#!/usr/bin/env bash
# Main-controlled single formal window. This wrapper starts only read-only top
# monitoring in addition to the frozen driver; it never starts a second window.
set -uo pipefail
cd /home/g/apps/sim-engine-issue6-cpu-baseline-v1
run_dir=/home/g/apps/sim-engine-issue6-cpu-baseline-v1/runs/cpu-batch-v1/run-20260927T055817Z-2557785
test ! -e "$run_dir/measurement" || exit 2
test ! -e "$run_dir/window-top.log" || exit 2
top -b -d 5 -w 180 -o %CPU > "$run_dir/window-top.log" &
monitor_pid=$!
cleanup_monitor() {
  kill -TERM "$monitor_pid" 2>/dev/null || true
  wait "$monitor_pid" 2>/dev/null || true
}
trap cleanup_monitor EXIT
printf 'monitor_pid=%s\n' "$monitor_pid"
date -u '+wrapper_started_utc=%FT%TZ'
PYTHONPATH=src .venv/bin/python benchmarks/cpu_batch_v1/driver.py measure \
  --run-dir "$run_dir" --deadline-seconds 1200
driver_status=$?
date -u '+wrapper_finished_utc=%FT%TZ'
printf 'driver_exit_status=%s\n' "$driver_status"
exit "$driver_status"
