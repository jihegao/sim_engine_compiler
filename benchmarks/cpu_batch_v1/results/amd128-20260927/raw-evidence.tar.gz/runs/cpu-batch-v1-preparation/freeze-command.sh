#!/usr/bin/env bash
set -euo pipefail
cd /home/g/apps/sim-engine-issue6-cpu-baseline-v1
PYTHONPATH=src .venv/bin/python benchmarks/cpu_batch_v1/driver.py freeze \
  --output-root /home/g/apps/sim-engine-issue6-cpu-baseline-v1/runs/cpu-batch-v1 \
  --plan /home/g/apps/sim-engine-issue6-cpu-baseline-v1/runs/cpu-batch-v1-preparation/plan.json \
  --lineage /home/g/apps/sim-engine-issue6-cpu-baseline-v1/runs/cpu-batch-v1-preparation/layers/lineage.json \
  --compiler-command '.venv/bin/python scripts/compile_ir.py /home/g/apps/sim-engine-issue6-cpu-baseline-v1/tests/fixtures/spare_mvp/f35-43day-5352a0d/simulation-inputs.json /home/g/apps/sim-engine-issue6-cpu-baseline-v1/runs/cpu-batch-v1-preparation/plan.json --semantic-profile event-time-v2 --artifacts-dir /home/g/apps/sim-engine-issue6-cpu-baseline-v1/runs/cpu-batch-v1-preparation/layers' \
  --install-provenance 'Isolated uv Python3.12.13 venv; RUSTUP_TOOLCHAIN=1.90.0 uv pip install --reinstall --python .venv/bin/python -e .[test]; cargo +1.90.0 build --locked --release --manifest-path rust/runtime/Cargo.toml --bin stage-c-benchmark --bin sim-engine-runtime. See runs/cpu-batch-v1-preparation/preparation.md. This text records commands, not an independent build attestation.'
