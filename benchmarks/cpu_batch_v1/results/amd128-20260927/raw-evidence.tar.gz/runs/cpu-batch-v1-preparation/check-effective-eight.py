"""Untimed semantic supplement: verify eight actual workers, not a timing probe."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from benchmarks.cpu_batch_v1 import driver
from sim_engine_compiler import run_batch
from sim_engine_compiler.reference.conformance import first_divergence

run_dir = ROOT / "runs/cpu-batch-v1/run-20260927T055817Z-2557785"
manifest = driver.load_frozen(run_dir)
driver.validate_gate_evidence(run_dir, manifest)
directory = run_dir / "effective-eight-semantic-supplement"
directory.mkdir(exist_ok=False)
plan = Path(manifest["timed_plan"]["path"])
seeds = [7, 0, 7, 1, 0, 1, 7, 7]
checks = []
commands = []
for observation in ("full", "summary"):
    admitted = json.loads(
        (run_dir / "semantic-gate" / f"rust-event-{observation}-required.json").read_text(encoding="utf-8")
    )
    expected = {row["seed"]: row["result"] for row in admitted["samples"]}
    rust_path = directory / f"rust-{observation}.json"
    command = [manifest["artifacts"]["runtime"]["path"], str(plan), str(rust_path),
               "--seeds", ",".join(map(str, seeds)), "--worker-threads", "8",
               "--observation-level", observation]
    execution = subprocess.run(command, check=True, capture_output=True, text=True, encoding="utf-8", timeout=60)
    commands.append({"argv": command, "exit_status": execution.returncode,
                     "stdout": execution.stdout, "stderr": execution.stderr})
    rust = json.loads(rust_path.read_text(encoding="utf-8"))
    pyo3 = run_batch(plan.read_bytes(), seeds, worker_threads=8, observation_level=observation)
    driver.atomic_json(directory / f"pyo3-{observation}.json", pyo3)
    for backend, result in (("rust", rust), ("pyo3", pyo3)):
        assert result["worker_threads"] == 8
        assert result["sample_count"] == len(seeds)
        assert [row["sample_index"] for row in result["samples"]] == list(range(8))
        assert [row["seed"] for row in result["samples"]] == seeds
        for index, sample in enumerate(result["samples"]):
            difference = first_divergence(expected[seeds[index]], sample["result"])
            checks.append({"backend": backend, "observation": observation,
                           "sample_index": index, "seed": seeds[index],
                           "first_divergence": driver._jsonable_divergence(difference),
                           "passed": difference is None})
    assert first_divergence(rust, pyo3) is None
report = {
    "schema_version": "cpu-batch-effective-eight-semantic-supplement/v1",
    "purpose": "Untimed pre-window semantics only; no throughput or latency claim; no N64 pilot.",
    "manifest_sha256": driver.sha256_file(run_dir / "manifest.json"),
    "primary_gate_sha256": driver.sha256_file(run_dir / "semantic-gate/report.json"),
    "script_sha256": driver.sha256_file(Path(__file__)),
    "seeds": seeds, "requested_workers": 8, "effective_workers": 8,
    "comparison": "Strict complete per-sample result trees against already admitted seeds0/1/7, each observation; strict complete Rust/PyO3 batch equality.",
    "commands": commands,
    "pyo3_call": "public run_batch(frozen_plan_bytes, seeds, worker_threads=8, observation_level=full|summary)",
    "checks": checks, "passed": all(row["passed"] for row in checks),
    "raw_files": {path.name: {"sha256": driver.sha256_file(path), "bytes": path.stat().st_size}
                  for path in directory.glob("*.json")},
}
driver.atomic_json(directory / "report.json", report)
assert report["passed"], "effective-eight semantic gate failed; do not measure"
print(json.dumps({"passed": report["passed"], "checks": len(checks), "effective_workers": 8}))
