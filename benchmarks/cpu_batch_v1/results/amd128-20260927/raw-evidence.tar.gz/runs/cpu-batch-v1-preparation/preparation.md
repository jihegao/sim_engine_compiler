# Untimed preparation, not formal measurement

Task `engine-issue6-baseline-resume-9e5020e-v1`, host `g-1503-amd128`.
Runtime/compiler baseline `595cb5eee9987324b19a8c3566f201f937e05f15`.
All commands below are preparation; no duration is claimed.

Fresh isolated `.venv` uses Python 3.12.13 and SimPy 4.1.1. Prior preparation
created it with uv, then explicitly rebuilt the editable native package with:

```sh
RUSTUP_TOOLCHAIN=1.90.0 uv pip install --reinstall --python .venv/bin/python -e '.[test]'
cargo +1.90.0 build --locked --release --manifest-path rust/runtime/Cargo.toml --bin stage-c-benchmark --bin sim-engine-runtime
```

The main coordinator verified the existing executable paths and that the
imported extension is this worktree's `src/sim_engine_compiler/_runtime.abi3.so`.
The freeze manifest hashes actual artifacts; version strings alone do not
authenticate a build. Runtime/compiler source must remain equal to the base.

Actual supported compilation, executed 2026-09-27 before the window:

```sh
PYTHONPATH=src .venv/bin/python scripts/compile_ir.py /home/g/apps/sim-engine-issue6-cpu-baseline-v1/tests/fixtures/spare_mvp/f35-43day-5352a0d/simulation-inputs.json /home/g/apps/sim-engine-issue6-cpu-baseline-v1/runs/cpu-batch-v1-preparation/plan.json --semantic-profile event-time-v2 --artifacts-dir /home/g/apps/sim-engine-issue6-cpu-baseline-v1/runs/cpu-batch-v1-preparation/layers
```

Printed identities:

- Business `c44e9f8c70595a133e52a811bc3a98f6c3ad283ab38ec637cafae0a558275dd3`
- Core `ae09fac8403b97a2eae2f3d919b0f2f3e9ac90555549b92d28ec59a44198a858`
- Plan `a7a27a982adc8b073cce0370c42d9e7284a48d2d038430e82618e906f4248ecc`

No candidate dispatch flag/index is enabled. The compiler is unchanged.
The 60-second per-cell cap is a prospective operational limit, not a measured
upper bound. No N64 timing pre-run has been performed.
