# K02 active Station.QTY blank/default1 finite native case

This directory includes all project execution code, source snapshots, prospective
full export/report/event/log references and independent native reader. Installed
SIMLOX/compiler/Python, current repository index/catalog, original protected GUI,
coordinator state and existing SSH trust are explicit prerequisites. Use isolated
Python (-I -X utf8 -B) with cwd C:/Windows/Temp.

Only the accepted active A01 Station(BASE-01).QTY changes from integer1 to null.
The documented default1 is exercised during real calculation, separately from
source exchange: all339 exported typed cells must preserve QTY=null, while all4044
report cells and the complete event/four-stage log bodies must match the accepted
single-station parent. This is a before-run hypothesis, never an observed oracle fix.

1. Read contract.json and selected-manifest-v22.json; verify all source/host pins,
   static review plus static-control-annotation-addendum-v1.json and reader binding.
2. derive_input.py --output <this-folder>/review/directory-derived-input-v1.json
   must create the exact one-cell child, using exclusive creation.
3. directory_preflight.py runs only the pure guarded SSH0/PS5 preflight (native0).
4. Independent review binds the actual preflight, source, entries and reader into
   one fresh permission. Preparation and compilation alone are not native GO.
5. directory_native_once.py <exact-GO-SHA> dispatches at most import-save, export,
   single-thread calc once and jsonreport once. A failure stops subsequent stages.
6. accept_native.py --controller <exact-path> --controller-sha <exact-SHA> verifies
   full immutable raw/model/report/log data, original-H lifecycle, actual NTFS
   identities, all closes, queue release and the protected GUI independently.

Fixed runID k02-qty-default-v100-20261019-01 is one-shot. An existing claim or raw
directory means STOP; do not recreate GO, retry, overwrite failure evidence or
change frozen expectations. Unknown identity/signal/close/queue stays in its
original owner; no kill/retry/release. Generic runtime/IR and protected settings
are unchanged. This case cannot establish general null defaults, wrong-type
rejection, inactive rows, nonASCII, a new-agent trial or whole-K02 completion.
