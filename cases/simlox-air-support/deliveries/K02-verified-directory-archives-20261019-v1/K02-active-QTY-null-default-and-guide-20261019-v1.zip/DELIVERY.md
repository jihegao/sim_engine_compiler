# K02 active QTY-null/default1 native case evidence delivery

Only the accepted active A01 Station(BASE-01).QTY changes from integer1 to null.
The actual independent native acceptance requires all339 typed export cells with
QTY still null, then all4044 report cells, the complete event log and all four
stage logs matching the prospectively frozen accepted parent behavior. The
observed single-station behavior is consistent with documented default1; internal
interpreter state was not inspected and no general default expansion is claimed.

This directory contains source, frozen expectations, native raw results, original
owner/independent receipts, project execution code and DIRECTORY-GUIDE.md. The
original runID, claim and GO are consumed. Never rerun their native entry, recreate
GO, overwrite evidence or change an oracle after observation. Any fresh native
reproduction needs a new fixed version/paths/runID and all independent safety gates.
Installed vendor tools, manuals, SSH trust, original GUI/coordinator state and live
repository freshness checks remain explicit prerequisites, not copied materials.

Portable read-only content replay:
  python -I -X utf8 -B replay.py <this directory>
It verifies every indexed byte, the exact one-cell source derivation, full typed
export/report, raw-normalized relationship, events, complete CRLF logs and the
archived custody/lifecycle receipts. It launches no native process and does not
recreate Windows readonly/identity/handle/queue/GUI state. Refer to the original
independent receipt for the actual OS evidence. No private dump, vendor program,
manual or credential is included. The static control annotation addendum records
a mislabeled QTY1 control and the subsequent actual QTY0 rejection without any
source, oracle or original receipt modification.

This bounded case is not general null/default semantics, wrong-type import
rejection, inactive-row preservation, nonASCII support, a separate-agent native
trial, repository publication, cross-engine conformance or whole-K02 completion.
