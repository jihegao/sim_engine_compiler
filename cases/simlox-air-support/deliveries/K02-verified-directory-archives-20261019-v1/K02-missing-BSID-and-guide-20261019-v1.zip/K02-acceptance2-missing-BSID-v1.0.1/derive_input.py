from pathlib import Path
import argparse,hashlib,json
CASE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();assert a.output.parent.resolve()==(CASE/'review').resolve()
r=(CASE/'source-snapshots/parent-input.json').read_bytes();assert hashlib.sha256(r).hexdigest()=='8bbd31d05630cc4a44c4b03b715d17e2f4a1ee1601352952089efd3e584f98b7'
d=json.loads(r);t=next(t for t in d['model']['tables'] if t['name']=='System');j=next(j for j,c in enumerate(t['columns']) if c['name']=='BSID')
assert len(t['instances'])==1 and t['instances'][0]['instance_name']=='' and t['instances'][0]['rows'][0][j] is None
t['instances'][0]['rows'][0][j]='K02-NO-SUCH';out=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode()
assert hashlib.sha256(out).hexdigest()=='18bcf7b7cb4502e1238ab9c3e42d82096adcb62eb593b998784871b9c49a5db3' and out==(CASE/'native-input.json').read_bytes()
with a.output.open('xb') as f:f.write(out)
print(json.dumps({'derived_source_sha256':hashlib.sha256(out).hexdigest(),'native_calls':0}))
