"""One reviewed fixed missing-BSID omission exchange, no retries."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

CASE=Path(__file__).resolve().parent
MANIFEST='82818f29dc999aa4f813b2db2374606bfbed2faf9dce11a23279952fd7cd90ee'
REVIEW=sys.argv[1]
assert __import__('re').fullmatch('[0-9a-f]{64}',REVIEW)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p): return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def save(p,value):
    with p.open('x',encoding='utf-8') as stream:json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')
mp=CASE/'selected-manifest-v24.json';assert sha(mp)==MANIFEST
m=json.loads(mp.read_bytes());target=m['targets']['native']
review=CASE/'review/independent-native-go-v24.json';assert sha(review)==REVIEW
permission=json.loads(review.read_bytes())
assert permission['decision']=='GO_PRELAUNCH' and permission['mode']=='native' and permission['manifest_sha256']==MANIFEST
assert permission['run_id']==target['run_id'] and permission['attempt_limit']==1
assert permission['allowed_stages']==['jimport_save','jexport','calc']
assert permission['simulation_calls_allowed']==1 and permission['maximum_native_child_creations']==3
assert permission['accepted_parent_or_control_reruns_allowed']==0
claim=Path(permission['attempt_claim_path']);assert not claim.exists()
assert not Path(target['physical_directory']).exists() and not Path(target['recovered_directory']).exists()
state=json.loads(Path('C:/Users/user/Documents/Codex/issue18-local-monitor/goal-mode-20261016/state.json').read_bytes())
assert state['thread_status']['type']=='systemError' and state['root_turns_started']==state['root_turns_completed']==52
assert not state.get('pending_requests')
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
record=CASE/('review/native-controller-'+stamp+'.json')
guardian=CASE/('review/guardian-native-'+stamp+'.json')
command=[m['powershell']['path'],'-NoProfile','-NonInteractive','-File',str(CASE/'standalone_guardian_selected_v24.ps1'),'-Mode','native','-OutputPath',str(guardian),'-ExpectedManifestSha',MANIFEST]
result={'schema':'issue18-K02-missing-BSID-single-native-controller/v1','started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest':pin(mp),'permission':pin(review),'original_thread_status':state['thread_status'],'original_turns':[state['root_turns_started'],state['root_turns_completed']],'guardian_command':command,'native_dispatch_attempted':False,'actual_native_calls':None,'actual_simulation_calls':None,'retries':0}
r=subprocess.run(command,capture_output=True)
result.update({'guardian_exit_code':r.returncode,'guardian_stdout':r.stdout.decode('utf-8-sig',errors='replace'),'guardian_stderr':r.stderr.decode('utf-8-sig',errors='replace')})
if r.returncode!=0 or not guardian.is_file():
    result.update({'status':'NATIVE_GUARDIAN_REJECTED_NO_DISPATCH','actual_native_calls':0,'actual_simulation_calls':0})
    save(record,result);print(json.dumps({**result,'record':pin(record)},ensure_ascii=False,indent=2));sys.exit(1)
g=json.loads(guardian.read_text(encoding='utf-8-sig'))
assert g['decision']=='GO_STANDALONE_SAFETY_ONLY' and g['terminal'] is True and g['native_calls']==0 and g['mode']=='native'
result['guardian']=pin(guardian)
save(claim,{'schema':'issue18-K02-missing-BSID-native-one-attempt-claim/v1','created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run_id':target['run_id'],'manifest_sha256':MANIFEST,'permission_sha256':REVIEW,'guardian':pin(guardian),'maximum_attempts':1,'automatic_retry':False})
command=[m['python']['path'],'-E','-X','utf8','-B',str(CASE/'ssh_transport_selected_v24.py'),'native','--review-sha',REVIEW,'--manifest-sha',MANIFEST,'--guardian',str(guardian),'--guardian-sha',sha(guardian)]
result.update({'attempt_claim':pin(claim),'native_dispatch_attempted':True,'transport_command':command})
r=subprocess.run(command,capture_output=True)
result.update({'completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'transport_exit_code':r.returncode,'transport_stdout':r.stdout.decode('utf-8-sig',errors='replace'),'transport_stderr':r.stderr.decode('utf-8-sig',errors='replace'),'status':'NATIVE_TRANSPORT_RETURNED_PENDING_INDEPENDENT_ACCEPTANCE' if r.returncode==0 else 'NATIVE_TRANSPORT_FAILED_NO_RETRY','physical_directory_exists':Path(target['physical_directory']).exists(),'recovered_directory_exists':Path(target['recovered_directory']).exists()})
try:
    evidence=Path(json.loads(result['transport_stdout'])['evidence'])
    owner_path=Path((evidence/'stdout.bin').read_text(encoding='utf-8-sig').strip())
    assert owner_path.parent==CASE/'review' and owner_path.name.startswith('native-')
    owner=json.loads(owner_path.read_text(encoding='utf-8-sig'))
    assert owner['mode']=='native' and owner['run_id']==target['run_id'] and owner['manifest_sha256']==MANIFEST
    owned=owner['result'];result.update({'owner_receipt':pin(owner_path),'actual_native_calls':owned['NativeSimloxCalls'],'actual_simulation_calls':owned['SimulationCalls'],'owner_failed':owned['Failed'],'raw_behavior_accepted':owned['RawBehaviorAccepted'],'queue_released_actual':owned['QueueReleasedActual']})
except Exception as error:
    result['owner_read_status']='Not yet independently verified: '+repr(error)
save(record,result)
print(json.dumps({**result,'record':pin(record)},ensure_ascii=False,indent=2))
sys.exit(r.returncode)
