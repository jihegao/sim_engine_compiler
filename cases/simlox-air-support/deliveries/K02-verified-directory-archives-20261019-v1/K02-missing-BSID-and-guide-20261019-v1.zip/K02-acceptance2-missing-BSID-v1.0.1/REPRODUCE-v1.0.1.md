# K02 missing BSID v1.0.1: canonical directory reproduction guide

Read this guide with contract.json and selected-manifest-v24.json. This is the
current guide. The retained DIRECTORY-GUIDE.md template mentions a v100
pre-native installation receipt: for this version use review/adapter-repair-
evidence-v1.json and preserved-v100-evidence/ instead. No guide grants native GO.

Scope: one active System(TEACH-AIR-01).BSID null -> K02-NO-SUCH. Source and all
339 typed export cells, exact converter error log and unusable SXO oracle are
byte-identical to the prospectively frozen v100 contract, except declared target
paths. The manual defines BSID as another defined System. Expected calc conversion
refusal is System rec1 error18, Errors1/Warnings2/Notes0, four-byte SXO8bc53301,
no event log/report and no actual simulation. All three processes may exit0.

All project execution code, source/oracle and independent reader are case-local.
Installed SIMLOX/compiler/Python/manuals, existing SSH trust, original protected
GUI, coordinator state and current repository index/catalog are host prerequisites.
Do not copy credentials/vendor programs/manuals or use an author scratch project.

Use the pinned Python with -I -X utf8 -B and cwd C:/Windows/Temp:
1. Verify every manifest source/tool/ref hash and the static v24 review. It includes
   real positive/negative response-protocol tests and independent path rendering.
2. derive_input.py --output <this-folder>/review/directory-derived-input-v1.json
   exclusively derives exactly the declared child from the pinned parent.
3. directory_preflight.py performs only fresh SSH0/PS5/GUI/identity/unique-execution/
   NativeQueue/ref/settings checks. Preparation/compilation is not native GO.
4. Independent actual-preflight review binds manifest, entries, reader, this guide
   and preserved v100 failure into one GO for k02-missing-bsid-v101-20261019-01.
5. directory_native_once.py <GO-SHA> dispatches only import-save/export/calc once
   each at most. No jsonreport, silent extra stage or automatic retry is allowed.
6. accept_native.py --controller <exact-path> --controller-sha <exact-SHA> checks
   immutable13-file originals/recovery, all339 typed cells, complete three logs,
   failed-result marker, no event/report, actual NTFS identities, all original-H
   closes, NativeQueue release and original GUI full identity independently.

v100 is consumed and remains end-to-end NO_GO: all native source/refusal evidence
matched its frozen contract, but its wrapper still required A01 success-report
fields. v101 fixes that protocol plus independent reader path rendering/audit
loading. It never changes source or an expected result to fit observations.

This v101 runID is also one-shot. An existing claim/raw directory means STOP;
never recreate GO, overwrite originals or rerun either version. Future reproduction
requires a new explicit version/paths/runID and all gates. Unknown H identity,
signal, close or queue stays with original owner; no kill/retry/release.
One negative BSID contract does not prove import rejection, arbitrary references,
cycles, successful simulation, wrong-type/duplicate/nonASCII/inactive fidelity,
GUI functionality, separate-agent trial, publication or wholeK02/Issue completion.
