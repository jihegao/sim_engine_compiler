# K02 one active missing-BSID converter refusal

The directory includes project execution code, exact parent/source snapshots,
prospective full339-cell export, full three-stage log shapes, retained prior
field-specific negative evidence, and an independent native acceptance reader.
Installed SIMLOX/compiler/Python, live repository index/catalog freshness, original
protected GUI and existing SSH trust remain explicit host prerequisites. Use
isolated Python (-I -X utf8 -B) from neutral cwd C:/Windows/Temp.

The sole authored change is System(TEACH-AIR-01).BSID null -> K02-NO-SUCH. This
identifier is not defined as any System. The manual says BSID must name another
defined system. Normal calc interprets/tests input before simulation. The exact
prospective result is import/export preservation of339 typed cells followed by
System rec1 error18 during calc, Errors1/Warnings2/Notes0, four-byte unusable SXO
8bc53301, no event log/report and no actual simulation. Calc may exit0; an exit
code is not a success oracle. The expected body is frozen before execution.

1. Read contract.json and selected-manifest-v24.json; verify all source/host pins,
   static review, pre-native-installation-failure-v1.json and reader binding.
2. derive_input.py --output <this-folder>/review/directory-derived-input-v1.json
   exclusively creates the exact one-reference child from case-local source.
3. directory_preflight.py performs guarded pure SSH0/PS5 preflight, native0.
4. Independent review binds actual preflight/entries/reader into one new GO.
5. directory_native_once.py <GO-SHA> performs import-save, export and calc once
   each at most; no jsonreport is allowed. Preserve all partial failure originals.
6. accept_native.py --controller <path> --controller-sha <SHA> independently checks
   full raw/typed/log/negative-result evidence, NTFS identities, original-H closes,
   queue release and the protected GUI. It does not import the producer checker.

RunID k02-missing-bsid-v101-20261019-01 is one-shot. Existing claim or raw directory
means STOP. No prepare/native retry, recreated GO, overwritten failure or observed
oracle correction. Unknown H identity/signal/close/queue remains with original
owner; no kill/retry/release. This accepts one converter refusal and diagnostic
retention, not a successful simulation, import rejection, arbitrary reference or
cycle rule, GUI feature, cross-engine parity, new-agent trial or wholeK02/Issue.
