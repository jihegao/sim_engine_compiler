"""Read-only independent full native-result acceptance for the fixed A01 run.

Does not import the producer/owner/content checker, execute a model, or change
source/raw files. Writes only a new terminal acceptance receipt after all checks.
"""
from pathlib import Path
import ctypes
from ctypes import wintypes
import datetime
import hashlib
import json
import re
import struct
import subprocess

CASE=Path(__file__).resolve().parent
MANIFEST='82818f29dc999aa4f813b2db2374606bfbed2faf9dce11a23279952fd7cd90ee'
def filepin(p):
    data=p.read_bytes();return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def bound(pin):
    p=Path(pin['path']);assert filepin(p)=={k:pin[k] for k in ('path','bytes','sha256')};return p.read_bytes()
def deep(a,b,path='$'):
    assert type(a) is type(b),'typed mismatch '+path
    if isinstance(a,dict):
        assert set(a)==set(b),'key mismatch '+path
        return 1+sum(deep(a[k],b[k],path+'/'+k) for k in a)
    if isinstance(a,list):
        assert len(a)==len(b),'array size mismatch '+path
        return 1+sum(deep(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b)))
    if isinstance(a,float):assert struct.pack('>d',a)==struct.pack('>d',b),'binary64 mismatch '+path
    else:assert a==b,'value mismatch '+path
    return 1
def cells(value):
    if isinstance(value,dict):return sum(sum(map(len,v)) if k=='rows' else cells(v) for k,v in value.items())
    if isinstance(value,list):return sum(cells(v) for v in value)
    return 0

def properties(items):
    d={}
    for k,v in items:assert k not in d,'lexical property duplicate';d[k]=v
    return d
def document(raw):return json.loads(raw,object_pairs_hook=properties,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite JSON')))
class FT(ctypes.Structure):_fields_=[('low',wintypes.DWORD),('high',wintypes.DWORD)]
class INFO(ctypes.Structure):
    _fields_=[('attributes',wintypes.DWORD),('creation',FT),('access',FT),('write',FT),('volume',wintypes.DWORD),('size_high',wintypes.DWORD),('size_low',wintypes.DWORD),('links',wintypes.DWORD),('id_high',wintypes.DWORD),('id_low',wintypes.DWORD)]
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.CreateFileW.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p,wintypes.DWORD,wintypes.DWORD,wintypes.HANDLE];k.CreateFileW.restype=wintypes.HANDLE
k.GetFileInformationByHandle.argtypes=[wintypes.HANDLE,ctypes.POINTER(INFO)];k.GetFileInformationByHandle.restype=wintypes.BOOL
k.CloseHandle.argtypes=[wintypes.HANDLE];k.CloseHandle.restype=wintypes.BOOL
k.OpenMutexW.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.LPCWSTR];k.OpenMutexW.restype=wintypes.HANDLE
def actual_file_identity(p):
    h=k.CreateFileW(str(p),0x80,1,None,3,0x00200000,None)
    assert h and h!=ctypes.c_void_p(-1).value,('read-only metadata open',str(p),ctypes.get_last_error())
    try:
        i=INFO();assert k.GetFileInformationByHandle(h,ctypes.byref(i))
        assert i.links==1 and not i.attributes&0x410 and i.attributes&1
        return {'Volume':i.volume,'Id':(i.id_high<<32)|i.id_low,'Creation':(i.creation.high<<32)|i.creation.low,'Bytes':(i.size_high<<32)|i.size_low,'Attributes':i.attributes}
    finally:assert k.CloseHandle(h),'independent metadata H close failure'

mp=CASE/'selected-manifest-v24.json';assert filepin(mp)['sha256']==MANIFEST
m=document(mp.read_bytes());t=m['targets']['native'];rawdir=Path(t['physical_directory']);recovered=Path(t['recovered_directory'])
import argparse
parser=argparse.ArgumentParser();parser.add_argument('--controller',type=Path,required=True);parser.add_argument('--controller-sha',required=True);args=parser.parse_args()
assert args.controller.parent==CASE/'review'
controller_pin=filepin(args.controller);assert controller_pin['sha256']==args.controller_sha
controller=document(bound(controller_pin))
assert controller['transport_exit_code']==0 and not controller['transport_stderr'] and controller['retries']==0
assert controller['actual_native_calls']==3 and controller['actual_simulation_calls']==1
owner_pin=controller['owner_receipt'];owner=document(bound(owner_pin));result=owner['result']
assert owner['mode']=='native' and owner['manifest_sha256']==MANIFEST and owner['run_id']==t['run_id']
for key in ['RawOwned','RecoveredOwned','OriginalSealed','RecoveryVerified','RawBehaviorAccepted','QueueReleaseAttempted','QueueReleasedActual']:
    assert result[key] is True,key
for key in ['Failed','UnknownChild','QueueOwned']:
    assert result[key] is False,key
assert result['NativeSimloxCalls']==3 and result['SimulationCalls']==1 and result['ParentReruns']==0
children=result['Children'];assert [x['Stage'] for x in children]==['jimport_save','jexport','calc']
identities=owner['independent_suspended_identity'];assert len(identities)==3
for child in children:
    for key in ['CreateAttempted','CreateReturned','Created','ResumeAttempted','ResumeReturned','Signaled','IdentityBeforeResume','IdentityAfterSignal','ExitCodeObserved']:
        assert child[key] is True,(child['Stage'],key)
    assert child['ExitCode']==0 and child['ResumeCount']==1 and child['Session']==0
    assert child['ImagePath'].lower()==m['exe']['path'].lower()
    rows=[x for x in identities if x['pid']==child['Pid'] and int(x['creation_filetime'])==child['Creation']]
    assert len(rows)==1 and rows[0]['observed_before_resume'] is True
    assert rows[0]['path'].lower()==m['exe']['path'].lower()
assert len({(x['Pid'],x['Creation']) for x in children})==3
handles=result['Handles'];assert handles
assert all(x['CloseAttempted'] is True and x['ClosedActual'] is True and x['CloseUnknown'] is False for x in handles)
assert len([x for x in handles if x['Role'].startswith('Process:')])==3
assert len([x for x in handles if x['Role'].startswith('Thread:')])==3

contract=document((CASE/'content-contract-v1.json').read_bytes())
assert filepin(CASE/'content-contract-v1.json')['sha256']==m['component_binding_sha256']
names=set(contract['raw_payload']);assert len(names)==13
assert {p.name for p in rawdir.iterdir()}=={p.name for p in recovered.iterdir()}==names
originals={x['Name']:x for x in result['Originals']};copies={x['Name']:x for x in result['Recovered']}
assert set(originals)==set(copies)==names
payload={};pairs=[]
for name in sorted(names):
    p=rawdir/name;q=recovered/name;op=originals[name];cp=copies[name]
    a=p.read_bytes();b=q.read_bytes();actual=hashlib.sha256(a).hexdigest()
    assert a==b and actual==op['Sha']==cp['Sha']
    assert len(a)==op['Bytes']==cp['Bytes']
    assert (op['Volume'],op['Id'])!=(cp['Volume'],cp['Id'])
    assert op['Attributes']&1 and cp['Attributes']&1
    li=actual_file_identity(p);ri=actual_file_identity(q)
    assert all(li[k]==op[k] and ri[k]==cp[k] for k in li)
    assert p.stat().st_file_attributes&1 and q.stat().st_file_attributes&1
    payload[name]=a;pairs.append({'name':name,'bytes':len(a),'sha256':actual,'original_and_recovered_byte_equal':True,'original_readonly':True,'recovered_readonly':True,'distinct_file_identity':True})
assert hashlib.sha256(payload['input.json']).hexdigest()=='18bcf7b7cb4502e1238ab9c3e42d82096adcb62eb593b998784871b9c49a5db3'
source=document(payload['input.json']);st=next(t for t in source['model']['tables'] if t['name']=='System');j=next(j for j,c in enumerate(st['columns']) if c['name']=='BSID')
assert len(st['instances'])==1 and st['instances'][0]['instance_name']=='' and len(st['instances'][0]['rows'])==1
assert st['instances'][0]['rows'][0][0]=='TEACH-AIR-01' and st['instances'][0]['rows'][0][j]=='K02-NO-SUCH'
st['instances'][0]['rows'][0][j]=None
assert (json.dumps(source,ensure_ascii=False,indent=2)+'\n').encode()==(CASE/'source-snapshots/parent-input.json').read_bytes()
assert len(payload['model.sxi'])>4 and payload['model.sxo']==bytes.fromhex('8bc53301')
for stage in ['jimport_save','jexport','calc']:assert payload[stage+'-stderr.bin']==b''
reference={name:bound({'path':str(CASE/p['relative_path']),'bytes':p['bytes'],'sha256':p['sha256']}) for name,p in contract['references'].items()}
export_nodes=deep(document(payload['roundtrip-raw.json']),document(reference['roundtrip-raw.json']))
assert cells(document(payload['roundtrip-raw.json']))==339
assert set(contract['forbidden_files']).isdisjoint({p.name for p in rawdir.iterdir()})
full_logs=[]
for name in ['import.log','export.log','run.log']:
    sh=bytes.fromhex(contract['run_log_shape_hex'] if name=='run.log' else contract['log_shapes_hex'][name])
    expanded=sh.replace(b'@RUN@\\',str(rawdir).encode('ascii')+b'\\').replace(b'@RUN@/',str(rawdir).replace('\\','/').encode('ascii')+b'/')
    assert b'@RUN@' not in expanded
    expression=re.escape(expanded).replace(re.escape(b'@ELAPSED@'),rb'[0-9]+\.[0-9]+')
    actual=payload[name]
    assert actual.endswith(b'\r\n') and b'\n' not in actual.replace(b'\r\n',b'') and b'\r' not in actual.replace(b'\r\n',b'')
    assert re.fullmatch(expression,actual),('full prospective log mismatch',name)
    full_logs.append({'name':name,'bytes':len(actual),'sha256':hashlib.sha256(actual).hexdigest(),'full_CRLF_body_matches_prospective':True})
marker=re.search(rb'Input conversion completed\. Errors: (\d+), Warnings: (\d+), Notes: (\d+)\r\n',payload['run.log']);assert marker and marker.groups()==(b'1',b'2',b'0')
assert b'rec 1: (error #18) Unknown base system identifier (BSID):  K02-NO-SUCH\r\n' in payload['run.log']
assert b'Starting simulation' not in payload['run.log'] and b'Saving results' not in payload['run.log']
for entry in m['sources']:bound(entry)

audit=document((CASE/'source-role-audit-v1.json').read_bytes())
binding=CASE/'directory-entry-binding-v1.json';permission=document(bound(controller['permission']))
assert filepin(binding)==permission['directory_entry_binding']
for v in document(binding.read_bytes())['files']:
    raw=(CASE/v['relative_path']).read_bytes();assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256']
invocation=CASE/'review/directory-native-invocation-v1.json';inv=document(invocation.read_bytes())
assert inv['exit_code']==0 and inv['retries']==0 and inv['cwd']=='C:/Windows/Temp'
assert inv['command'][:5]==[m['python']['path'],'-I','-X','utf8','-B'] and inv['command'][5]==str(CASE/'directory_native_once.py')
assert m['working_directory']==str(CASE)
for v in audit['source_roles']:
    if v['classification'].startswith('PROJECT'):assert Path(v['selected']['path']).is_relative_to(CASE)

ps=r'''$g=@(Get-Process Simlox -ErrorAction SilentlyContinue);if($g.Count -ne 1){throw 'Unexpected native process set'};$g|ForEach-Object{[ordered]@{pid=$_.Id;session=$_.SessionId;creation_filetime=$_.StartTime.ToUniversalTime().ToFileTimeUtc().ToString();path=$_.Path;responding=$_.Responding}}|ConvertTo-Json -Compress'''
observed=subprocess.run([m['powershell']['path'],'-NoProfile','-NonInteractive','-Command',ps],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=20)
assert observed.returncode==0 and not observed.stderr
gui=document(observed.stdout)
assert gui['pid']==13340 and gui['session']==1 and gui['creation_filetime']=='134350637968261381' and gui['responding'] is True
assert gui['path']==m['exe']['path']
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.OpenMutexW.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.LPCWSTR];kernel.OpenMutexW.restype=wintypes.HANDLE
kernel.CloseHandle.argtypes=[wintypes.HANDLE];kernel.CloseHandle.restype=wintypes.BOOL
ctypes.set_last_error(0);handle=kernel.OpenMutexW(0x00100000,False,r'Global\SimloxIssue18NativeQueue');error=ctypes.get_last_error()
if handle:assert kernel.CloseHandle(handle)
assert not handle and error==2
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt={'schema':'issue18-independent-K02-active-missing-BSID-acceptance/v1','utc':now,'terminal':True,'completed':True,'decision':'ACCEPT_BOUNDED_K02_MISSING_BSID_CONVERSION_REFUSAL_AND_FAILURE_RETENTION','run_id':t['run_id'],'manifest':filepin(mp),'controller':controller_pin,'owner_receipt':owner_pin,'physical_directory':str(rawdir),'recovered_directory':str(recovered),'actual_native_stages':[{'stage':x['Stage'],'pid':x['Pid'],'creation_filetime_decimal':str(x['Creation']),'exit_code':x['ExitCode'],'original_H_signaled':x['Signaled'],'single_resume_count':x['ResumeCount']} for x in children],'actual_native_calls':3,'actual_calc_invocations':1,'owner_SimulationCalls_legacy_counter':1,'successful_simulation_executions':0,'jsonreport_invocations':0,'new_control_calls':0,'parent_validation_reruns':0,'source_roles_rechecked':len(m['sources']),'independent_export_tree_nodes_checked':export_nodes,'export_cells':cells(document(payload['roundtrip-raw.json'])),'full_stage_logs_checked':full_logs,'native_error':{'phase':'calc input conversion','form':'System','record':1,'code':18,'reference':'K02-NO-SUCH','converter_errors':1,'converter_warnings':2,'converter_notes':0},'failed_result':{'bytes':4,'sha256':hashlib.sha256(payload['model.sxo']).hexdigest(),'hex':'8bc53301','usable_behavioral_result':False},'behavioral_event_log_present':False,'behavioral_report_present':False,'complete_raw_pairs':pairs,'all_original_handles_closed_actual':True,'handle_records_verified':len(handles),'actual_readonly_NTFS_metadata_queries':26,'native_queue_release_actual':True,'native_queue_OpenExisting_after':{'exists':bool(handle),'last_error':error,'ownership_not_changed':True},'protected_gui_final':gui,'native_execution_verified':True,'negative_input_contract_accepted':True,'successful_model_behavior_accepted':False,'owner_RawBehaviorAccepted_means':'Prospective negative refusal/retention envelope only, never successful simulation','directory_only_cold_process_native_verified':True,'project_source_paths_outside_case_required':0,'guide_only_other_agent_delivery_verified':False,'publication_GO':False,'original_import_rejection_oracle_changed':False,'K02_native_holds_unchanged':True,'whole_scope_complete':False,'denominator':None,'limitations':['Only one active System.BSID undefined reference in this installed engine; no arbitrary references/cycles','Import/export retain input; rejection is calc conversion, not import','Exit0 is retained as actual process state, not behavioral success','Wrong-type NO_GO, duplicate import HOLD, nonASCII failure and inactive_rows gaps remain; no separate-agent/publication/wholeIssue acceptance']}
target=CASE/'review/independent-native-acceptance-v24.json'
with target.open('x',encoding='utf-8') as stream:json.dump(receipt,stream,ensure_ascii=False,indent=2);stream.write('\n')
print(json.dumps({'observed_at_utc':now,'decision':receipt['decision'],'terminal_receipt':filepin(target),'native_stages':receipt['actual_native_stages'],'actual_native_calls':3,'actual_calc_invocations':1,'successful_simulation_executions':0,'raw_pairs_verified':len(pairs),'export_cells':339,'full_stage_logs':3,'handle_records_verified':len(handles),'native_error':receipt['native_error'],'failed_result':receipt['failed_result'],'native_queue_release_actual':True,'native_queue_after':receipt['native_queue_OpenExisting_after'],'protected_gui_final':gui,'whole_scope_complete':False},ensure_ascii=False,indent=2))
