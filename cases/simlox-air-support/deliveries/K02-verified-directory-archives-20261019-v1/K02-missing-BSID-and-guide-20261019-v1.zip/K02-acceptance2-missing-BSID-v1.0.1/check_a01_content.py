"""Read-only complete content check for one prospectively frozen converter refusal."""
from pathlib import Path
import argparse,hashlib,json,math,re,struct
CASE=Path(__file__).resolve().parent
TIMING=re.compile(rb'(?m)^(Import completed! Time: |Export completed! Time: |Input data conversion time: )[0-9]+\.[0-9]+( secs\.?\r)$')
COUNTS={'import.log':1,'export.log':1,'run.log':1}
CONTENT_NAMES=['input.json','model.sxi','model.sxo','roundtrip-raw.json','import.log','export.log','run.log']
def need(x,m):
 if not x:raise ValueError(m)
def digest(r):return hashlib.sha256(r).hexdigest()
def props(items):
 d={}
 for k,v in items:need(k not in d,'lexical duplicate property');d[k]=v
 return d
def document(r):return json.loads(r,object_pairs_hook=props,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite JSON')))
def typed(v):
 if isinstance(v,dict):return ('object',tuple((k,typed(x)) for k,x in sorted(v.items())))
 if isinstance(v,list):return ('array',tuple(map(typed,v)))
 if type(v) is float:need(math.isfinite(v),'nonfinite number');return ('binary64',struct.pack('>d',v).hex())
 return (type(v).__name__,v)
def cells(v):
 if isinstance(v,dict):return sum(sum(map(len,x)) if k=='rows' else cells(x) for k,x in v.items())
 if isinstance(v,list):return sum(map(cells,v))
 return 0
def shape(raw,directory,name):
 need(raw.endswith(b'\r\n'),name+': final CRLF missing');rest=raw.replace(b'\r\n',b'');need(b'\r' not in rest and b'\n' not in rest,name+': incomplete CRLF')
 raw=raw.replace(directory.encode('ascii'),b'@RUN@').replace(directory.replace('\\','/').encode('ascii'),b'@RUN@')
 result,n=TIMING.subn(rb'\1@ELAPSED@\2',raw);need(n==COUNTS[name],name+': elapsed grammar');return result
def verify_content(actual,directory,c,refs):
 need(set(CONTENT_NAMES)<=set(actual),'complete negative content missing')
 need(digest(actual['input.json'])==c['source_input_sha256'],'source changed')
 need(len(actual['model.sxi'])>4,'invalid SXI')
 need(actual['model.sxo']==bytes.fromhex(c['invalid_sxo_hex']),'invalid-result marker mismatch; no behavioral success inferred')
 export=document(actual['roundtrip-raw.json']);need(typed(export)==typed(document(refs['roundtrip-raw.json'])),'complete typed export mismatch')
 need(cells(export)==339,'full export cells mismatch')
 for n in ['import.log','export.log']:
  need(shape(actual[n],directory,n)==bytes.fromhex(c['log_shapes_hex'][n]),n+': complete log mismatch')
 need(shape(actual['run.log'],directory,'run.log')==bytes.fromhex(c['run_log_shape_hex']),'run.log: complete prospective converter error mismatch')
 need(not(set(c['forbidden_files'])&set(actual)),'behavioral log/report unexpectedly present')
 return {'status':'NEGATIVE_CONVERSION_CONTENT_ACCEPTED_NOT_SIMULATION_SUCCESS','full_typed_export_cells':339,'native_error_code':18,'native_error_reference':'K02-NO-SUCH','converter_errors':1,'converter_warnings':2,'converter_notes':0,'sxo_bytes':4,'behavioral_report_present':False,'event_log_present':False,'native_GO':False,'publication_GO':False}
def load_contract(expected):
 raw=(CASE/'content-contract-v1.json').read_bytes();need(digest(raw)==expected,'contract changed');c=document(raw);need(c['schema']=='issue18-K02-missing-BSID-content/v1','unsupported contract')
 refs={}
 for n,v in c['references'].items():
  r=(CASE/v['relative_path']).read_bytes();need(len(r)==v['bytes'] and digest(r)==v['sha256'],'reference changed: '+n);refs[n]=r
 return c,refs
def main():
 p=argparse.ArgumentParser();p.add_argument('--binding-sha',required=True);p.add_argument('--raw-directory',type=Path,required=True);p.add_argument('--input-path',type=Path,required=True);p.add_argument('--output-path',type=Path,required=True);a=p.parse_args()
 c,refs=load_contract(a.binding_sha);need(str(a.raw_directory)==c['physical_directory'],'fixed directory differs')
 need(a.input_path==a.raw_directory/'input.json' and a.output_path==a.raw_directory/'roundtrip-raw.json','fixed input/export paths differ')
 names={x.name for x in a.raw_directory.iterdir()};need(names==set(c['raw_payload']) and all((a.raw_directory/n).is_file() for n in names),'complete13-file negative raw inventory differs')
 actual={n:(a.raw_directory/n).read_bytes() for n in names}
 for n in ['jimport_save','jexport','calc']:need(actual[n+'-stderr.bin']==b'','native stderr nonempty: '+n)
 out=verify_content(actual,str(a.raw_directory),c,refs);out['raw_sha256']={n:digest(r) for n,r in actual.items()};print(json.dumps(out,sort_keys=True));return 0
if __name__=='__main__':raise SystemExit(main())
