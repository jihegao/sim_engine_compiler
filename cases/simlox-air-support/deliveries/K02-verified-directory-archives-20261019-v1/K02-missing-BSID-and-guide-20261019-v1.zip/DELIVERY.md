# K02 active missing-BSID native refusal and directory delivery

The sole authored change is System(TEACH-AIR-01).BSID null -> K02-NO-SUCH in the
accepted active A01 input. Import/export preserve all339 typed cells including
the undefined reference. One real calc invocation refuses it during input
conversion: System record1 error18 names K02-NO-SUCH, totals Errors1/Warnings2/
Notes0, with an unusable four-byte SXO8bc53301 and no event log or report.
All three child processes exit0. This is acceptance of one frozen negative
input/refusal/retention contract, not successful simulation or import rejection.

This directory contains all project execution code, exact parent/source,
prospective full export and complete log expectations, native raw files and
original-owner/independent receipts plus DIRECTORY-GUIDE.md. Installed tools,
manuals, SSH trust, original GUI/coordinator state and live repository freshness
are explicit host prerequisites. No vendor program/manual/credential/database or
private dump is included. All source/oracle/failure/raw evidence remains separate.

The original runID/claim/GO is consumed. Never rerun its native entry, recreate
GO, overwrite an original or change an expected result after observation. A new
native reproduction requires a new fixed version/directory/runID and all safety
and independent gates. The prior v100 adapter protocol failure and its
exact original and independent diagnostic receipts are retained under preserved-v100-evidence. This v101 changes only response integration and independent path handling, never source/oracle. Read REPRODUCE-v1.0.1.md as the canonical guide; the older template is retained for history.

Portable content replay:
  python -I -X utf8 -B replay.py <this directory>
It verifies every indexed byte, exact one-reference source derivation, full339
typed export, all13 retained raw files, complete three-stage CRLF logs, failed
result and archived custody/identity/close/queue receipts. It launches no native
process and does not recreate Windows readonly/identity/handle/queue/GUI evidence.
The original independent terminal receipt remains the OS-custody authority.

One missing BSID is not a general reference/cycle rule, wrong-type acceptance,
duplicate-import refusal, nonASCII fix, inactive-row fidelity, GUI function,
cross-engine parity, separate-agent trial, repository publication or wholeK02.
