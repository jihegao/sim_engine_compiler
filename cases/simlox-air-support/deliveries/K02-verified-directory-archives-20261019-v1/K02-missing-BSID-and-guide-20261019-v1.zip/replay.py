"""Portable full-content replay; never launches native code or recreates OS custody."""
from pathlib import Path,PurePosixPath,PureWindowsPath
import hashlib,json,re,struct,sys
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
CASE=ROOT/'K02-acceptance2-missing-BSID-v1.0.1'
def sha(r):return hashlib.sha256(r).hexdigest()
def pairs(items):
 d={}
 for k,v in items:assert k not in d,'lexical property duplicate';d[k]=v
 return d
def doc(r):return json.loads(r,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite JSON')))
def equal(a,b):
 if type(a) is not type(b):return False
 if isinstance(a,dict):return set(a)==set(b) and all(equal(a[k],b[k]) for k in a)
 if isinstance(a,list):return len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
 if isinstance(a,float):return struct.pack('>d',a)==struct.pack('>d',b)
 return a==b
def cells(d,root):return sum(len(row) for t in d[root]['tables'] for i in t['instances'] for row in i['rows'])
index=doc((ROOT/'delivery-index.json').read_bytes());assert index['schema']=='issue18-K02-active-missing-BSID-delivery/v1'
files={v['relative_path']:v for v in index['files']};assert len(files)==len(index['files'])==index['file_count']
for name,v in files.items():
 rel=PurePosixPath(name);assert not rel.is_absolute() and all(p not in ['..','.',''] for p in rel.parts) and '\\' not in name and ':' not in name
 p=ROOT.joinpath(*rel.parts);assert p.is_file() and not p.is_symlink();r=p.read_bytes();assert len(r)==v['bytes'] and sha(r)==v['sha256'],name
assert {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}==set(files)|{'delivery-index.json'}
mp=CASE/'selected-manifest-v24.json';assert sha(mp.read_bytes())=='82818f29dc999aa4f813b2db2374606bfbed2faf9dce11a23279952fd7cd90ee'
m=doc(mp.read_bytes());target=m['targets']['native'];remote=PureWindowsPath(m['working_directory'])
def mapped(v):
 rel=PureWindowsPath(v['path']).relative_to(remote);r=CASE.joinpath(*rel.parts).read_bytes()
 assert len(r)==v['bytes'] and sha(r)==v['sha256'];return r
tp=CASE/'review/independent-native-acceptance-v24.json';terminal=doc(tp.read_bytes());assert sha(tp.read_bytes())==index['terminal_sha256']
assert terminal['decision']=='ACCEPT_BOUNDED_K02_MISSING_BSID_CONVERSION_REFUSAL_AND_FAILURE_RETENTION'
assert terminal['negative_input_contract_accepted'] and not terminal['successful_model_behavior_accepted'] and terminal['successful_simulation_executions']==0
assert terminal['directory_only_cold_process_native_verified'] and terminal['actual_readonly_NTFS_metadata_queries']==26
owner=doc(mapped(terminal['owner_receipt']));r=owner['result'];children=r['Children']
assert [c['Stage'] for c in children]==['jimport_save','jexport','calc'] and [c['ExitCode'] for c in children]==[0,0,0]
assert all(c['ResumeCount']==1 and c['Signaled'] and c['ExitCodeObserved'] for c in children)
assert r['NativeSimloxCalls']==3 and r['SimulationCalls']==1 and r['ParentReruns']==0
assert r['RecoveryVerified'] and r['OriginalSealed'] and r['RawBehaviorAccepted'] and r['QueueReleasedActual'] and not r['QueueOwned'] and not r['UnknownChild'] and not r['Failed']
assert all(v['CloseAttempted'] and v['ClosedActual'] and not v['CloseUnknown'] for v in r['Handles'])
assert len(r['Handles'])==terminal['handle_records_verified']
content=doc((CASE/'content-contract-v1.json').read_bytes());assert sha((CASE/'content-contract-v1.json').read_bytes())==m['component_binding_sha256']
refs={}
for name,v in content['references'].items():
 data=(CASE/v['relative_path']).read_bytes();assert len(data)==v['bytes'] and sha(data)==v['sha256'];refs[name]=data
rawdir=CASE/'runs'/target['run_id'];names={p.name for p in rawdir.iterdir()}
assert names==set(content['raw_payload']) and len(names)==13
originals={v['Name']:v for v in r['Originals']};copies={v['Name']:v for v in r['Recovered']}
assert names==set(originals)==set(copies)=={v['name'] for v in terminal['complete_raw_pairs']}
payload={}
for name in names:
 raw=(rawdir/name).read_bytes();a=originals[name];b=copies[name]
 assert sha(raw)==a['Sha']==b['Sha'] and len(raw)==a['Bytes']==b['Bytes']
 assert (a['Volume'],a['Id'])!=(b['Volume'],b['Id']) and a['Attributes']&1 and b['Attributes']&1
 payload[name]=raw
assert sha(payload['input.json'])==m['input_sha256']=='18bcf7b7cb4502e1238ab9c3e42d82096adcb62eb593b998784871b9c49a5db3'
source=doc(payload['input.json']);table=next(t for t in source['model']['tables'] if t['name']=='System');j=next(j for j,c in enumerate(table['columns']) if c['name']=='BSID')
assert len(table['instances'])==1 and table['instances'][0]['instance_name']=='' and len(table['instances'][0]['rows'])==1
assert table['instances'][0]['rows'][0][0]=='TEACH-AIR-01' and table['instances'][0]['rows'][0][j]=='K02-NO-SUCH'
assert all(row[0]!='K02-NO-SUCH' for t in source['model']['tables'] if t['name']=='System' for i in t['instances'] for row in i['rows'])
table['instances'][0]['rows'][0][j]=None;parent=(CASE/'source-snapshots/parent-input.json').read_bytes()
assert (json.dumps(source,ensure_ascii=False,indent=2)+'\n').encode()==parent and sha(parent)=='8bbd31d05630cc4a44c4b03b715d17e2f4a1ee1601352952089efd3e584f98b7'
exported=doc(payload['roundtrip-raw.json']);assert equal(exported,doc(refs['roundtrip-raw.json'])) and cells(exported,'model')==terminal['export_cells']==339
assert payload['model.sxo']==bytes.fromhex('8bc53301')
assert set(content['forbidden_files']).isdisjoint(names)
physical=str(PureWindowsPath(target['physical_directory']))
for name in ['import.log','export.log','run.log']:
 shape=bytes.fromhex(content['run_log_shape_hex'] if name=='run.log' else content['log_shapes_hex'][name])
 expanded=shape.replace(b'@RUN@\\',physical.encode()+b'\\').replace(b'@RUN@/',physical.replace('\\','/').encode()+b'/')
 assert b'@RUN@' not in expanded
 expr=re.escape(expanded).replace(re.escape(b'@ELAPSED@'),rb'[0-9]+\.[0-9]+')
 raw=payload[name];assert raw.endswith(b'\r\n') and not re.search(rb'[\r\n]',raw.replace(b'\r\n',b''))
 assert re.fullmatch(expr,raw),name
assert b'rec 1: (error #18) Unknown base system identifier (BSID):  K02-NO-SUCH\r\n' in payload['run.log']
assert b'Input conversion completed. Errors: 1, Warnings: 2, Notes: 0\r\n' in payload['run.log']
assert b'Starting simulation' not in payload['run.log'] and b'Saving results' not in payload['run.log']
for stage in ['jimport_save','jexport','calc']:assert not payload[stage+'-stderr.bin']
assert terminal['failed_result']['bytes']==4 and terminal['failed_result']['sha256']==sha(payload['model.sxo'])
assert not terminal['behavioral_report_present'] and not terminal['behavioral_event_log_present'] and terminal['jsonreport_invocations']==0
repair=doc((CASE/'review/adapter-repair-evidence-v1.json').read_bytes());assert repair['native_calls']==0 and repair['source_and_complete_oracles_byte_equal'] and not repair['prior_prepare_or_native_retried'] and not repair['source_payload_or_oracle_modified']
prior=doc(mapped(repair['prior_records'][2]));assert not prior['adapter_end_to_end_accepted'] and prior['negative_raw_content_accepted']
assert (CASE/'REPRODUCE-v1.0.1.md').is_file()
print(json.dumps({'decision':'ACCEPT_PORTABLE_ACTIVE_MISSING_BSID_NATIVE_REFUSAL_AND_FAILURE_CONTENT_REPLAY','files_checked':len(files),'source_reconstructed':True,'export_cells':339,'raw_files':13,'full_stage_logs':3,'native_error_code':18,'converter_errors':1,'converter_warnings':2,'converter_notes':0,'failed_result_bytes':4,'behavioral_event_log_present':False,'behavioral_report_present':False,'successful_simulation_executions':0,'actual_native_calls_this_replay':0,'original_OS_custody_recreated':False,'new_agent_trial_inferred':False,'whole_K02_complete':False,'whole_issue_complete':False},indent=2))
