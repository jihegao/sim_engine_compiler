# K02 finite numeric-null native exchange delivery

The folder contains the exact source, prospectively frozen complete export,
case-local project execution code, full raw native outputs/logs, owner receipts,
independent acceptance and DIRECTORY-GUIDE.md for one integer/double blank-column
omission case. SIMLOX LINDX(integer)/MANHC(double) metadata and four authored nulls
were omitted; all 381 full exported cells, including restored nulls, were accepted.
Import-save and export ran once each with natural exit0; calc was not called.

Installed vendor tools, manuals, SSH trust and credentials are not included.
The original runID/claim/GO is consumed: NEVER rerun the archived native entry,
recreate GO or overwrite preparation/results. A new native reproduction requires
its own frozen version/paths/runID and the existing independent safety gates.

Portable content replay: python -I -X utf8 -B replay.py <this directory>
This checks every indexed byte, exact source derivation, complete381 typed export,
full CRLF stage logs and the archived owner/acceptance receipt content. It launches
no native process and does not recreate Windows attributes, handle identity,
GUI state or serial queue ownership; the original independent receipt proves them.

Only optional blank LINDX/MANHC omission in the declared two named instances is
accepted. General default expansion, required keys, inactive rows, nonASCII,
error rejection, simulation/cross-engine behavior and separate-agent trial remain
outside this acceptance. Whole K02/Issue18 and repository publication are incomplete.
