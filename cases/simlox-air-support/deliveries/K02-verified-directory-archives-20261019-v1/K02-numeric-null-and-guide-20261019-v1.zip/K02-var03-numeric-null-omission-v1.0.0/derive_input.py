from pathlib import Path
import argparse,hashlib,json
CASE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
assert a.output.parent.resolve()==(CASE/'review').resolve()
r=(CASE/'source-snapshots/parent-input.json').read_bytes()
assert hashlib.sha256(r).hexdigest()=='178b4230dc6264de739320bd044dd389424609be27603555dee177bdd33a3e99'
d=json.loads(r);t=next(t for t in d['model']['tables'] if t['name']=='Station')
for j in sorted([j for j,c in enumerate(t['columns']) if c['name'] in ['LINDX','MANHC']],reverse=True):
 t['columns'].pop(j)
 for i in t['instances']:assert i['rows'][0].pop(j) is None
out=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode()
assert hashlib.sha256(out).hexdigest()=='61f4e1efb06a4bf5ab68730ceb7878c35ef58efe494fd80850889dcf77aeed21' and out==(CASE/'native-input.json').read_bytes()
with a.output.open('xb') as f:f.write(out)
print(json.dumps({'source_sha256':hashlib.sha256(out).hexdigest(),'native_calls':0}))
