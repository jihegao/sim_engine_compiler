"""Independent immutable native-diagnostic reader; imports no producer checker."""
from pathlib import Path
import argparse,ctypes,datetime,hashlib,json,re,struct,subprocess
from ctypes import wintypes
CASE=Path(__file__).resolve().parent
M='17069c90545b9ecb7dd403c87f10e9fb171d795ecc506bd030cdf3c5b7d55881'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pin(p):
    raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':sha(raw)}
def bound(v):
    p=Path(v['path']);assert pin(p)=={k:v[k] for k in ['path','bytes','sha256']};return p.read_bytes()
def properties(items):
    d={}
    for k,v in items:assert k not in d,'lexical property duplicate';d[k]=v
    return d
def document(raw):return json.loads(raw,object_pairs_hook=properties,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite JSON')))
def equal(a,b):
    if type(a) is not type(b):return False
    if isinstance(a,dict):return set(a)==set(b) and all(equal(a[k],b[k]) for k in a)
    if isinstance(a,list):return len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
    if isinstance(a,float):return struct.pack('>d',a)==struct.pack('>d',b)
    return a==b
def cells(d):return sum(len(row) for t in d['model']['tables'] for i in t['instances'] for row in i['rows'])
def save(p,d):
    with p.open('x',encoding='utf-8') as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')

class FT(ctypes.Structure):_fields_=[('low',wintypes.DWORD),('high',wintypes.DWORD)]
class INFO(ctypes.Structure):
    _fields_=[('attributes',wintypes.DWORD),('creation',FT),('access',FT),('write',FT),('volume',wintypes.DWORD),('size_high',wintypes.DWORD),('size_low',wintypes.DWORD),('links',wintypes.DWORD),('id_high',wintypes.DWORD),('id_low',wintypes.DWORD)]
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.CreateFileW.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p,wintypes.DWORD,wintypes.DWORD,wintypes.HANDLE];k.CreateFileW.restype=wintypes.HANDLE
k.GetFileInformationByHandle.argtypes=[wintypes.HANDLE,ctypes.POINTER(INFO)];k.GetFileInformationByHandle.restype=wintypes.BOOL
k.CloseHandle.argtypes=[wintypes.HANDLE];k.CloseHandle.restype=wintypes.BOOL
k.OpenMutexW.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.LPCWSTR];k.OpenMutexW.restype=wintypes.HANDLE
def actual_file_identity(p):
    h=k.CreateFileW(str(p),0x80,1,None,3,0x00200000,None)
    assert h and h!=ctypes.c_void_p(-1).value,('read-only metadata open',str(p),ctypes.get_last_error())
    try:
        i=INFO();assert k.GetFileInformationByHandle(h,ctypes.byref(i))
        assert i.links==1 and not i.attributes&0x410 and i.attributes&1
        return {'Volume':i.volume,'Id':(i.id_high<<32)|i.id_low,'Creation':(i.creation.high<<32)|i.creation.low,'Bytes':(i.size_high<<32)|i.size_low,'Attributes':i.attributes}
    finally:assert k.CloseHandle(h),'independent metadata H close failure'

def main():
    p=argparse.ArgumentParser();p.add_argument('--controller',type=Path,required=True);p.add_argument('--controller-sha',required=True);a=p.parse_args()
    assert a.controller.parent==CASE/'review' and re.fullmatch('[0-9a-f]{64}',a.controller_sha)
    controller_pin=pin(a.controller);assert controller_pin['sha256']==a.controller_sha
    controller=document(a.controller.read_bytes());assert controller['retries']==0 and controller['native_dispatch_attempted'] is True
    mp=CASE/'selected-manifest-v21.json';assert pin(mp)['sha256']==M
    m=document(mp.read_bytes());t=m['targets']['native'];rawdir=Path(t['physical_directory']);recovered=Path(t['recovered_directory'])
    owner_pin=controller['owner_receipt'];owner=document(bound(owner_pin));r=owner['result']
    assert owner['manifest_sha256']==M and owner['run_id']==t['run_id'] and owner['mode']=='native'
    for key in ['RawOwned','RecoveredOwned','OriginalSealed','RecoveryVerified','QueueReleaseAttempted','QueueReleasedActual']:assert r[key] is True,key
    assert r['UnknownChild'] is False and r['QueueOwned'] is False
    children=r['Children'];assert 1<=len(children)<=2 and r['NativeSimloxCalls']==len(children) and r['SimulationCalls']==0 and r['ParentReruns']==0
    assert [c['Stage'] for c in children]==['jimport_save','jexport'][:len(children)]
    identities=owner['independent_suspended_identity'];assert len(identities)==len(children)
    for child in children:
        for field in ['CreateAttempted','CreateReturned','Created','ResumeAttempted','ResumeReturned','Signaled','IdentityBeforeResume','IdentityAfterSignal','ExitCodeObserved']:assert child[field] is True,(child['Stage'],field)
        assert child['ResumeCount']==1 and child['Session']==0 and child['ImagePath'].lower()==m['exe']['path'].lower()
        rows=[row for row in identities if row['pid']==child['Pid'] and int(row['creation_filetime'])==child['Creation']]
        assert len(rows)==1 and rows[0]['observed_before_resume'] is True and rows[0]['path'].lower()==m['exe']['path'].lower()
        assert 0<=child['ExitCode']<=0xffffffff
    assert len({(c['Pid'],c['Creation']) for c in children})==len(children)
    if children[0]['ExitCode']!=0:assert len(children)==1
    if len(children)==2:assert children[0]['ExitCode']==0
    handles=r['Handles'];assert handles and all(h['CloseAttempted'] is True and h['ClosedActual'] is True and h['CloseUnknown'] is False for h in handles)
    assert sum(h['Role'].startswith('Process:') for h in handles)==len(children)
    assert sum(h['Role'].startswith('Thread:') for h in handles)==len(children)
    content=document((CASE/'content-contract-v1.json').read_bytes());assert pin(CASE/'content-contract-v1.json')['sha256']==m['component_binding_sha256']
    allowed=set(content['raw_payload']);names={p.name for p in rawdir.iterdir()}
    assert names=={p.name for p in recovered.iterdir()} and names<=allowed and 'input.json' in names
    for child in children:
        assert {child['Stage']+'-stdout.bin',child['Stage']+'-stderr.bin'}<=names
    originals={v['Name']:v for v in r['Originals']};copies={v['Name']:v for v in r['Recovered']};assert set(originals)==set(copies)==names
    payload={};pairs=[]
    for name in sorted(names):
        op=originals[name];cp=copies[name];left=rawdir/name;right=recovered/name;x=left.read_bytes();y=right.read_bytes()
        assert x==y and sha(x)==op['Sha']==cp['Sha'] and len(x)==op['Bytes']==cp['Bytes']
        li=actual_file_identity(left);ri=actual_file_identity(right)
        assert all(li[key]==op[key] and ri[key]==cp[key] for key in li)
        assert (li['Volume'],li['Id'])!=(ri['Volume'],ri['Id'])
        payload[name]=x;pairs.append({'name':name,'bytes':len(x),'sha256':sha(x),'full_byte_equality':True,'actual_NTFS_readonly_original_and_recovery_identity_verified':True})
    assert sha(payload['input.json'])==m['input_sha256']=='61f4e1efb06a4bf5ab68730ceb7878c35ef58efe494fd80850889dcf77aeed21'
    parent=(CASE/'source-snapshots/parent-input.json').read_bytes();source=document(payload['input.json'])
    table=next(t for t in source['model']['tables'] if t['name']=='Station')
    assert [i['instance_name'] for i in table['instances']]==['K02-BASE','K02-AUX']
    assert not {'LINDX','MANHC'}&{c['name'] for c in table['columns']}
    for j,col in [(6,{'datatype':'integer','name':'LINDX'}),(7,{'datatype':'double','name':'MANHC'})]:
        table['columns'].insert(j,col)
        for i in table['instances']:assert len(i['rows'])==1;i['rows'][0].insert(j,None)
    assert (json.dumps(source,ensure_ascii=False,indent=2)+'\n').encode()==parent
    assert sha(parent)=='178b4230dc6264de739320bd044dd389424609be27603555dee177bdd33a3e99'
    refs={name:bound({'path':str(CASE/v['relative_path']),'bytes':v['bytes'],'sha256':v['sha256']}) for name,v in content['references'].items()}
    statuses=[c['ExitCode'] for c in children];assert statuses==[0,0] and names==allowed
    exported=document(payload['roundtrip-raw.json']);assert equal(exported,document(refs['expected-export.json']))
    full_cells=cells(exported);assert full_cells==381
    table=next(t for t in exported['model']['tables'] if t['name']=='Station')
    assert [i['instance_name'] for i in table['instances']]==['','K02-BASE','K02-AUX']
    for name,datatype in [('LINDX','integer'),('MANHC','double')]:
        j=next(j for j,c in enumerate(table['columns']) if c['name']==name)
        assert table['columns'][j]=={'name':name,'datatype':datatype}
        assert all(i['rows'][0][j] is None for i in table['instances'])
    classification='INTEGER_DOUBLE_NULL_OMISSION_RESTORED';matched=True;parse_error=None
    logs={}
    for kind in ['import','export']:
        name=kind+'.log'
        if name not in payload:logs[kind]={'present':False};continue
        raw=payload[name];lines=raw.splitlines(keepends=True);prefix=b'Importing data from Json file: ' if kind=='import' else b'Exporting data to Json file: '
        path=rawdir/('input.json' if kind=='import' else 'roundtrip-raw.json');end=b'Import' if kind=='import' else b'Export'
        crlf=raw.endswith(b'\r\n') and not re.search(rb'[\r\n]',raw.replace(b'\r\n',b''))
        body=lines[1:-1]==refs['parent-'+kind+'.log'].splitlines(keepends=True)[1:-1]
        grammar=bool(lines and re.fullmatch(end+rb' completed! Time: (?:0|[1-9][0-9]*)\.[0-9]{2} secs\r\n',lines[-1]))
        logs[kind]={'present':True,'bytes':len(raw),'sha256':sha(raw),'complete_lines':len(lines),'strict_CRLF_with_final_terminator':bool(crlf),'exact_physical_path':bool(lines and lines[0]==prefix+str(path).encode()+b'\r\n'),'completion_grammar':grammar,'body_equals_parent':body,'full_raw_retained':True}
    assert statuses==[0,0] and full_cells==381 and names==allowed and len(payload['model.sxi'])>4
    assert all(not payload[c['Stage']+'-stderr.bin'] for c in children)
    assert all(v['strict_CRLF_with_final_terminator'] and v['exact_physical_path'] and v['completion_grammar'] and v['body_equals_parent'] for v in logs.values())
    assert r['RawBehaviorAccepted'] is True and r['Failed'] is False
    assert controller['transport_exit_code']==0 and not controller['transport_stderr']
    for value in m['sources']:bound(value)
    bp=CASE/'directory-entry-binding-v1.json';permission=document(bound(controller['permission']));assert pin(bp)==permission['directory_entry_binding']
    for value in document(bp.read_bytes())['files']:
        raw=(CASE/value['relative_path']).read_bytes();assert len(raw)==value['bytes'] and sha(raw)==value['sha256']
    invocation_path=CASE/'review/directory-native-invocation-v1.json';invocation=document(invocation_path.read_bytes())
    assert invocation['cwd']=='C:/Windows/Temp' and invocation['command'][5]==str(CASE/'directory_native_once.py')
    assert invocation['retries']==0 and invocation['command'][:5]==[m['python']['path'],'-I','-X','utf8','-B']
    ps=r'''$g=@(Get-Process Simlox -ErrorAction SilentlyContinue);if($g.Count -ne 1){throw 'unexpected native process set'};$g|ForEach-Object{[ordered]@{pid=$_.Id;session=$_.SessionId;creation_filetime=$_.StartTime.ToUniversalTime().ToFileTimeUtc().ToString();path=$_.Path;responding=$_.Responding}}|ConvertTo-Json -Compress'''
    status=subprocess.run([m['powershell']['path'],'-NoProfile','-NonInteractive','-Command',ps],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=20)
    assert status.returncode==0 and not status.stderr;gui=document(status.stdout)
    assert gui['pid']==13340 and gui['session']==1 and gui['creation_filetime']=='134350637968261381' and gui['responding'] is True and gui['path']==m['exe']['path']
    ctypes.set_last_error(0);h=k.OpenMutexW(0x00100000,False,r'Global\SimloxIssue18NativeQueue');error=ctypes.get_last_error()
    if h:assert k.CloseHandle(h)
    assert not h and error==2
    receipt={'schema':'issue18-independent-K02-numeric-null-native-acceptance/v1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'terminal':True,'completed':True,'decision':'ACCEPT_BOUNDED_INTEGER_DOUBLE_NULL_OMISSION_NATIVE_EXCHANGE','classification':classification,'run_id':t['run_id'],'manifest':pin(mp),'independent_reader':pin(Path(__file__)),'controller':controller_pin,'owner_receipt':owner_pin,'directory_invocation':pin(invocation_path),'directory_entry_binding':pin(bp),'actual_native_stages':[{'stage':c['Stage'],'pid':c['Pid'],'creation_filetime':str(c['Creation']),'exit_code':c['ExitCode'],'single_resume_count':c['ResumeCount']} for c in children],'actual_native_calls':len(children),'actual_simulation_calls':0,'parent_or_control_reruns':0,'full_typed_export_cells':full_cells,'complete_original_recovered_pairs':pairs,'actual_readonly_NTFS_metadata_queries':2*len(pairs),'owner_handle_records_closed_actual':len(handles),'all_owner_handles_closed_actual':True,'source_roles_rechecked':len(m['sources']),'full_logs':logs,'parse_error':parse_error,'native_owner_failed':r['Failed'],'native_owner_failure':r.get('Failure'),'native_queue_release_actual':True,'native_queue_OpenExisting_after':{'exists':False,'last_error':2,'ownership_changed':False},'protected_GUI_final':gui,'native_behavior_acceptance':True,'business_key_cause_confirmed_from_status_alone':False,'original_duplicate_rejection_oracle':'HOLD_UNCHANGED','wrong_type_original_contract':'NO_GO_UNCHANGED','settings_changed':False,'publication_GO':False,'whole_K02_complete':False,'whole_issue_complete':False,'denominator':None,'limitations':['Only LINDX integer/MANHC double blank-column omission in these two named Station instances; no non-null default or required-key claim','Full381 typed model and original logs frozen before native; no oracle fitting','No simulation, inactive-row losslessness, IR/Rust/MLIR equivalence or separate-agent trial','Prior nonASCII/wrong-type NO_GO and duplicate import oracle HOLD unchanged']}
    rp=CASE/'review/independent-native-acceptance-v21.json';save(rp,receipt)
    print(json.dumps({'utc':receipt['utc'],'decision':receipt['decision'],'classification':classification,'terminal_receipt':pin(rp),'actual_native_calls':len(children),'actual_simulation_calls':0,'stages':receipt['actual_native_stages'],'full_typed_export_cells':full_cells,'raw_pairs':len(pairs),'owner_handles_closed_actual':len(handles),'full_logs':logs,'native_queue_released':True,'GUI':gui,'native_behavior_acceptance':True,'original_duplicate_rejection_oracle':'HOLD_UNCHANGED'},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
