# K02 finite integer/double null omission exchange

This folder contains all project execution sources and frozen full export oracle.
Host prerequisites remain the pinned installed SIMLOX, x64 compiler, Python,
existing SSH trust and protected original GUI/coordinator state. No author scratch
directory is needed. Use isolated Python (-I -X utf8 -B) from C:/Windows/Temp.

Read contract.json and selected-manifest-v21.json. Two optional Station columns,
LINDX(integer) and MANHC(double), and their four authored nulls are omitted. The
entire prospective export remains the accepted parent's 381 typed cells: restored
schema with nulls, never zero or inferred calculation defaults. The native stages
are import-save then export; no calc, settings changes or parent/control reruns.

1. Verify every pinned source and independent static/ABI receipt.
2. Run derive_input.py --output <this-folder>/review/directory-derived-input-v1.json.
3. Run directory_preflight.py, a pure guarded SSH check with no native children.
4. Independent review must bind the real preflight, directory entries and reader
   into one new permission. Preparation alone is not native GO.
5. Run directory_native_once.py <exact-new-GO-SHA> once. Fixed runID is
   k02-numeric-null-v100-20261019-01. Existing claim or raw path means STOP.
6. accept_native.py --controller <exact-controller-path> --controller-sha <SHA>
   checks immutable native raw, both stage results, full381 model, complete logs,
   actual NTFS identities, all original closes, GUI and queue release independently.

Never reuse a consumed ID, recreate GO, change oracle after observation, kill an
unknown owner or touch the user's GUI. Keep every known failure/partial original.
An unknown lifecycle result remains in the original owner without automatic retry.
This is bounded null/omission exchange, not general default expansion, inactive
rows, nonASCII, whole K02, cross-engine or separate-agent acceptance.
