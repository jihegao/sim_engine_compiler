"""Portable immutable content replay. Never imports a native runner or uses OS custody APIs."""
from pathlib import Path,PurePosixPath,PureWindowsPath
import hashlib,json,re,struct,sys
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
CASE=ROOT/'K02-var03-numeric-null-omission-v1.0.0'
def sha(r):return hashlib.sha256(r).hexdigest()
def properties(items):
 d={}
 for k,v in items:assert k not in d,'lexical property duplicate';d[k]=v
 return d
def doc(r):return json.loads(r,object_pairs_hook=properties,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite JSON')))
def equal(a,b):
 if type(a) is not type(b):return False
 if isinstance(a,dict):return set(a)==set(b) and all(equal(a[k],b[k]) for k in a)
 if isinstance(a,list):return len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
 if isinstance(a,float):return struct.pack('>d',a)==struct.pack('>d',b)
 return a==b
index=doc((ROOT/'delivery-index.json').read_bytes());assert index['schema']=='issue18-K02-numeric-null-delivery/v1'
files={v['relative_path']:v for v in index['files']};assert len(files)==len(index['files'])==index['file_count']
for name,v in files.items():
 rel=PurePosixPath(name);assert not rel.is_absolute() and all(p not in ['.','..',''] for p in rel.parts) and '\\' not in name and ':' not in name
 p=ROOT.joinpath(*rel.parts);assert p.is_file() and not p.is_symlink();r=p.read_bytes();assert len(r)==v['bytes'] and sha(r)==v['sha256'],name
assert {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}==set(files)|{'delivery-index.json'}
mp=CASE/'selected-manifest-v21.json';assert sha(mp.read_bytes())=='17069c90545b9ecb7dd403c87f10e9fb171d795ecc506bd030cdf3c5b7d55881'
m=doc(mp.read_bytes());target=m['targets']['native'];remote=PureWindowsPath(m['working_directory'])
def mapped(v):
 rel=PureWindowsPath(v['path']).relative_to(remote);r=CASE.joinpath(*rel.parts).read_bytes()
 assert len(r)==v['bytes'] and sha(r)==v['sha256'];return r
tp=CASE/'review/independent-native-acceptance-v21.json';terminal=doc(tp.read_bytes())
assert sha(tp.read_bytes())==index['terminal_sha256'] and terminal['native_behavior_acceptance'] is True
assert terminal['decision']=='ACCEPT_BOUNDED_INTEGER_DOUBLE_NULL_OMISSION_NATIVE_EXCHANGE'
assert terminal['original_duplicate_rejection_oracle']=='HOLD_UNCHANGED' and terminal['wrong_type_original_contract']=='NO_GO_UNCHANGED'
owner=doc(mapped(terminal['owner_receipt']));r=owner['result'];children=r['Children']
assert [c['Stage'] for c in children]==['jimport_save','jexport'] and [c['ExitCode'] for c in children]==[0,0]
assert all(c['ResumeCount']==1 and c['Signaled'] and c['ExitCodeObserved'] for c in children)
assert r['NativeSimloxCalls']==2 and r['SimulationCalls']==0 and r['ParentReruns']==0
assert r['RecoveryVerified'] and r['OriginalSealed'] and r['RawBehaviorAccepted'] and r['QueueReleasedActual'] and not r['QueueOwned'] and not r['Failed'] and not r['UnknownChild']
assert all(h['CloseAttempted'] and h['ClosedActual'] and not h['CloseUnknown'] for h in r['Handles'])
assert len(r['Handles'])==terminal['owner_handle_records_closed_actual']
content=doc((CASE/'content-contract-v1.json').read_bytes());assert sha((CASE/'content-contract-v1.json').read_bytes())==m['component_binding_sha256']
refs={}
for name,v in content['references'].items():
 raw=(CASE/v['relative_path']).read_bytes();assert len(raw)==v['bytes'] and sha(raw)==v['sha256'];refs[name]=raw
rawdir=CASE/'runs'/target['run_id'];names={p.name for p in rawdir.iterdir()}
assert names==set(content['raw_payload']) and len(names)==9
originals={v['Name']:v for v in r['Originals']};copies={v['Name']:v for v in r['Recovered']}
assert set(originals)==set(copies)==names=={v['name'] for v in terminal['complete_original_recovered_pairs']}
payload={}
for name in names:
 data=(rawdir/name).read_bytes();a=originals[name];b=copies[name]
 assert sha(data)==a['Sha']==b['Sha'] and len(data)==a['Bytes']==b['Bytes']
 assert (a['Volume'],a['Id'])!=(b['Volume'],b['Id']) and a['Attributes']&1 and b['Attributes']&1
 payload[name]=data
assert sha(payload['input.json'])==m['input_sha256']=='61f4e1efb06a4bf5ab68730ceb7878c35ef58efe494fd80850889dcf77aeed21'
source=doc(payload['input.json']);t=next(t for t in source['model']['tables'] if t['name']=='Station')
assert not {'LINDX','MANHC'}&{c['name'] for c in t['columns']}
for j,col in [(6,{'datatype':'integer','name':'LINDX'}),(7,{'datatype':'double','name':'MANHC'})]:
 t['columns'].insert(j,col)
 for i in t['instances']:assert len(i['rows'])==1;i['rows'][0].insert(j,None)
parent=(CASE/'source-snapshots/parent-input.json').read_bytes()
assert (json.dumps(source,ensure_ascii=False,indent=2)+'\n').encode()==parent and sha(parent)=='178b4230dc6264de739320bd044dd389424609be27603555dee177bdd33a3e99'
model=doc(payload['roundtrip-raw.json']);assert equal(model,doc(refs['expected-export.json']))
cells=sum(len(row) for t in model['model']['tables'] for i in t['instances'] for row in i['rows'])
assert cells==terminal['full_typed_export_cells']==381
t=next(t for t in model['model']['tables'] if t['name']=='Station')
for name,typ in [('LINDX','integer'),('MANHC','double')]:
 j=next(j for j,c in enumerate(t['columns']) if c['name']==name);assert t['columns'][j]=={'name':name,'datatype':typ}
 assert all(i['rows'][0][j] is None for i in t['instances'])
for kind in ['import','export']:
 data=payload[kind+'.log'];lines=data.splitlines(keepends=True);v=terminal['full_logs'][kind]
 assert sha(data)==v['sha256'] and len(data)==v['bytes'] and len(lines)==v['complete_lines']
 assert data.endswith(b'\r\n') and not re.search(rb'[\r\n]',data.replace(b'\r\n',b''))
 prefix=b'Importing data from Json file: ' if kind=='import' else b'Exporting data to Json file: '
 file='input.json' if kind=='import' else 'roundtrip-raw.json'
 assert lines[0]==prefix+str(PureWindowsPath(target['physical_directory'])/file).encode()+b'\r\n'
 end=b'Import' if kind=='import' else b'Export'
 assert re.fullmatch(end+rb' completed! Time: (?:0|[1-9][0-9]*)\.[0-9]{2} secs\r\n',lines[-1])
 assert lines[1:-1]==refs['parent-'+kind+'.log'].splitlines(keepends=True)[1:-1]
assert all(not payload[s+'-stderr.bin'] for s in ['jimport_save','jexport'])
print(json.dumps({'decision':'ACCEPT_PORTABLE_NUMERIC_NULL_SOURCE_AND_COMPLETE_NATIVE_RAW_REPLAY','files_checked':len(files),'source_reconstructed':True,'full_typed_export_cells':cells,'raw_files':9,'full_logs':2,'actual_native_calls_this_replay':0,'original_OS_custody_recreated':False,'new_agent_trial_inferred':False,'whole_K02_complete':False,'whole_issue_complete':False},indent=2))
