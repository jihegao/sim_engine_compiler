"""One actual guarded pure SSH preflight. No native process invocation."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

CASE=Path(__file__).resolve().parent
MODE='preflight'
MANIFEST='0c3d885b9aff212a615dfb3a99e6f590a8839cee232d40ef8e73a9876b0b1a5e'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p): return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def save(p,value):
    with p.open('x',encoding='utf-8') as stream:json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')
mp=CASE/'selected-manifest-v19.json';assert sha(mp)==MANIFEST
m=json.loads(mp.read_bytes());target=m['targets']['native']
state=json.loads(Path('C:/Users/user/Documents/Codex/issue18-local-monitor/goal-mode-20261016/state.json').read_bytes())
assert state['thread_status']['type']=='systemError' and state['root_turns_started']==state['root_turns_completed']==52
assert not state.get('pending_requests')
assert not Path(target['physical_directory']).exists() and not Path(target['recovered_directory']).exists()
review=CASE/'review/independent-preflight-go-v19.json'
permission=json.loads(review.read_bytes())
assert permission['decision']=='GO_PRELAUNCH_STATIC' and permission['manifest_sha256']==MANIFEST
assert permission['native_calls_allowed']==permission['simulation_calls_allowed']==0
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
record=CASE/('review/preflight-controller-'+stamp+'.json')
guardian=CASE/('review/guardian-preflight-'+stamp+'.json')
command=[m['powershell']['path'],'-NoProfile','-NonInteractive','-File',str(CASE/'standalone_guardian_selected_v19.ps1'),'-Mode',MODE,'-OutputPath',str(guardian),'-ExpectedManifestSha',MANIFEST]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=subprocess.run(command,capture_output=True)
result={'schema':'issue18-A01-pure-preflight-controller/v1','started_at_utc':started,'guardian_command':command,'guardian_exit_code':r.returncode,'guardian_stdout':r.stdout.decode('utf-8-sig',errors='replace'),'guardian_stderr':r.stderr.decode('utf-8-sig',errors='replace'),'original_thread_status':state['thread_status'],'original_turns':[state['root_turns_started'],state['root_turns_completed']],'native_calls':0,'simulation_calls':0}
if r.returncode!=0 or not guardian.is_file():
    result['status']='GUARDIAN_REJECTED_NO_PREFLIGHT';save(record,result);print(json.dumps({**result,'record':pin(record)},ensure_ascii=False,indent=2));sys.exit(1)
g=json.loads(guardian.read_text(encoding='utf-8-sig'));assert g['decision']=='GO_STANDALONE_SAFETY_ONLY' and g['native_calls']==0
result['guardian']=pin(guardian)
command=[m['python']['path'],'-E','-X','utf8','-B',str(CASE/'ssh_transport_selected_v19.py'),MODE,'--review-sha',sha(review),'--manifest-sha',MANIFEST,'--guardian',str(guardian),'--guardian-sha',sha(guardian)]
result['transport_command']=command
r=subprocess.run(command,capture_output=True)
result.update({'completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'transport_exit_code':r.returncode,'transport_stdout':r.stdout.decode('utf-8-sig',errors='replace'),'transport_stderr':r.stderr.decode('utf-8-sig',errors='replace'),'status':'PREFLIGHT_TRANSPORT_COMPLETED' if r.returncode==0 else 'PREFLIGHT_TRANSPORT_FAILED_NO_NATIVE','physical_directory_exists':Path(target['physical_directory']).exists(),'recovered_directory_exists':Path(target['recovered_directory']).exists()})
assert not result['physical_directory_exists'] and not result['recovered_directory_exists']
save(record,result)
print(json.dumps({**result,'record':pin(record)},ensure_ascii=False,indent=2))
sys.exit(r.returncode)
