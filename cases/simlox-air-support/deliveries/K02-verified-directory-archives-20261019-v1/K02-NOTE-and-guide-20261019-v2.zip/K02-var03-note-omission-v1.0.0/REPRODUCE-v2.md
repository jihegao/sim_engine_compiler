# 仅靠本目录和指南的全新原生复现

NOTE省略父例已独立接受，终结收据SHA256为34d4daa786f2189425c024b39cb9ac1433e329bb3f7c2a71eebab4f42c8aea00。原runID已消耗，不得重跑。

本有限入口为一次明确要求的独立新目录复现准备全新profile，不改变源输入、oracle、原始结果或过程/资源保护。不会在准备时启动SIMLOX。运行 `python -I -B prepare_guide_reproduction_v2.py --prepare`，会在同级创建尚不存在的K02-note-guide-reproduction-v1.0.0，新runID k02-note-guide-v100-20261019-01；再次准备明确失败。保留源父例全部原件。

接着只使用新目录内容和本次准备回执：

1. `python -I -B independent_static_review.py <manifest SHA> <directory-entry-binding SHA>`，复核全部来源、具体常量变化、完整预期和ABI，签发零原生调用的preflight GO。
2. `python -I -B directory_preflight.py`，得到实际纯预检的controller路径及SHA。主机安装、GUI/session、SSH0/PS5、原始执行互斥、实时refs等条件均维持。
3. `python -I -B bind_preflight.py <manifest SHA> <preflight controller path> <controller SHA> <directory-entry-binding SHA>`，独立复核实际预检后签发仅限本新runID的一次native GO，读取并外部核验该GO的SHA。
4. 从例如C:/Windows/Temp这样的无项目当前目录，运行 `python -I -B <新目录>/directory_native_once.py <native GO SHA>`。程序源及其数据仅从新目录取得，主机已安装工具/许可证/SSH信任和当前运行守护仍为显式前提。执行只有import-save/export各一次，calc0。新的native controller打印路径和SHA。
5. `python -I -B accept_native.py <manifest SHA> <native controller path> <controller SHA> <directory-entry-binding SHA>`，独立复核全部原始/恢复文件和身份、381格typed值、全日志、原始H信号/退出/关闭/队列和GUI。

任一阶段失败停止后续步骤，保留全部部分文件和真实结果；不重建GO、不复用runID、不改oracle，不自动kill/retry/release。准备成功、编译成功、原生自然exit0、独立内容/资源验收和最终发布分别判断。这里是当前Codex按目录指南的冷进程复现验证，不能据此声称新agent试用或整Issue已经完成。
