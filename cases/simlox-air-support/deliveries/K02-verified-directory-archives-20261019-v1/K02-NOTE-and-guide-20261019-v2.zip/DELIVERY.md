# K02 NOTE省略分支及目录指南原生复现交付

本包包含两个实际验收目录的项目源、完整事前oracle、原始回导/日志/流、可打开的原生SXI及独立终结收据。第一个只从两个具名Station实例省略可选NOTE文本列，原生回导完整恢复null；第二个按目录/指南在全新profile/runID中完成同源原生复现。两例各有import-save/export自然exit0、完整381格typed回导、9对原始/恢复文件、100次实际句柄关闭及NativeQueue释放。没有calc。输入174个authored行值，原生规范化完整模型381格；不能混为同一分母。

SOURCE原件与oracle未按实测修改。指南准备阶段的Windows默认GBK解码UTF8中文错误原件保留；仅补完已核验未运行目录的文档/绑定，未重跑prepare或原生attempt。源目录中当前准备器为prepare_guide_reproduction_v3.py（显式UTF8）；v1/v2为保留历史，勿作为当前入口。

运行下面的标准库内容回放不需要4700-3原作者临时项目路径，index SHA从独立交付记录取得：

```text
python -I -X utf8 -B replay.py --index-sha <交付记录中的delivery-index.json SHA256>
```

这会核对全部交付文件和两例完整原始数据/类型/二进制64/空值及日志，不执行SIMLOX，也不重新证明Windows句柄、只读属性或互斥所有权。两份已完成runID/GO均已消耗，不能重跑；新原生复现必须另建新版本、独有目录/runID和实际独立许可。原始physical/recovered证据仍在4700-3，路径和哈希见各终结收据。

4700-3原生指南见源案例的DIRECTORY-GUIDE.md和REPRODUCE-v3.md（prepare_guide_reproduction_v3.py为当前显式UTF8入口）。工具、许可证、SSH信任、实时仓库/协调状态和GUI保护仍是明确的主机前提。安装程序、专有手册和凭据没有打包。项目来源已放入案例provenance，当前工作目录为各案例本身。

本包是受限本地交付，尚未发布/合入仓库。仅证明Station.NOTE两个文本null单元格的省略/恢复和本次指南冷进程复现，不是一般null/default、数字默认值、缺键、inactive_rows或仿真语义验收。新agent试用不能从本聊天冷进程复现推断。K02非ASCII导入崩溃、wrong-QTY-type冻结合同NO_GO、duplicate oracle HOLD及缺引用import验收仍未解决；Issue18整体保持未完成。
