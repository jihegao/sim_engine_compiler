"""Portable full-source/raw replay; performs no native execution or OS replay."""
from pathlib import Path,PureWindowsPath,PurePosixPath
import argparse,hashlib,json,re,struct
def sha(raw):return hashlib.sha256(raw).hexdigest()
def typed(x):
    if isinstance(x,dict):return ('object',tuple((k,typed(v)) for k,v in sorted(x.items())))
    if isinstance(x,list):return ('array',tuple(typed(v) for v in x))
    if type(x) is float:return ('binary64',struct.pack('>d',x).hex())
    return(type(x).__name__,x)
def pairs(items):
    d={}
    for k,v in items:
        assert k not in d,'duplicate JSON property';d[k]=v
    return d
def document(raw):return json.loads(raw,object_pairs_hook=pairs)
def main():
    p=argparse.ArgumentParser();p.add_argument('--index-sha',required=True);a=p.parse_args();root=Path(__file__).resolve().parent
    index_raw=(root/'delivery-index.json').read_bytes();assert sha(index_raw)==a.index_sha
    index=document(index_raw);assert index['schema']=='issue18-K02-directory-native-delivery/v1'
    for name,v in index['files'].items():
        rel=PurePosixPath(name);assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in name
        raw=root.joinpath(*rel.parts).read_bytes();assert len(raw)==v['bytes'] and sha(raw)==v['sha256'],name
    results=[]
    for entry in index['cases']:
        case=root/entry['directory'];receipt=document((case/'review/independent-native-acceptance-v19.json').read_bytes())
        assert sha((case/'review/independent-native-acceptance-v19.json').read_bytes())==entry['terminal_sha256']
        assert receipt['actual_native_calls']==2 and receipt['actual_simulation_calls']==0
        assert receipt['all_original_handles_closed_actual'] and receipt['native_queue_release_actual']
        rawdir=case/'runs'/entry['run_id'];names={x.name for x in rawdir.iterdir()};assert len(names)==9
        for v in receipt['complete_original_recovered_pairs']:
            raw=(rawdir/v['name']).read_bytes();assert len(raw)==v['bytes'] and sha(raw)==v['sha256']
        assert sha((rawdir/'input.json').read_bytes())=='3ae6b43062876f74bcdf3e4563578759b01952bca01137bf1ee52b31666eaf17'
        actual=document((rawdir/'roundtrip-raw.json').read_bytes());expected=document((case/'oracle/expected-export.json').read_bytes())
        assert typed(actual)==typed(expected)
        count=sum(len(r) for t in actual['model']['tables'] for inst in t['instances'] for r in inst['rows']);assert count==381
        station=next(t for t in actual['model']['tables'] if t['name']=='Station');j=[c['name'] for c in station['columns']].index('NOTE')
        assert len(station['instances'])==3 and all(r[j] is None for inst in station['instances'] for r in inst['rows'])
        for kind in ['import','export']:
            raw=(rawdir/(kind+'.log')).read_bytes();old=(case/('source-snapshots/parent-'+kind+'.log')).read_bytes()
            assert raw.endswith(b'\r\n') and not re.search(rb'[\r\n]',raw.replace(b'\r\n',b''))
            lines=raw.splitlines(keepends=True);source=old.splitlines(keepends=True);assert len(lines)==len(source) and lines[1:-1]==source[1:-1]
            prefix=b'Importing data from Json file: ' if kind=='import' else b'Exporting data to Json file: '
            filename='input.json' if kind=='import' else 'roundtrip-raw.json'
            assert lines[0]==prefix+str(PureWindowsPath(receipt['physical_directory'])/filename).encode()+b'\r\n'
            end=b'Import' if kind=='import' else b'Export';assert re.fullmatch(end+rb' completed! Time: (?:0|[1-9][0-9]*)\.[0-9]{2} secs\r\n',lines[-1])
        results.append({'id':entry['directory'],'run_id':entry['run_id'],'native_receipt_content_replayed':True,'full_typed_export_cells':381,'raw_files':9,'full_logs':2})
    print(json.dumps({'decision':'PORTABLE_FULL_SOURCE_AND_NATIVE_RAW_REPLAY_ACCEPTED','cases':results,'files_checked':len(index['files']),'native_calls_this_replay':0,'original_OS_custody_recreated':False,'new_agent_trial_inferred':False,'whole_issue_complete':False},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
