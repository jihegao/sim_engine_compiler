"""Independently review the finite NOTE source/oracle and unchanged owner core."""
from pathlib import Path
import sys,ast,copy,datetime,hashlib,importlib.util,json,subprocess
CASE=Path(__file__).resolve().parent
MANIFEST=sys.argv[1]
def pin(p):
    r=p.read_bytes();return {'path':str(p),'bytes':len(r),'sha256':hashlib.sha256(r).hexdigest()}
def bound(v):
    p=Path(v['path']);assert pin(p)=={k:v[k] for k in ['path','bytes','sha256']};return p.read_bytes()
def save(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
mp=CASE/'selected-manifest-v19.json';assert pin(mp)['sha256']==MANIFEST
m=json.loads(mp.read_bytes());target=m['targets']['native']
assert not Path(target['physical_directory']).exists() and not Path(target['recovered_directory']).exists()
for v in m['sources']:bound(v)
audit=json.loads((CASE/'source-role-audit-v1.json').read_bytes())
assert audit['credentials_copied'] is False and audit['manuals_or_installers_copied'] is False
project_sources=[]
for row in audit['source_roles']:
    v=row['selected'];raw=bound(v)
    if row['classification'].startswith('PROJECT'):
        assert Path(v['path']).is_relative_to(CASE)
        assert v['bytes']==row['original']['bytes'] and v['sha256']==row['original']['sha256']
        project_sources.append(row)
    else:assert not v['path'].lower().startswith('c:\\users\\user\\documents\\codex\\')
proof=json.loads((CASE/'owner-profile-proof-v1.json').read_bytes());owner=(CASE/'selected-runner-note-v1.cs').read_text()
assert hashlib.sha256(owner.encode()).hexdigest()==proof['candidate_sha256']
for edit in reversed(proof['edits']):owner=owner.replace(edit['after'],edit['before'])
baseline=next(row for row in project_sources if row['original']['path'].endswith('K02-acceptance2-wrong-type-v1.0.0\\selected-runner-v8.cs'))
assert owner==bound(baseline['selected']).decode()
assert m['working_directory']==str(CASE)
parent=json.loads((CASE/'source-snapshots/parent-input.json').read_bytes());expected=copy.deepcopy(parent)
t=next(t for t in expected['model']['tables'] if t['name']=='Station');assert t['columns'].pop()=={'datatype':'string','name':'NOTE'}
for inst in t['instances']:
    assert len(inst['rows'])==1 and inst['rows'][0].pop() is None
source=json.loads((CASE/'native-input.json').read_bytes());assert source==expected
for name in ['check_exchange_v3.py','ssh_transport_selected_v19.py','git_ssh_bounded_v13.py']:ast.parse((CASE/name).read_text())
ps=r'''$ErrorActionPreference='Stop';$case='__CASE__';foreach($name in @('run_selected_ssh_v19.ps1','standalone_guardian_selected_v19.ps1')){$t=$null;$e=$null;$null=[Management.Automation.Language.Parser]::ParseFile((Join-Path $case $name),[ref]$t,[ref]$e);if($e.Count -ne 0){throw ($e|Out-String)}};Add-Type -Path (Join-Path $case 'review\selected-runner-note-v1.dll');[Issue18SelectedK02NoteV1.SelectedOwner]::CheckAbi();@{abi='x64_CHECKED';powershell_syntax_errors=0;native_execute_calls=0}|ConvertTo-Json -Compress'''.replace('__CASE__',str(CASE))
r=subprocess.run([m['powershell']['path'],'-NoProfile','-NonInteractive','-Command',ps],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=30);assert r.returncode==0 and not r.stderr,(r.stdout,r.stderr)
abi=json.loads(r.stdout)
spec=importlib.util.spec_from_file_location('note_content_static',CASE/'check_exchange_v3.py');checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
contract,refs=checker.load(m['component_binding_sha256'])
actual={'input.json':(CASE/'native-input.json').read_bytes(),'roundtrip-raw.json':refs['expected-export.json']}
for kind in ['import','export']:
    lines=refs['parent-'+kind+'.log'].splitlines(keepends=True)
    prefix=b'Importing data from Json file: ' if kind=='import' else b'Exporting data to Json file: '
    lines[0]=prefix+str(Path(target['physical_directory'])/('input.json' if kind=='import' else 'roundtrip-raw.json')).encode()+b'\r\n';actual[kind+'.log']=b''.join(lines)
dry=checker.verify(actual,Path(target['physical_directory']),contract,refs);assert dry['cells']==381
neg=[]
for name,raw,label in [('input.json',(CASE/'source-snapshots/parent-input.json').read_bytes(),'unmodified_parent_input'),('roundtrip-raw.json',json.dumps(expected).encode(),'omitted_column_not_restored'),('import.log',actual['import.log'].replace(b'\r\n',b'\n'),'LF_log')]:
    test=dict(actual);test[name]=raw
    try:checker.verify(test,Path(target['physical_directory']),contract,refs)
    except ValueError as error:neg.append({'control':label,'rejected':True,'reason':str(error)})
    else:raise AssertionError('Invalid control accepted '+label)
bp=CASE/'directory-entry-binding-v1.json'
assert pin(bp)['sha256']==sys.argv[2]
for v in json.loads(bp.read_bytes())['files']:
    raw=(CASE/v['relative_path']).read_bytes();assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256']
    if v['relative_path'].endswith('.py'):ast.parse(raw.decode())
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
review={'schema':'issue18-K02-NOTE-independent-static/v1','utc':now,'terminal':True,'completed':True,'decision':'GO_FIXED_PROFILE_STATIC_ONLY_NOT_NATIVE','manifest':pin(mp),'source_roles_verified':len(m['sources']),'project_source_roles_within_case':len(project_sources),'no_old_project_source_paths_required':True,'old_working_directory_required':False,'owner_source_reverse_equal':True,'owner_core_unchanged':True,'ABI':abi,'source_delta':'Only optional Station.NOTE metadata and two null authored cells omitted; all other business cells/metadata preserved','prospective_full_export_cells':381,'prospective_content_dry_run':dry,'negative_controls':neg,'new_native_calls':0,'native_GO':False,'publication_GO':False}
rp=CASE/'review/static-source-content-review-v19.json';save(rp,review)
original=m['real_benign_reuse_required']['actual_original_acceptance'];bound(original)
reuse={'schema':'issue18-K02-NOTE-exact-core-reuse/v1','utc':now,'terminal':True,'completed':True,'decision':'GO_SELECTED_REAL_BENIGN_ACCEPTED','manifest_sha256':MANIFEST,'probe0_run_id':m['targets']['probe0']['run_id'],'probe7_run_id':m['targets']['probe7']['run_id'],'actual_original_acceptance':original,'candidate_source_review':pin(rp),'scope':'Only source/profile constants and case-local cwd changed. Original two-stage process/handle/seal/queue core exact. No new harmless controls or parent/native reruns.','new_control_calls':0,'native_GO':False}
br=CASE/'review/real-benign-core-reuse-v19.json';save(br,reuse)
permit={'schema':'issue18-K02-NOTE-pure-preflight-permission/v19','utc':now,'terminal':True,'completed':True,'decision':'GO_PRELAUNCH_STATIC','mode':'preflight','run_id':target['run_id'],'manifest_sha256':MANIFEST,'benign_acceptance':pin(br),'accepted_static':pin(rp),'native_calls_allowed':0,'simulation_calls_allowed':0,'native_GO':False}
gp=CASE/'review/independent-preflight-go-v19.json';save(gp,permit)
print(json.dumps({'utc':now,'decision':review['decision'],'manifest':pin(mp),'review':pin(rp),'preflight_permission':pin(gp),'source_roles':len(m['sources']),'project_roles':len(project_sources),'full_export_cells':381,'negative_controls':neg,'native_calls':0},ensure_ascii=False,indent=2))
