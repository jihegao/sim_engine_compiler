"""Independently bind the real pure preflight to a single fixed native attempt."""
from pathlib import Path
import sys
import datetime
import hashlib
import json

CASE=Path(__file__).resolve().parent
MANIFEST=sys.argv[1]
def pin(p):
    raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def checked(value):
    p=Path(value['path']);assert pin(p)==value;return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,data):
    with p.open('x',encoding='utf-8') as stream:json.dump(data,stream,ensure_ascii=False,indent=2);stream.write('\n')
mp=CASE/'selected-manifest-v19.json';assert pin(mp)['sha256']==MANIFEST
m=json.loads(mp.read_bytes());t=m['targets']['native']
controller_pin={'path':sys.argv[2],'bytes':Path(sys.argv[2]).stat().st_size,'sha256':sys.argv[3]}
controller=checked(controller_pin)
assert controller['status']=='PREFLIGHT_TRANSPORT_COMPLETED' and controller['transport_exit_code']==0
assert controller['native_calls']==controller['simulation_calls']==0 and not controller['transport_stderr']
guardian=checked(controller['guardian'])
assert guardian['decision']=='GO_STANDALONE_SAFETY_ONLY' and guardian['terminal'] is True
assert guardian['native_calls']==0 and guardian['native_queue_free'] is True and guardian['executor_mutex_held'] is True
directory=Path(json.loads(controller['transport_stdout'])['evidence'])
assert directory.parent==CASE/'review' and directory.name.startswith('transport-preflight-')
transport_path=directory/'transport-receipt.json';transport=json.loads(transport_path.read_bytes())
assert transport['mode']=='preflight' and transport['exit_code']==0 and not transport['error'] and not transport['source_stability_error']
assert transport['manifest_sha256']==MANIFEST and transport['run_id']==t['run_id']
stdout=(directory/'stdout.bin').read_bytes().decode('utf-8-sig').strip()
assert '\n' not in stdout and '\r' not in stdout
preflight_path=Path(stdout)
assert preflight_path.parent==CASE/'review' and preflight_path.name.startswith('preflight-')
preflight=json.loads(preflight_path.read_text(encoding='utf-8-sig'))
assert preflight['decision']=='GO_PRELAUNCH_CANDIDATE' and preflight['manifest_sha256']==MANIFEST and preflight['run_id']==t['run_id']
assert preflight['native_process_started'] is False and preflight['run_directory_absent'] is True
assert preflight['ps_major']==5 and preflight['session_id']==0
assert preflight['native_queue_held'] is True and preflight['native_queue_abandoned'] is False
assert preflight['gui']==m['gui'] and preflight['settings']['read_only'] is True
assert preflight['transport_identity']['connection'].startswith('127.0.0.1 ')
assert preflight['git_freshness'] and all(x['exit_code']==0 and x['refs']==m['refs']['remote'] for x in preflight['git_freshness'])
assert not Path(t['physical_directory']).exists() and not Path(t['recovered_directory']).exists()
for value in m['sources']:
    assert pin(Path(value['path']))=={k:value[k] for k in ('path','bytes','sha256')},value['path']
static_path=CASE/'review/static-source-content-review-v19.json'
static=json.loads(static_path.read_bytes())
assert static['decision']=='GO_FIXED_PROFILE_STATIC_ONLY_NOT_NATIVE'
assert static['manifest']['sha256']==MANIFEST and static['prospective_full_export_cells']==381
assert len(static['negative_controls'])==3 and all(x['rejected'] for x in static['negative_controls'])
assert static['owner_source_reverse_equal'] is True and static['native_GO'] is False
reuse_path=CASE/'review/real-benign-core-reuse-v19.json'
reuse=json.loads(reuse_path.read_bytes())
assert reuse['manifest_sha256']==MANIFEST and reuse['new_control_calls']==0
binding_path=CASE/'directory-entry-binding-v1.json'
assert pin(binding_path)['sha256']==sys.argv[4]
for v in json.loads(binding_path.read_bytes())['files']:
    observed=pin(CASE/v['relative_path']);assert observed['bytes']==v['bytes'] and observed['sha256']==v['sha256']
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
review={'schema':'issue18-independent-K02-NOTE-actual-preflight-review/v1','utc':now,'terminal':True,'completed':True,'decision':'ACCEPT_ACTUAL_PURE_PREFLIGHT_K02_NOTE_TWO_STAGE','manifest':pin(mp),'controller':controller_pin,'preflight':pin(preflight_path),'preflight_transport':pin(transport_path),'standalone_guardian':controller['guardian'],'accepted_static':pin(static_path),'benign_reuse':pin(reuse_path),'source_roles_rechecked':len(m['sources']),'native_calls':0,'native_GO_from_this_review':False,'whole_scope_complete':False,'denominator':None}
review_path=CASE/'review/actual-preflight-review-v19.json';save(review_path,review)
go={'schema':'issue18-independent-K02-NOTE-single-native-permission/v19','utc':now,'terminal':True,'completed':True,'decision':'GO_PRELAUNCH','mode':'native','run_id':t['run_id'],'manifest_sha256':MANIFEST,'manifest':pin(mp),'benign_acceptance':pin(reuse_path),'preflight':pin(preflight_path),'preflight_transport':pin(transport_path),'actual_preflight_acceptance':pin(review_path),'accepted_static':pin(static_path),'directory_entry_binding':pin(binding_path),'attempt_limit':1,'attempt_claim_path':str(CASE/'review/native-attempt-claim-v19.json'),'allowed_stages':['jimport_save','jexport'],'simulation_calls_allowed':0,'maximum_native_child_creations':2,'threads':1,'accepted_parent_or_control_reruns_allowed':0,'execution_role':'One user-required guide-only new-directory reproduction of the accepted K02 NOTE source; source unchanged, no calculation','conditions':['Fresh terminal native-mode standalone guardian immediately before the single plain selected SSH dispatch','All existing GUI/WTS/SSH0/identity/source/tool/ref/settings and normal serial NativeQueue guards remain mandatory','Any stage failure stops later stages; retain all actual originals and partials with exact custody','Unknown signal/identity/close/queue retains owning stack, no kill/retry/release authority','Complete9-file native payload and independent full source/report/event/log/endstate/resource acceptance required'],'publication_GO':False,'whole_scope_complete':False,'denominator':None}
go_path=CASE/'review/independent-native-go-v19.json';save(go_path,go)
print(json.dumps({'observed_at_utc':now,'decision':review['decision'],'actual_preflight_review':pin(review_path),'single_attempt_permission':pin(go_path),'new_native_calls':0,'whole_scope_complete':False},ensure_ascii=False,indent=2))
