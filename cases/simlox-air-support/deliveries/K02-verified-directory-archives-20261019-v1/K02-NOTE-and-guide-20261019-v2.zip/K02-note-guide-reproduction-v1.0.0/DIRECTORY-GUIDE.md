# K02.var03：省略可选NOTE列的原生交换

本受限案例研究两个具名Station实例的NOTE空白列是否可以省略，并由SIMLOX原生回导恢复为null。只删一项string列元数据和两个null值；业务键、引用、所有其他类型/值和DTIM binary64不变。完整事前oracle为381个回导单元格，包含已冻结的原生空白默认Station实例。失败结果保留，不能用它修订oracle。不是一般空值/默认值规则，未运行仿真。

项目代码、原始父输入、oracle、日志模板及历史证明原字节位于本目录，provenance下按source-role-audit-v1.json定位。运行工作目录为案例自身。主机前提仍包括已安装的SIMLOX2017、Windows PS5、既有Python/Git/SSH、现有许可证和SSH信任；不复制安装文件、手册或凭据。实时仓库索引/目录/refs与GUI身份/会话/执行互斥仍按既有守护核实。

使用已安装Python（3.12.14）执行如下目录入口，从任何当前目录均可。入口使用文件自身位置，命令不依赖原作者临时项目路径。

1. `python -I -B derive_input.py --output <不存在的新文件>` 仅靠父输入重新派生本例，指纹应为3ae6b43062876f74bcdf3e4563578759b01952bca01137bf1ee52b31666eaf17。拒绝覆盖文件。
2. 完整来源/预期/ABI独立静态复核后，`python -I -B directory_preflight.py` 执行独立守护和纯SSH0/PS5预检，不调用SIMLOX。没有匹配的独立preflight GO时必须停止。
3. 独立核验真实预检并签发精确单次native GO后，`python -I -B directory_native_once.py <外部核验的native GO SHA256>` 正常串行执行import-save与export。无calc、无父例/控制重跑；四类原始流保留，9文件封存与恢复。未知身份、信号、关闭或队列状态保留原owner，不自动kill/retry/release。
4. 独立验收必须逐字节/哈希/身份复核原始和恢复集合，完整381格类型/空值/二进制64、全日志CRLF与精确body、原始H信号/退出/关闭及队列释放，并核验原GUI不变。exit0本身不代表通过。

本版固定runID k02-note-guide-v100-20261019-01，只允许首次独立许可的一次调用。native-attempt-claim-v19.json一旦出现即不能复用、删除或重建旧GO；新复现必须另建新版本/目录、runID和完整许可。目录内容审阅、静态编译、实际原生结果和发布分别判定。本指南本身不授予任何native或发布GO；K02其他分支的失败/HOLD不改变。

本目录是明确要求的全新同源复现，输入和oracle与已验收父例相同。新runID只允许一次；源准备阶段的GBK/UTF8指南读取失败保留，实际原生调用仍为0。
