"""Finite K02 Station.NOTE omission exchange contract. Read only; no GO."""
from pathlib import Path
import argparse,hashlib,json,math,re,struct
CASE=Path(__file__).resolve().parent
def need(value,message):
    if not value:raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pairs(values):
    d={}
    for key,value in values:
        need(key not in d,'duplicate lexical property: '+key);d[key]=value
    return d
def strict(raw):
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('nonfinite JSON')))
def typed(x):
    if isinstance(x,dict):return ('object',tuple((k,typed(v)) for k,v in sorted(x.items())))
    if isinstance(x,list):return ('array',tuple(typed(v) for v in x))
    if type(x) is float:
        need(math.isfinite(x),'nonfinite number');return ('binary64',struct.pack('>d',x).hex())
    return (type(x).__name__,x)
def cells(d):return sum(len(r) for t in d['model']['tables'] for inst in t['instances'] for r in inst['rows'])
def check_logs(actual,reference,kind,path):
    need(actual.endswith(b'\r\n') and not re.search(rb'[\r\n]',actual.replace(b'\r\n',b'')),'native CRLF/final terminator differs')
    old=reference.splitlines(keepends=True);lines=actual.splitlines(keepends=True)
    need(len(lines)==len(old),'native full line count differs')
    prefix=b'Importing data from Json file: ' if kind=='import' else b'Exporting data to Json file: '
    need(lines[0]==prefix+str(path).encode('ascii')+b'\r\n','native physical path differs')
    need(lines[1:-1]==old[1:-1],'native complete body differs')
    end=b'Import' if kind=='import' else b'Export'
    need(re.fullmatch(end+rb' completed! Time: (?:0|[1-9][0-9]*)\.[0-9]{2} secs\r\n',lines[-1]) is not None,'native elapsed grammar differs')
def verify(actual,root,contract,refs):
    need(sha(actual['input.json'])==contract['source']['sha256'],'source input differs')
    exported=strict(actual['roundtrip-raw.json']);expected=strict(refs['expected-export.json'])
    need(typed(exported)==typed(expected),'complete typed export/oracle differs')
    need(cells(exported)==381,'full native cell count differs')
    table=next(t for t in exported['model']['tables'] if t['name']=='Station')
    names=[c['name'] for c in table['columns']];j=names.index('NOTE')
    need(table['columns'][j]=={'datatype':'string','name':'NOTE'},'restored NOTE metadata differs')
    need(len(table['instances'])==3,'native Station instance set differs')
    need(all(r[j] is None for inst in table['instances'] for r in inst['rows']),'omitted NOTE not restored null')
    for kind in ['import','export']:
        check_logs(actual[kind+'.log'],refs['parent-'+kind+'.log'],kind,root/('input.json' if kind=='import' else 'roundtrip-raw.json'))
    return {'status':'RAW_IDENTITY_CHECK_ONLY','cells':381,'actual_target_independently_verified':True,'Station_NOTE_restored_null_instances':3,'full_metadata_types_nulls_and_binary64_equal':True,'native_GO':False,'publication_GO':False}
def load(expected):
    raw=(CASE/'content-contract-v1.json').read_bytes();need(sha(raw)==expected,'external content contract differs');c=strict(raw)
    need(c['schema']=='issue18-K02-Station-NOTE-omission-content/v1','unsupported finite content contract')
    refs={}
    for name,p in c['references'].items():
        raw=(CASE/p['relative_path']).read_bytes();need(len(raw)==p['bytes'] and sha(raw)==p['sha256'],'reference differs '+name);refs[name]=raw
    return c,refs
def main():
    p=argparse.ArgumentParser();p.add_argument('--binding-sha',required=True);p.add_argument('--raw-directory',type=Path,required=True);p.add_argument('--input-path',type=Path,required=True);p.add_argument('--output-path',type=Path,required=True);a=p.parse_args()
    c,refs=load(a.binding_sha);need(str(a.raw_directory)==c['target']['physical_directory'],'fixed run directory differs');need(a.input_path==a.raw_directory/'input.json' and a.output_path==a.raw_directory/'roundtrip-raw.json','fixed paths differ')
    need({f.name for f in a.raw_directory.iterdir()}==set(c['raw_payload']),'fixed9 payload differs')
    actual={name:(a.raw_directory/name).read_bytes() for name in c['raw_payload']}
    need(len(actual['model.sxi'])>4,'invalid SXI')
    for stage in ['jimport_save','jexport']:need(not actual[stage+'-stderr.bin'],'native stderr not empty')
    print(json.dumps(verify(actual,a.raw_directory,c,refs),ensure_ascii=False))
if __name__=='__main__':main()
