"""Read-only independent full native-result acceptance for the fixed A01 run.

Does not import the producer/owner/content checker, execute a model, or change
source/raw files. Writes only a new terminal acceptance receipt after all checks.
"""
from pathlib import Path
import sys
import ctypes
from ctypes import wintypes
import datetime
import hashlib
import json
import re
import struct
import subprocess

CASE=Path(__file__).resolve().parent
MANIFEST=sys.argv[1]
def filepin(p):
    data=p.read_bytes();return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def bound(pin):
    p=Path(pin['path']);assert filepin(p)=={k:pin[k] for k in ('path','bytes','sha256')};return p.read_bytes()
def deep(a,b,path='$'):
    assert type(a) is type(b),'typed mismatch '+path
    if isinstance(a,dict):
        assert set(a)==set(b),'key mismatch '+path
        return 1+sum(deep(a[k],b[k],path+'/'+k) for k in a)
    if isinstance(a,list):
        assert len(a)==len(b),'array size mismatch '+path
        return 1+sum(deep(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b)))
    if isinstance(a,float):assert struct.pack('>d',a)==struct.pack('>d',b),'binary64 mismatch '+path
    else:assert a==b,'value mismatch '+path
    return 1
def cells(value):
    if isinstance(value,dict):return sum(sum(map(len,v)) if k=='rows' else cells(v) for k,v in value.items())
    if isinstance(value,list):return sum(cells(v) for v in value)
    return 0

mp=CASE/'selected-manifest-v19.json';assert filepin(mp)['sha256']==MANIFEST
m=json.loads(mp.read_bytes());t=m['targets']['native'];rawdir=Path(t['physical_directory']);recovered=Path(t['recovered_directory'])
controller_pin={'path':sys.argv[2],'bytes':Path(sys.argv[2]).stat().st_size,'sha256':sys.argv[3]}
controller=json.loads(bound(controller_pin))
assert controller['transport_exit_code']==0 and not controller['transport_stderr'] and controller['retries']==0
assert controller['actual_native_calls']==2 and controller['actual_simulation_calls']==0
owner_pin=controller['owner_receipt'];owner=json.loads(bound(owner_pin));result=owner['result']
assert owner['mode']=='native' and owner['manifest_sha256']==MANIFEST and owner['run_id']==t['run_id']
for key in ['RawOwned','RecoveredOwned','OriginalSealed','RecoveryVerified','RawBehaviorAccepted','QueueReleaseAttempted','QueueReleasedActual']:
    assert result[key] is True,key
for key in ['Failed','UnknownChild','QueueOwned']:
    assert result[key] is False,key
assert result['NativeSimloxCalls']==2 and result['SimulationCalls']==0 and result['ParentReruns']==0
children=result['Children'];assert [x['Stage'] for x in children]==['jimport_save','jexport']
identities=owner['independent_suspended_identity'];assert len(identities)==2
for child in children:
    for key in ['CreateAttempted','CreateReturned','Created','ResumeAttempted','ResumeReturned','Signaled','IdentityBeforeResume','IdentityAfterSignal','ExitCodeObserved']:
        assert child[key] is True,(child['Stage'],key)
    assert child['ExitCode']==0 and child['ResumeCount']==1 and child['Session']==0
    assert child['ImagePath'].lower()==m['exe']['path'].lower()
    rows=[x for x in identities if x['pid']==child['Pid'] and int(x['creation_filetime'])==child['Creation']]
    assert len(rows)==1 and rows[0]['observed_before_resume'] is True
    assert rows[0]['path'].lower()==m['exe']['path'].lower()
assert len({(x['Pid'],x['Creation']) for x in children})==2
handles=result['Handles'];assert handles
assert all(x['CloseAttempted'] is True and x['ClosedActual'] is True and x['CloseUnknown'] is False for x in handles)
assert len([x for x in handles if x['Role'].startswith('Process:')])==2
assert len([x for x in handles if x['Role'].startswith('Thread:')])==2

contract=json.loads((CASE/'content-contract-v1.json').read_bytes())
assert filepin(CASE/'content-contract-v1.json')['sha256']==m['component_binding_sha256']
names=set(contract['raw_payload']);assert len(names)==9
assert {p.name for p in rawdir.iterdir()}=={p.name for p in recovered.iterdir()}==names
originals={x['Name']:x for x in result['Originals']};copies={x['Name']:x for x in result['Recovered']}
assert set(originals)==set(copies)==names
payload={};pairs=[]
for name in sorted(names):
    p=rawdir/name;q=recovered/name;op=originals[name];cp=copies[name]
    a=p.read_bytes();b=q.read_bytes();actual=hashlib.sha256(a).hexdigest()
    assert a==b and actual==op['Sha']==cp['Sha']
    assert len(a)==op['Bytes']==cp['Bytes']
    assert (op['Volume'],op['Id'])!=(cp['Volume'],cp['Id'])
    assert op['Attributes']&1 and cp['Attributes']&1
    assert p.stat().st_file_attributes&1 and q.stat().st_file_attributes&1
    payload[name]=a;pairs.append({'name':name,'bytes':len(a),'sha256':actual,'original_and_recovered_byte_equal':True,'original_readonly':True,'recovered_readonly':True,'distinct_file_identity':True})
assert hashlib.sha256(payload['input.json']).hexdigest()=='3ae6b43062876f74bcdf3e4563578759b01952bca01137bf1ee52b31666eaf17'
assert len(payload['model.sxi'])>4
for stage in ['jimport_save','jexport']:
    assert payload[stage+'-stderr.bin']==b''

reference={name:bound({'path':str(CASE/p['relative_path']),'bytes':p['bytes'],'sha256':p['sha256']}) for name,p in contract['references'].items()}
def no_duplicate_properties(items):
    result={}
    for key,value in items:
        assert key not in result,'duplicate lexical JSON property';result[key]=value
    return result
def document(raw):return json.loads(raw,object_pairs_hook=no_duplicate_properties)
actual=document(payload['roundtrip-raw.json']);expected=document(reference['expected-export.json'])
tree_nodes=deep(actual,expected);assert cells(actual)==381
station=next(t for t in actual['model']['tables'] if t['name']=='Station')
columns=[c['name'] for c in station['columns']];j=columns.index('NOTE')
assert station['columns'][j]=={'datatype':'string','name':'NOTE'}
assert [i['instance_name'] for i in station['instances']]==['','K02-BASE','K02-AUX']
assert all(len(i['rows'])==1 and i['rows'][0][j] is None for i in station['instances'])
source=document(payload['input.json']);source_station=next(t for t in source['model']['tables'] if t['name']=='Station')
assert 'NOTE' not in [c['name'] for c in source_station['columns']]
assert [i['instance_name'] for i in source_station['instances']]==['K02-BASE','K02-AUX']
source_station['columns'].append({'datatype':'string','name':'NOTE'})
for instance in source_station['instances']:instance['rows'][0].append(None)
reconstructed=(json.dumps(source,ensure_ascii=False,indent=2)+'\n').encode()
assert reconstructed==(CASE/'source-snapshots/parent-input.json').read_bytes()
assert hashlib.sha256(reconstructed).hexdigest()=='178b4230dc6264de739320bd044dd389424609be27603555dee177bdd33a3e99'
for kind in ['import','export']:
    raw=payload[kind+'.log'];old=reference['parent-'+kind+'.log']
    assert raw.endswith(b'\r\n') and not re.search(rb'[\r\n]',raw.replace(b'\r\n',b''))
    lines=raw.splitlines(keepends=True);original=old.splitlines(keepends=True)
    assert len(lines)==len(original) and lines[1:-1]==original[1:-1]
    prefix=b'Importing data from Json file: ' if kind=='import' else b'Exporting data to Json file: '
    filename='input.json' if kind=='import' else 'roundtrip-raw.json'
    assert lines[0]==prefix+str(rawdir/filename).encode()+b'\r\n'
    end=b'Import' if kind=='import' else b'Export'
    assert re.fullmatch(end+rb' completed! Time: (?:0|[1-9][0-9]*)\.[0-9]{2} secs\r\n',lines[-1])
for v in m['sources']:bound(v)
binding_path=CASE/'directory-entry-binding-v1.json'
assert filepin(binding_path)['sha256']==sys.argv[4]
for v in json.loads(binding_path.read_bytes())['files']:
    p=CASE/v['relative_path'];assert filepin(p)['sha256']==v['sha256'] and p.stat().st_size==v['bytes']
invocation_path=CASE/'review/directory-native-invocation-v1.json';invocation=json.loads(invocation_path.read_bytes())
assert invocation['exit_code']==0 and invocation['retries']==0 and invocation['current_working_directory']=='C:/Windows/Temp'
assert invocation['project_code_loaded_from_case_directory_only'] is True
assert invocation['command'][3]==str(CASE/'directory_native_once.py')
assert m['working_directory']==str(CASE)
source_audit=json.loads((CASE/'source-role-audit-v1.json').read_bytes())
for item in source_audit['source_roles']:
    if item['classification'].startswith('PROJECT'):assert Path(item['selected']['path']).is_relative_to(CASE)
ps=r'''$g=@(Get-Process Simlox -ErrorAction SilentlyContinue);if($g.Count -ne 1){throw 'unexpected native process set'};$g|ForEach-Object{[ordered]@{pid=$_.Id;session=$_.SessionId;creation_filetime=$_.StartTime.ToUniversalTime().ToFileTimeUtc().ToString();path=$_.Path;responding=$_.Responding}}|ConvertTo-Json -Compress'''
r=subprocess.run([m['powershell']['path'],'-NoProfile','-NonInteractive','-Command',ps],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=20)
assert r.returncode==0 and not r.stderr;gui=json.loads(r.stdout)
assert gui['pid']==13340 and gui['session']==1 and gui['creation_filetime']=='134350637968261381' and gui['responding'] is True and gui['path']==m['exe']['path']
kernel=ctypes.WinDLL('kernel32',use_last_error=True);kernel.OpenMutexW.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.LPCWSTR];kernel.OpenMutexW.restype=wintypes.HANDLE
kernel.CloseHandle.argtypes=[wintypes.HANDLE];kernel.CloseHandle.restype=wintypes.BOOL
ctypes.set_last_error(0);h=kernel.OpenMutexW(0x00100000,False,r'Global\SimloxIssue18NativeQueue');error=ctypes.get_last_error()
if h:assert kernel.CloseHandle(h)
assert not h and error==2
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt={'schema':'issue18-independent-K02-Station-NOTE-native-acceptance/v1','utc':now,'terminal':True,'completed':True,'decision':'ACCEPT_DIRECTORY_GUIDE_NATIVE_REPRODUCTION_OF_K02_NOTE','run_id':t['run_id'],'manifest':filepin(mp),'controller':controller_pin,'owner_receipt':owner_pin,'directory_invocation':filepin(invocation_path),'directory_entry_binding':filepin(binding_path),'physical_directory':str(rawdir),'recovered_directory':str(recovered),'actual_native_stages':[{'stage':c['Stage'],'pid':c['Pid'],'creation_filetime':str(c['Creation']),'exit_code':c['ExitCode'],'single_resume_count':c['ResumeCount']} for c in children],'actual_native_calls':2,'actual_simulation_calls':0,'parent_reruns':0,'new_control_calls':0,'full_typed_export_cells':381,'independent_tree_nodes_checked':tree_nodes,'Station_NOTE_authored_omitted_cells':2,'Station_NOTE_native_restored_null_instances':3,'complete_original_recovered_pairs':pairs,'source_roles_rechecked':len(m['sources']),'full_stage_logs_verified':2,'native_exit_codes':[0,0],'all_original_handles_closed_actual':True,'handle_records_verified':len(handles),'native_queue_release_actual':True,'native_queue_OpenExisting_after':{'exists':False,'last_error':2,'ownership_not_changed':True},'protected_GUI_final':gui,'project_source_paths_outside_case_required':0,'old_working_directory_required':False,'directory_only_native_execution_verified':True,'fresh_independent_agent_trial_verified':False,'installed_host_tool_manual_and_SSH_trust_prerequisites_retained':True,'whole_K02_complete':False,'whole_issue_complete':False,'publication_GO':False,'denominator':None,'limitations':['Optional Station.NOTE text-null omission in two named instances only, not arbitrary null/default laws','No numeric/required-key omission or inactive-row lossless claim','No simulation/calculation, IR/Rust equivalence or performance acceptance','Original nonASCII/wrong-type failures and duplicate oracle HOLD remain unchanged','Case-local cold-process execution is verified; a separate agent trial is not inferred']}
target=CASE/'review/independent-native-acceptance-v19.json'
with target.open('x',encoding='utf-8') as f:json.dump(receipt,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'observed_at_utc':now,'decision':receipt['decision'],'terminal_receipt':filepin(target),'native_stages':receipt['actual_native_stages'],'actual_native_calls':2,'actual_simulation_calls':0,'raw_pairs':len(pairs),'full_export_cells':381,'handle_records_verified':len(handles),'native_queue_released':True,'GUI_final':gui,'directory_only_native_execution_verified':True,'whole_issue_complete':False},ensure_ascii=False,indent=2))
