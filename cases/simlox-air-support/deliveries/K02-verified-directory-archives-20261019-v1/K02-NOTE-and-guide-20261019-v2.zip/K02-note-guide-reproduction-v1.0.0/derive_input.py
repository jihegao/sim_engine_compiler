from pathlib import Path
import argparse,copy,hashlib,json
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();root=Path(__file__).resolve().parent
raw=(root/'source-snapshots/parent-input.json').read_bytes();assert hashlib.sha256(raw).hexdigest()=='178b4230dc6264de739320bd044dd389424609be27603555dee177bdd33a3e99'
d=json.loads(raw);table=next(t for t in d['model']['tables'] if t['name']=='Station');assert table['columns'].pop()=={'datatype':'string','name':'NOTE'}
for instance in table['instances']:assert instance['rows'][0].pop() is None
out=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode();assert hashlib.sha256(out).hexdigest()=='3ae6b43062876f74bcdf3e4563578759b01952bca01137bf1ee52b31666eaf17'
with a.output.open('xb') as f:f.write(out)
print(json.dumps({'source_sha256':hashlib.sha256(out).hexdigest(),'removed_column':'Station.NOTE','removed_authored_null_cells':2,'native_calls':0}))
