# STIM9 directory-only derivation and native reproduction delivery

The directory preparation actually ran from its own prepare.py and bundled accepted
A01 source archive, in an isolated Windows Python process with neutral cwd. It derives
only STIM8.0-to9.0hours, one byte, and carries the full earlier frozen339-cell export,
4044-cell report, full events and four complete CRLF stage log expectations. The new
case-local helper preserves the accepted original-H/GUI/SSH0/PS5/serial queue guards.

This package includes the complete preparation directory, new case project sources,
prospective data, immutable native results and independent original custody receipt.
Installed SIMLOX/Python/.NET/SSH, existing trust and protected coordinator/GUI plus
live repository freshness remain explicit host prerequisites. Vendor programs/manuals,
credentials, private dumps and databases are excluded. No old authored temporary
project source directory is needed for the demonstrated finite preparation/run.

Every included fixed preparation/native path/runID/claim/GO is consumed. Do not rerun
it or recreate GO; future native reproduction requires a new reviewed finite version,
paths and runID. Read-only replay:
  python -I -X utf8 -B replay.py <this directory>
It checks all indexed bytes, preparation entry/source/derivation proof, full typed
export/report/raw-normalized relation/events/four logs, archived original handles,
queue and logged SSH receipts. It never executes preparation or native code and does
not rebuild Windows readonly attributes/NTFS identities/original H/queue/GUI custody.
Use the actual independent native receipt for original OS evidence.

One source-only candidate was retired before any SSH preflight/native claim because
its business folder name overlapped the existing native run-marker matcher. Its
source evidence is retained. The new business label changes no matcher/exclusion,
model bytes, oracle or process identity rules. Old consumed profiles were not rerun.

This accepts one earlier STIM9 model's directory preparation/helper migration, not
new model semantics, arbitrary factory paths/ranges, a separate new-agent trial,
repository publication, K02 failed imports/lossless exchange or whole Issue18.
