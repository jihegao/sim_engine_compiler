"""Negative arm: successful conversion can never satisfy failure retention."""
import json
print(json.dumps({"status":"NO_GO_UNEXPECTED_NATIVE_SUCCESS_FOR_INVALID_INTEGER","negative_behavior_accepted":False,"publication_GO":False}))
raise SystemExit(1)
