# K02 JSON DTIM precision v1.0.3 candidate

Additive local guardian PID-query return-code repair. Get-Process on an absent PID silently returned PS5 exit1; no SSH/native occurred. Explicit pinned PS5 CIM query now distinguishes absence(exit0), live process(exit1), query failure(nonzero/stderr), preserving local diagnostic streams. v1.0.2 final hash/readonly sealing is unchanged. Source/oracle and bounded import/save/export method remain unchanged. No native/result/publication acceptance.
