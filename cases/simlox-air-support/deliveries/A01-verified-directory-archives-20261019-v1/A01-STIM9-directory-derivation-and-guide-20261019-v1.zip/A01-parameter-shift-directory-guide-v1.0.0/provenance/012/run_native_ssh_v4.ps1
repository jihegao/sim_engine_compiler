param([switch]$PreflightOnly,[Parameter(Mandatory=$true)][string]$ExpectedManifestSha,[Parameter(Mandatory=$true)][string]$ExpectedReviewSha)
$ErrorActionPreference='Stop'
$case=$PSScriptRoot;$root=(Resolve-Path (Join-Path $case '..\..\..')).Path
$manifestPath=Join-Path $case 'prelaunch-manifest-v4-run01.json'
function Sha([string]$p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function Save([string]$p,$x){if(Test-Path -LiteralPath $p){throw "receipt already exists: $p"};$x|ConvertTo-Json -Depth 40|Set-Content -LiteralPath $p -Encoding UTF8}
function Canonical([string]$p){
 if(-not [IO.Path]::IsPathRooted($p) -or [IO.Path]::GetFullPath($p) -cne $p){throw 'noncanonical absolute path'}
 $cursor=[IO.Path]::GetPathRoot($p)
 foreach($part in $p.Substring($cursor.Length).Split('\')){if($part){$cursor=Join-Path $cursor $part;$i=Get-Item -LiteralPath $cursor -Force -ErrorAction SilentlyContinue;if($i -and ($i.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'reparse path'}}}
}
if($ExpectedManifestSha -cnotmatch '^[0-9a-f]{64}$' -or $ExpectedReviewSha -cnotmatch '^[0-9a-f]{64}$' -or (Sha $manifestPath) -cne $ExpectedManifestSha){throw 'external manifest/review binding differs'}
$m=Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8|ConvertFrom-Json
if($m.schema -cne 'simlox-k02-json-dtim-prelaunch/v4' -or $m.native_steps.Count -ne 2 -or $m.native_steps[0] -cne 'jimport_save' -or $m.native_steps[1] -cne 'jexport'){throw 'bounded two-step manifest differs'}
$exe=$m.exe.path;$python=$m.python.path;$run=$m.physical_directory;$recover=$m.recovered_directory
$created=$false;$steps=@();$ancestry=@();$mutex=$null;$locked=$false;$child=$null
function Pins{
 foreach($x in $m.sources){Canonical $x.path;if(-not(Test-Path -LiteralPath $x.path -PathType Leaf) -or (Get-Item -LiteralPath $x.path).Length -ne $x.bytes -or (Sha $x.path) -cne $x.sha256){throw "source pin differs: $($x.path)"}}
 foreach($x in @($m.live_index,$m.live_catalog)){if((Sha $x.path) -cne $x.sha256 -or (Get-Item -LiteralPath $x.path).Length -ne $x.bytes){throw 'live index/catalog epoch advanced'}}
 $refs=@(& $m.git.path -C $root ls-remote origin refs/heads/main refs/heads/simlox/main);if($LASTEXITCODE -ne 0 -or ($refs -join "`n") -cne ($m.refs.remote -join "`n")){throw 'remote epoch advanced'}
 if((& $m.git.path -C $root rev-parse HEAD) -cne $m.refs.HEAD){throw 'worktree HEAD changed'}
}
function Settings{
 $sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
 if($sid -cne $m.settings.user_sid){throw 'SSH user SID differs'}
 $k=Get-Item -LiteralPath 'HKCU:/Software/Systecon/SIMLOX Version 2017/JSON Import/Export'
 if(@($k.GetValueNames()).Count -ne $m.settings.values.Count){throw 'JSON settings keyset differs'}
 foreach($v in $m.settings.values){if($k.GetValueNames() -cnotcontains $v.name -or $k.GetValueKind($v.name).ToString() -cne $v.kind -or $k.GetValue($v.name) -cne $v.value){throw 'JSON export settings differ'}}
 return [ordered]@{user_sid=$sid;values=$m.settings.values;observed_utc=[DateTime]::UtcNow.ToString('o');read_only=$true}
}
function Safety{
 if($env:COMPUTERNAME -cne '4700-3' -or $PSVersionTable.PSVersion.Major -ne 5 -or (Get-Process -Id $PID).SessionId -ne 0 -or -not $env:SSH_CONNECTION -or $env:SESSIONNAME -or @($ancestry|Where-Object{$_.name -ceq 'sshd.exe'}).Count -eq 0){throw 'actual SSH0 PS5 ancestry required'}
 $g=@(Get-Process Simlox -ErrorAction SilentlyContinue)
 if($g.Count -ne 1 -or $g[0].Id -ne $m.gui.pid -or $g[0].SessionId -ne $m.gui.session -or $g[0].Path -cne $exe -or -not $g[0].Responding -or ([DateTimeOffset]$g[0].StartTime.ToUniversalTime()).ToUnixTimeMilliseconds() -ne $m.gui.start_unix_ms){throw 'protected GUI/native process identity differs'}
 $wts=@(qwinsta 2>&1);if($LASTEXITCODE -ne 0 -or @($wts|Where-Object{$_ -match '^\s*>?\s*(Console|RDP-Tcp#\d+)\s+\S+\s+1\s+(?:Active|\u8fd0\u884c\u4e2d)(?:\s|$)'}).Count -ne 1){throw 'active WTS1 not unique'}
 $exclude=@($PID)+@($ancestry|ForEach-Object{$_.pid})
 $other=@(Get-CimInstance Win32_Process|Where-Object{$_.SessionId -eq 0 -and $_.ProcessId -notin $exclude -and $_.Name -match '^(powershell|pwsh|python|pythonw|cmd|ssh)\.exe$' -and $_.CommandLine -match '(?i)(run_native_ssh|SimloxIssue18NativeQueue|k02-json-dtim-v101)'})
 if($other.Count){throw 'another native runner contender'}
 Canonical $run;Canonical $recover
 if((Test-Path -LiteralPath $run) -and -not $created){throw 'physical run already occupied'}
 if(Test-Path -LiteralPath $recover){throw 'recovered run already occupied'}
 if($created -and -not(Test-Path -LiteralPath $run -PathType Container)){throw 'owned run disappeared'}
 foreach($line in @(('Importing data from Json file: '+(Join-Path $run 'input.json')),('Exporting data to Json file: '+(Join-Path $run 'roundtrip-raw.json')))){if($line -cne [Text.Encoding]::ASCII.GetString([Text.Encoding]::ASCII.GetBytes($line)) -or [Text.Encoding]::ASCII.GetByteCount($line) -gt 199){throw 'unsafe native path length/encoding'}}
 Pins;Settings|Out-Null
}
function Capture([string]$name,[string]$program,[string]$arguments,[string]$dir,[switch]$Native){
 $out=Join-Path $dir ($name+'-stdout.bin');$err=Join-Path $dir ($name+'-stderr.bin')
 if((Test-Path -LiteralPath $out) -or (Test-Path -LiteralPath $err)){throw 'capture path occupied'}
 $started=[DateTime]::UtcNow.ToString('o');$identity=$null;$identityError=$null
 $p=Start-Process -FilePath $program -ArgumentList $arguments -WorkingDirectory $m.working_directory -WindowStyle Hidden -PassThru -RedirectStandardOutput $out -RedirectStandardError $err
 # If the native child exits before identity can be observed, seal NO_GO after
 # natural completion; never invent an observed child identity or terminate it.
 if($Native){try{
   $live=Get-CimInstance Win32_Process -Filter "ProcessId=$($p.Id)"
   if(-not $live -or $live.SessionId -ne 0 -or $live.ParentProcessId -ne $PID -or $live.ExecutablePath -cne $exe){throw 'native child identity not independently observable'}
   $childProcess=Get-Process -Id $p.Id -ErrorAction Stop; $processStart=([DateTimeOffset]$childProcess.StartTime.ToUniversalTime()).ToUnixTimeMilliseconds(); $cimStart=([DateTimeOffset]$live.CreationDate.ToUniversalTime()).ToUnixTimeMilliseconds(); if($processStart -ne $cimStart -or $childProcess.SessionId -ne 0 -or $childProcess.Path -cne $exe){throw 'native child start/path/session identity differs'}
   $identity=[ordered]@{pid=[int]$live.ProcessId;session=[int]$live.SessionId;parent_pid=[int]$live.ParentProcessId;path=$live.ExecutablePath;created=$live.CreationDate;start_unix_ms=$processStart;cim_start_unix_ms=$cimStart;runner_ssh_ancestors=$ancestry}
 }catch{$identityError=$_.Exception.Message}}
 $observedHandle=$p.Handle;$p.WaitForExit();$p.Refresh()
 $capture=[ordered]@{name=$name;program=$program;arguments=$arguments;child_pid=$p.Id;child_identity=$identity;identity_error=$identityError;started_utc=$started;completed_utc=[DateTime]::UtcNow.ToString('o');exit_code=$p.ExitCode;stdout_bytes=(Get-Item $out).Length;stdout_sha256=(Sha $out);stderr_bytes=(Get-Item $err).Length;stderr_sha256=(Sha $err)}
 Save (Join-Path $dir ($name+'-capture.json')) $capture
 if($identityError -or $p.ExitCode -ne 0 -or $capture.stderr_bytes -ne 0){throw "captured command failed: $name $identityError exit=$($p.ExitCode)"}
 return $capture
}
$script:recoveryOwned=$false
function Recover([bool]$success,[string]$errorText){
 if(-not $created){return}
 $raw=@(Get-ChildItem -LiteralPath $run -File|Sort-Object Name|ForEach-Object{[ordered]@{name=$_.Name;bytes=$_.Length;sha256=(Sha $_.FullName)}})
 $closurePath=Join-Path $run 'closure.json'
 if(-not(Test-Path -LiteralPath $closurePath)){
  Save $closurePath ([ordered]@{schema='simlox-k02-dtim-native-closure/v2';run_id=$m.run_id;native_validation_success=$success;recovery_status='pending';error=$errorText;steps=$steps;raw=$raw;native_steps_planned=2;simulation_calls=0;parent_reruns=0;publication_state='not_published'})
 }
 if(Test-Path -LiteralPath $recover){if(-not $script:recoveryOwned){throw 'recovery target occupied by another owner'}}else{New-Item -ItemType Directory -Path $recover -Force|Out-Null;$script:recoveryOwned=$true}
 foreach($f in Get-ChildItem -LiteralPath $run -File){
  $target=Join-Path $recover $f.Name
  if(Test-Path -LiteralPath $target){if((Sha $target) -cne (Sha $f.FullName)){throw 'existing owned recovery bytes differ'}}else{Copy-Item -LiteralPath $f.FullName -Destination $target}
  if((Sha $target) -cne (Sha $f.FullName)){throw 'raw recovery mismatch'}
  (Get-Item $target).IsReadOnly=$true;(Get-Item $f.FullName).IsReadOnly=$true
 }
 $receipt=Join-Path $case ('review\recovery-'+[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ')+'.json')
 Save $receipt ([ordered]@{schema='simlox-k02-dtim-recovery/v2';run_id=$m.run_id;original_run_directory=$run;recovered_run_directory=$recover;closure_sha256=(Sha $closurePath);all_copied_files_readonly=$true;native_validation_success=$success;recovery_status='complete';publication_state='not_published'})
}

function SealOriginals {
 if(-not $created){return}
 $rows=@();$errors=@()
 foreach($f in @(Get-ChildItem -LiteralPath $run -File|Sort-Object Name)){
  $hash=$null;$before=$f.Length;$failure=@()
  try{$hash=Sha $f.FullName}catch{$failure+=@($_.Exception.Message)}
  try{(Get-Item -LiteralPath $f.FullName).IsReadOnly=$true}catch{$failure+=@($_.Exception.Message)}
  $readonly=$false
  try{$readonly=(Get-Item -LiteralPath $f.FullName).IsReadOnly;if(-not $readonly){throw 'original remains writable'};if($hash -and ((Sha $f.FullName) -cne $hash -or (Get-Item -LiteralPath $f.FullName).Length -ne $before)){throw 'original changed during seal'}}catch{$failure+=@($_.Exception.Message)}
  $rows+=@([ordered]@{name=$f.Name;bytes=$before;sha256=$hash;readonly=$readonly;errors=$failure})
  $errors+=@($failure)
 }
 $recoveredRows=@()
 if($script:recoveryOwned -and (Test-Path -LiteralPath $recover)){
  foreach($f in @(Get-ChildItem -LiteralPath $recover -File|Sort-Object Name)){
   $failure=@();$hash=$null;$readonly=$false
   try{$hash=Sha $f.FullName}catch{$failure+=@($_.Exception.Message)}
   try{(Get-Item -LiteralPath $f.FullName).IsReadOnly=$true;$readonly=(Get-Item -LiteralPath $f.FullName).IsReadOnly;if(-not $readonly){throw 'owned recovered file remains writable'}}catch{$failure+=@($_.Exception.Message)}
   $recoveredRows+=@([ordered]@{name=$f.Name;bytes=$f.Length;sha256=$hash;readonly=$readonly;errors=$failure});$errors+=@($failure)
  }
 }
 $sealPath=Join-Path $case ('review\original-seal-'+[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ')+'.json')
 Save $sealPath ([ordered]@{schema='simlox-k02-original-final-seal/v1';run_id=$m.run_id;original_run_directory=$run;recovered_run_directory=$recover;originals=$rows;owned_recovered=$recoveredRows;all_originals_hashed_readonly=($errors.Count -eq 0);errors=$errors;publication_state='not_published'})
 (Get-Item -LiteralPath $sealPath).IsReadOnly=$true
 if($errors.Count -gt 0){throw 'original final sealing incomplete; see additive seal receipt'}
}

try{
 $cursor=(Get-CimInstance Win32_Process -Filter "ProcessId=$PID").ParentProcessId
 for($i=0;$i -lt 15 -and $cursor -gt 0;$i++){$a=Get-CimInstance Win32_Process -Filter "ProcessId=$cursor";if(-not $a){break};$ancestry+=@([ordered]@{pid=[int]$a.ProcessId;name=$a.Name;session=[int]$a.SessionId;created=$a.CreationDate});$cursor=$a.ParentProcessId}
 $mutex=[Threading.Mutex]::new($false,'Global\SimloxIssue18NativeQueue')
 try{$locked=$mutex.WaitOne(0)}catch [System.Threading.AbandonedMutexException]{$locked=$true;throw 'abandoned native queue: NO_GO'}
 if(-not $locked){throw 'native queue held'}
 Safety
 $reviewPath=Join-Path $case $(if($PreflightOnly){'review\independent-static-go-v4.json'}else{'review\independent-prelaunch-go-v4.json'})
 if((Sha $reviewPath) -cne $ExpectedReviewSha){throw 'external independent review SHA differs'}
 $review=Get-Content -LiteralPath $reviewPath -Raw -Encoding UTF8|ConvertFrom-Json
 if($review.manifest_sha256 -cne $ExpectedManifestSha -or $review.run_id -cne $m.run_id -or $review.decision -cne $(if($PreflightOnly){'GO_PRELAUNCH_STATIC'}else{'GO_PRELAUNCH'})){throw 'review does not bind this gate/manifest/run'}
 if(-not $PreflightOnly){
  if($review.preflight_relative_path -cnotmatch '^review\\preflight-ssh0-[0-9TZ]+\.json$'){throw 'preflight path grammar'}
  $pf=Join-Path $case $review.preflight_relative_path
  if((Sha $pf) -cne $review.preflight_sha256 -or (Sha (Join-Path $case 'review\independent-static-go-v4.json')) -cne $review.static_review_sha256){throw 'receipt/static hash differs'}
  $r=Get-Content $pf -Raw -Encoding UTF8|ConvertFrom-Json
  if($r.decision -cne 'GO_PRELAUNCH_CANDIDATE' -or $r.manifest_sha256 -cne $ExpectedManifestSha -or $r.run_id -cne $m.run_id -or $r.native_process_started -ne $false -or $r.run_directory_absent -ne $true -or $r.ps_major -ne 5 -or $r.session_id -ne 0){throw 'pure receipt safety differs'}
 }
 $pure=Join-Path $case ('review\pure-'+[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ'));New-Item -ItemType Directory -Path $pure|Out-Null
 $proof=Capture 'selfcheck' $python ('-E -X utf8 -B "'+(Join-Path $case 'check_exchange_v2.py')+'" --self-check') $pure
 $self=Get-Content (Join-Path $pure 'selfcheck-stdout.bin') -Raw -Encoding UTF8|ConvertFrom-Json
 if($self.status -cne 'PASS' -or $self.tests -ne 46 -or $self.native_calls -ne 0){throw 'pure controls differ'}
 Safety
 if($PreflightOnly){
  $p=Join-Path $case ('review\preflight-ssh0-'+[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ')+'.json')
  Save $p ([ordered]@{schema='simlox-k02-dtim-SSH-preflight/v2';decision='GO_PRELAUNCH_CANDIDATE';utc=[DateTime]::UtcNow.ToString('o');run_id=$m.run_id;manifest_sha256=$ExpectedManifestSha;static_review_sha256=$ExpectedReviewSha;runner_sha256=(Sha $PSCommandPath);host=$env:COMPUTERNAME;ps_major=5;session_id=0;ssh_connection=$env:SSH_CONNECTION;ssh_ancestors=$ancestry;settings=(Settings);gui=$m.gui;native_queue_held=$true;native_queue_abandoned=$false;run_directory_absent=$true;native_process_started=$false;pure_capture=$proof;checks=$self.tests;source_pins_verified=$m.sources.Count})
  Write-Output $p;return
 }
 Safety;New-Item -ItemType Directory -Path $run|Out-Null;$created=$true
 $input=Join-Path $run 'input.json';$sxi=Join-Path $run 'model.sxi';$output=Join-Path $run 'roundtrip-raw.json'
 Copy-Item -LiteralPath (Join-Path $case 'native-input.json') -Destination $input
 if((Sha $input) -cne $m.input_sha256){throw 'copied source differs'}
 Save (Join-Path $run 'invocation.json') ([ordered]@{schema='simlox-k02-dtim-invocation/v2';run_id=$m.run_id;original_run_directory=$run;manifest_sha256=$ExpectedManifestSha;approval_sha256=$ExpectedReviewSha;preflight_sha256=$review.preflight_sha256;ancestry=$ancestry;settings_before=(Settings);native_steps=@('jimport_save','jexport');simulation_calls=0;parent_reruns=0})
 $commands=@([ordered]@{name='jimport_save';args=('-silent -jimport "{0}" -save "{1}" -log "{2}" -close' -f $input,$sxi,(Join-Path $run 'import.log'))},[ordered]@{name='jexport';args=('"{0}" -silent -jexport "{1}" -log "{2}" -close' -f $sxi,$output,(Join-Path $run 'export.log'))})
 $sxiHash=$null
 foreach($command in $commands){
  Safety;if((Sha $input) -cne $m.input_sha256){throw 'physical input changed'}
  if($sxiHash -and (Sha $sxi) -cne $sxiHash){throw 'SXI changed before export'}
  $capture=Capture $command.name $exe $command.args $run -Native;$steps+=@($capture)
  Safety;if((Sha $input) -cne $m.input_sha256){throw 'physical input changed after stage'}
  if($command.name -ceq 'jimport_save'){if(-not(Test-Path $sxi) -or (Get-Item $sxi).Length -le 4 -or -not(Test-Path (Join-Path $run 'import.log'))){throw 'import output missing'};$sxiHash=Sha $sxi}
  else{if((Sha $sxi) -cne $sxiHash -or -not(Test-Path $output) -or (Get-Item $output).Length -le 4){throw 'export missing or SXI changed'}}
  Save (Join-Path $run ($command.name+'-postguard.json')) ([ordered]@{settings=(Settings);input_sha256=(Sha $input);sxi_sha256=(Sha $sxi);gui_preserved=$true;source_pins_preserved=$true})
 }
 Safety
 $args='-E -X utf8 -B "'+(Join-Path $case 'check_exchange_v2.py')+'" --binding-sha '+$m.component_binding_sha256+' --raw-directory "'+$run+'" --input-path "'+$input+'" --output-path "'+$output+'"'
 $check=Capture 'raw-check' $python $args $run
 $rawResult=Get-Content (Join-Path $run 'raw-check-stdout.bin') -Raw -Encoding UTF8|ConvertFrom-Json
 if($rawResult.status -cne 'RAW_IDENTITY_CHECK_ONLY' -or $rawResult.cells -ne 381 -or $rawResult.actual_target_independently_verified -ne $true){throw 'full raw identity failed'}
 Safety;Save (Join-Path $run 'source-settings-final.json') ([ordered]@{sources=$m.sources;settings=(Settings);sxi_sha256=(Sha $sxi);input_sha256=(Sha $input)})
 Recover $true $null;Write-Output 'NATIVE_IDENTITY_CANDIDATE_NOT_PUBLISHED'
}catch{
 $errorText=$_.Exception.Message
 if($created){
  $failurePath=Join-Path $run ('failure-seal-'+[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ')+'.json')
  Save $failurePath ([ordered]@{schema='simlox-k02-dtim-failure/v2';run_id=$m.run_id;error=$errorText;steps=$steps;recovery_status='not_complete';publication_state='not_published'})
  try{Recover $false $errorText}catch{
   $recoveryError=$_.Exception.Message
   Save (Join-Path $case ('review\recovery-failure-'+[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ')+'.json')) ([ordered]@{run_id=$m.run_id;original_error=$errorText;recovery_error=$recoveryError;failure_seal_sha256=(Sha $failurePath);original_run_directory=$run;recovered_run_directory=$recover;recovery_status='incomplete';publication_state='not_published'})
  }
 }else{Save (Join-Path $case ('review\guard-failure-'+[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ')+'.json')) ([ordered]@{error=$errorText;run_id=$m.run_id;native_process_started=$false;utc=[DateTime]::UtcNow.ToString('o')})}
 throw
}finally{try{SealOriginals}finally{if($locked){$mutex.ReleaseMutex()|Out-Null};if($mutex){$mutex.Dispose()}}}
