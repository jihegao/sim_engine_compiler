"""Read-only content checker for one frozen case-local A01 reproduction profile.

This does not provide process, custody, queue, publication or native launch GO.
The historical raw report remains invalid strict JSON and must byte-match its
exact accepted reference. Only the separately pinned historical normalized
representation is parsed; this is deliberately not a relaxed JSON decoder.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import struct

CASE=Path(__file__).resolve().parent
TIMING=re.compile(rb'(?m)^(Import completed! Time: |Export completed! Time: |Input data conversion time: |Simulation time: |Result saving time: |Total execution time: |Json-report generation time: )[0-9]+\.[0-9]+( secs\.?\r)$')
TIMING_COUNTS={'import.log':1,'export.log':1,'run.log':4,'report-export.log':1}
CONTENT_NAMES=['input.json','model.sxi','model.sxo','roundtrip-raw.json','report-raw.json','model.log','import.log','export.log','run.log','report-export.log']

def need(value,message):
    if not value:
        raise ValueError(message)

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def crlf(raw,name):
    need(raw.endswith(b'\r\n'),name+': missing final CRLF')
    rest=raw.replace(b'\r\n',b'')
    need(b'\n' not in rest and b'\r' not in rest,name+': non-CRLF terminator')

def log_shape(raw,directory,name):
    crlf(raw,name)
    raw=raw.replace(directory.encode('ascii'),b'@RUN@')
    raw=raw.replace(directory.replace('\\','/').encode('ascii'),b'@RUN@')
    shaped,count=TIMING.subn(rb'\1@ELAPSED@\2',raw)
    need(count==TIMING_COUNTS[name],name+': unsupported elapsed grammar')
    return shaped

def typed(value):
    if isinstance(value,dict):
        return ('object',tuple((key,typed(child)) for key,child in sorted(value.items())))
    if isinstance(value,list):
        return ('array',tuple(typed(child) for child in value))
    if type(value) is float:
        need(math.isfinite(value),'nonfinite typed numeric value')
    if type(value) is float:return ('binary64',struct.pack('>d',value).hex())
    return (type(value).__name__,value)

def cells(value):
    if isinstance(value,dict):
        return sum(sum(len(row) for row in child) if key=='rows' else cells(child) for key,child in value.items())
    if isinstance(value,list):
        return sum(cells(child) for child in value)
    return 0

def verify_content(actual,directory,contract,reference):
    need(set(CONTENT_NAMES)<=set(actual),'missing fixed native content file')
    need(digest(actual['input.json'])==contract['source_input_sha256'],'original source changed')
    for name in ['model.sxi','model.sxo']:
        need(len(actual[name])>4,name+': invalid/nontruncated model/result required')
    exported=json.loads(actual['roundtrip-raw.json'])
    need(typed(exported)==typed(json.loads(reference['roundtrip-raw.json'])),'full typed export/metadata/reference/null mismatch')
    need(actual['report-raw.json']==reference['report-raw.json'],'full frozen native report mismatch; no observed oracle repair')
    raw=reference['report-raw.json'];normalized=reference['historical-report-normalized.json']
    need(raw[103957]==44 and raw[:103957]+raw[103958:]==normalized,'historical normalization provenance mismatch')
    try:
        json.loads(raw)
    except json.JSONDecodeError as error:
        need(error.pos==103966,'historical strict-JSON failure changed')
    else:
        raise ValueError('historical raw strict failure disappeared')
    report=json.loads(normalized)
    need(cells(report)==4044,'full report cell count mismatch')
    need(actual['model.log']==reference['model.log'],'full native event log mismatch')
    crlf(actual['model.log'],'model.log')
    for name in TIMING_COUNTS:
        expected=bytes.fromhex(contract['log_shapes_hex'][name])
        need(log_shape(actual[name],directory,name)==expected,name+': complete log body mismatch')
    tables={table['name']:table for table in report['report']['tables']}
    table=tables['SystemResults'];columns=[x['name'] for x in table['columns']];rows=table['instances'][0]['rows']
    need(len(rows)==72 and len(columns)==40,'fixed A01 SystemResults shape differs')
    values={key:sum(row[columns.index(key)]*(row[columns.index('ETINT')]-row[columns.index('STINT')]) for row in rows) for key in ['FTMO','NSYMO','NSYMA','NSYMR','NSYRY']}
    need(values=={'FTMO':2,'NSYMO':2,'NSYMA':3,'NSYMR':1,'NSYRY':33},'fixed A01 operation/reservation/ready integrals differ')
    need(rows[-1][columns.index('NSYRY')]==1,'terminal ready state differs')
    return {'status':'RAW_IDENTITY_CHECK_ONLY','report_cells':4044,'export_cells':cells(exported),'full_report_byte_equal_reference':True,'historical_raw_strict_JSON_failure_retained':True,'report_interpretation':'Exact accepted historical normalized reference; actual raw byte equality checked first','integrals_hours':values,'terminal_ready':1,'actual_target_independently_verified':True,'publication_GO':False,'native_GO':False}

def load_contract(expected_sha):
    raw=(CASE/'content-contract-v1.json').read_bytes()
    need(digest(raw)==expected_sha,'external content contract SHA differs')
    contract=json.loads(raw)
    need(contract['schema']=='issue18-A01-directory-guide-content/v1','unsupported content contract')
    references={}
    for name,pin in contract['references'].items():
        data=(CASE/pin['relative_path']).read_bytes()
        need(len(data)==pin['bytes'] and digest(data)==pin['sha256'],'reference changed: '+name)
        references[name]=data
    return contract,references

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--binding-sha',required=True)
    parser.add_argument('--raw-directory',type=Path,required=True)
    parser.add_argument('--input-path',type=Path,required=True)
    parser.add_argument('--output-path',type=Path,required=True)
    args=parser.parse_args()
    contract,reference=load_contract(args.binding_sha)
    directory=args.raw_directory
    need(str(directory)==contract['physical_directory'],'exact prospective raw directory differs')
    need(args.input_path==directory/'input.json' and args.output_path==directory/'roundtrip-raw.json','fixed input/output path differs')
    expected=set(contract['raw_payload'])
    actual_names={p.name for p in directory.iterdir()}
    need(actual_names==expected and all((directory/n).is_file() for n in actual_names),'complete18-file flat payload mismatch')
    actual={name:(directory/name).read_bytes() for name in expected}
    for stage in ['jimport_save','jexport','calc','jsonreport']:
        need(not actual[stage+'-stderr.bin'],'native stderr not empty: '+stage)
    result=verify_content(actual,str(directory),contract,reference)
    result['raw_sha256']={name:digest(data) for name,data in actual.items()}
    result['stdout_retention_only']={stage:len(actual[stage+'-stdout.bin']) for stage in ['jimport_save','jexport','calc','jsonreport']}
    print(json.dumps(result,ensure_ascii=False,sort_keys=True))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
