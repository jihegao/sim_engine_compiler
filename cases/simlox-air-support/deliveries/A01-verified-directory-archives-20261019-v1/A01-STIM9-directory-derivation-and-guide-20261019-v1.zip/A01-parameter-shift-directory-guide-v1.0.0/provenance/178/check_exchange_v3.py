"""Exact source-bound new native raw check using corrected delivery validator."""
import argparse,json
from pathlib import Path,PureWindowsPath
from replay_archived_native01_v2 import ROOT,trusted,exact,validate_log_bytes
from precision_contract_v2 import strict_json,validate
def main():
 p=argparse.ArgumentParser();p.add_argument('--binding-sha',required=True);p.add_argument('--raw-directory',required=True,type=Path);p.add_argument('--input-path',required=True);p.add_argument('--output-path',required=True);a=p.parse_args()
 contract,expected=trusted(ROOT,a.binding_sha);physical=PureWindowsPath(contract['candidate']['physical_directory'])
 if a.input_path!=str(physical/'input.json') or a.output_path!=str(physical/'roundtrip-raw.json'):raise ValueError('exact original physical provenance differs')
 exact(a.raw_directory/'input.json',contract['source'])
 result=validate(strict_json((a.raw_directory/'roundtrip-raw.json').read_bytes()),expected)
 result['logs']=[validate_log_bytes(ROOT,(a.raw_directory/'import.log').read_bytes(),'import',a.input_path),validate_log_bytes(ROOT,(a.raw_directory/'export.log').read_bytes(),'export',a.output_path)]
 result.update(status='RAW_IDENTITY_CHECK_ONLY',publication_GO=False,binding_sha256=a.binding_sha,source_sha256=contract['source']['sha256'],variant='K02.var02',strict_log_bytes=True)
 print(json.dumps(result));return 0
if __name__=='__main__':raise SystemExit(main())
