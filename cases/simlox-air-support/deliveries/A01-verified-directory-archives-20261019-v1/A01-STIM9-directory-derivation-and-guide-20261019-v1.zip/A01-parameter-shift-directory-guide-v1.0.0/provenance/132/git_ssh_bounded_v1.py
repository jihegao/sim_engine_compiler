"""Fixed Git SSH443 network child only. No SIMLOX/owner/queue operations."""
import argparse,datetime,hashlib,ipaddress,json,os,subprocess,sys,time,uuid
from pathlib import Path

def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p):
 b=Path(p).read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):
 with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def raw(p,b):
 with Path(p).open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
def retain_unknown(directory,process,error):
 # Deliberate ownership hold, not automatic recovery. No further kill/wait/retry.
 try:save(directory/'UNKNOWN-RETAINED.json',dict(utc=utc(),error=repr(error),owned_direct_pid=process.pid,meaning='Original wrapper and exact direct SSH process object retained; no terminal result/no retry/release authority'))
 except BaseException:pass
 while True:time.sleep(1)

def exchange(command,directory,popen=subprocess.Popen,hold=retain_unknown):
 started=utc()
 process=popen(command,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=False)
 owned=utc();tick=time.monotonic();timeout=False
 try:
  try:out,err=process.communicate(timeout=20)
  except subprocess.TimeoutExpired:
   timeout=True
   # On Windows Popen.kill/terminate uses this object's retained _handle,
   # not GetProcessById or a process-tree kill.
   process.kill()
   out,err=process.communicate(timeout=5)
  if process.returncode is None or process.poll() is None:raise RuntimeError('Original direct SSH terminal status unconfirmed')
  result=dict(schema='issue18-fixed-Git-SSH443-network-child/v1',started_utc=started,owned_utc=owned,completed_utc=utc(),elapsed_after_Popen_seconds=time.monotonic()-tick,command=command,owned_direct_pid=process.pid,timeout_seconds=20,timeout_observed=timeout,owned_direct_process_terminal=True,actual_ssh_exit_code=process.returncode,wrapper_exit_code=124 if timeout else process.returncode,scope='SSH network phase after successful Popen only; not total Git/DNS/process-creation harddeadline',kill_target='same directly created Popen retained handle only' if timeout else None)
  raw(directory/'stdout.bin',out);raw(directory/'stderr.bin',err)
  result['streams']={n:digest(directory/(n+'.bin')) for n in ('stdout','stderr')}
  save(directory/'result.json',result)
  sys.stdout.buffer.write(out);sys.stdout.buffer.flush()
  sys.stderr.buffer.write(err);sys.stderr.buffer.flush()
  return result['wrapper_exit_code']
 except BaseException as error:
  return hold(directory,process,error)

def main():
 p=argparse.ArgumentParser()
 p.add_argument('--manifest',type=Path,required=True);p.add_argument('--manifest-sha',required=True)
 p.add_argument('--mode',choices=['probe0','probe7','preflight','native'],required=True)
 p.add_argument('--resolved-ip',required=True);p.add_argument('git_argv',nargs=argparse.REMAINDER)
 a=p.parse_args()
 if digest(a.manifest)['sha256']!=a.manifest_sha:raise ValueError('Exact manifest differs')
 m=json.loads(a.manifest.read_text(encoding='utf-8-sig'))
 if m['schema']!='simlox-k02-selected-manifest/v5':raise ValueError('Selected network version differs')
 ip=ipaddress.ip_address(a.resolved_ip)
 if ip.version!=4 or str(ip)!=a.resolved_ip:raise ValueError('Canonical IPv4 required')
 tail=a.git_argv
 if tail and tail[0]=='--':tail=tail[1:]
 expected=['-o','SendEnv=GIT_PROTOCOL','git@github.com',"git-upload-pack 'jihegao/sim_engine_compiler.git'"]
 if tail not in (expected,expected[2:]):raise ValueError('Undeclared Git SSH argv rejected')
 profile=m['git_network']
 if profile['host']!='ssh.github.com' or profile['port']!=443 or profile['ssh_network_timeout_seconds']!=20 or profile['ssh_terminal_wait_seconds']!=5 or profile['ssh_config_file']!='NUL':raise ValueError('Fixed network profile differs')
 if profile['identity_file']!=r'C:\Users\user\.ssh\github_deploy_20260927':raise ValueError('Existing deploy identity differs')
 ssh=Path(m['ssh']['path'])
 if digest(ssh)!={k:m['ssh'][k] for k in ('bytes','sha256')}:raise ValueError('OpenSSH executable pin differs')
 if digest(sys.executable)!={k:m['python'][k] for k in ('bytes','sha256')}:raise ValueError('Python interpreter pin differs')
 target=m['targets']['native' if a.mode=='preflight' else a.mode]
 directory=a.manifest.parent/'review'/('git-network-'+a.mode+'-'+uuid.uuid4().hex);directory.mkdir()
 # -F NUL excludes user/system ssh configuration. No proxies, local commands,
 # multiplexing, forwarding, external agent or arbitrary config include helpers.
 command=[str(ssh),'-F','NUL','-i',profile['identity_file'],'-p','443']
 for option in ['IdentitiesOnly=yes','HostName='+str(ip),'HostKeyAlias=github.com','StrictHostKeyChecking=yes','UpdateHostKeys=no','BatchMode=yes','ConnectTimeout=10','ServerAliveInterval=5','ServerAliveCountMax=2','ProxyCommand=none','ProxyJump=none','PermitLocalCommand=no','ControlMaster=no','ControlPath=none','ControlPersist=no','IdentityAgent=none','ForwardAgent=no','ClearAllForwardings=yes']:
  command+=['-o',option]
 command+=tail
 save(directory/'request.json',dict(utc=utc(),manifest_sha256=a.manifest_sha,mode=a.mode,run_id=target['run_id'],resolved_ipv4=str(ip),command=command,Git_arguments=tail,SSH_network_timeout_seconds=20,config_isolated=True,native_or_probe_processes_created=0))
 return exchange(command,directory)
if __name__=='__main__':raise SystemExit(main())

