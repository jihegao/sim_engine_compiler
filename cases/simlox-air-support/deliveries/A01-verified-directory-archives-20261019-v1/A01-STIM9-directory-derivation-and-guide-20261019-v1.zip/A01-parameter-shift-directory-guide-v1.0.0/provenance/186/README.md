# K02.var02 nonASCII Station identifier

One prospective STID change from the independently accepted published v104 parent. Source-method GO only until separate static, reused-real-benign binding, actual SSH0/PS5 preflight and new exact native GO. Never replay old controls or occupied runs. Whole K02 and Issue18 remain incomplete.
