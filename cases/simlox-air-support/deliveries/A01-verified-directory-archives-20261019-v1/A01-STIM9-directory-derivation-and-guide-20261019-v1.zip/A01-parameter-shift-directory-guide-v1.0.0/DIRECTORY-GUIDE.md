# STIM9 directory-local derivation and native reproduction

Preparation uses only prepare.py and fixed-A01-source.zip in the companion
preparation directory, plus installed Python/SIMLOX/.NET/SSH and the declared live
repository, original coordinator and protected GUI safety prerequisites. It was
actually run with isolated Python and cwd C:/Windows/Temp. All project execution
sources are case-local; no old authored temporary directory is needed.

Only OperationProfile(BASIC-SCHEDULE,BASIC-MISSION).STIM changes8.0 to9.0hours,
one byte. The directory-derived source must exactly match native-input.json.
All339 exported typed cells,4044 report cells, full event sequence and four CRLF
stage logs are frozen before native. Notice8, mission9..11, task9.5..10.5,
reservation8..9, one sortie,2h flight,33h ready, NPSTA0 and terminalready1.
Existing normalized STIM9 reference is used only after exact raw report equality;
the original trailing comma remains. No relaxed parser or observed oracle edits.

Read contract.json, source-role-audit-v1.json, selected-manifest-v29.json and the
independent source/ABI review. Verify directory-entry-binding and reader-binding.
directory_preflight.py runs one actual SSH0/PS5 pure preflight, native0. Independent
review must bind its real client original-H natural termination, exact argv/ancestry,
source/refs/settings/GUI/queue and complete prospective oracle into one new GO.
Then directory_native_once.py EXACT_GO_SHA dispatches import-save/export/calc/
jsonreport once, one thread. accept_native.py --controller PATH --controller-sha
SHA performs the independent full-content, actual NTFS and original-H/queue/GUI
acceptance. Use pinned Python -I -X utf8 -B and cwd C:/Windows/Temp.

The fixed run a01-stim9-guide-native-v101-20261019-01 is one-shot. Existing claim,
debug/raw/recovery directory means STOP. Never rerun preparation/native, recreate
GO or reuse consumed IDs. Future native copies need a new reviewed finite version,
paths and runID. Archive replay alone never rebuilds original OS custody.
This is a previously accepted model's directory/tool migration, not new general
model semantics, a separate-agent trial, whole K02 or Issue18 completion.
