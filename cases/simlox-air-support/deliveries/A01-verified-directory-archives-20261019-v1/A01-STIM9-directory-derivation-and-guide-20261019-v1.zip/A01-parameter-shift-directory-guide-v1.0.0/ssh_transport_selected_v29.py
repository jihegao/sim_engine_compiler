"""One-shot, externally reviewed SSH transport; no retries, kills or timeouts."""
import argparse,ctypes,datetime,hashlib,json,shutil,subprocess,uuid
from ctypes import wintypes
from pathlib import Path
CASE=Path(__file__).resolve().parent
def seal(p):
 b=Path(p).read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def check_sources(m):
 for x in m['sources']:
  if seal(x['path'])!={k:x[k] for k in ('bytes','sha256')}:raise ValueError('source pin differs: '+x['path'])
 for x in (m['live_index'],m['live_catalog']):
  if seal(x['path'])!={k:x[k] for k in ('bytes','sha256')}:raise ValueError('live epoch advanced')
def main():
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['preflight','probe0','probe7','native']);p.add_argument('--review-sha',required=True);p.add_argument('--manifest-sha',required=True);p.add_argument('--guardian',required=True,type=Path);p.add_argument('--guardian-sha',required=True);a=p.parse_args()
 manifest_path=CASE/'selected-manifest-v29.json'
 if seal(manifest_path)['sha256']!=a.manifest_sha:raise ValueError('externally expected manifest differs')
 m=json.loads(manifest_path.read_text(encoding='utf-8-sig'));check_sources(m)
 target=m['targets']['native' if a.mode=='preflight' else a.mode]
 rp=CASE/'review'/('independent-'+a.mode+'-go-v29.json')
 if seal(rp)['sha256']!=a.review_sha:raise ValueError('externally expected independent review differs')
 review=json.loads(rp.read_text(encoding='utf-8-sig'))
 if review.get('terminal') is not True or review.get('mode')!=a.mode or review['decision']!=('GO_PRELAUNCH_STATIC' if a.mode=='preflight' else 'GO_PRELAUNCH' if a.mode=='native' else 'GO_REAL_BENIGN_EXACT_BOUND') or review['manifest_sha256']!=a.manifest_sha or review['run_id']!=target['run_id']:raise ValueError('review gate differs')
 if seal(a.guardian)['sha256']!=a.guardian_sha:raise ValueError('standalone guardian receipt differs')
 guardian=json.loads(a.guardian.read_text(encoding='utf-8-sig'))
 if guardian['decision']!='GO_STANDALONE_SAFETY_ONLY' or guardian['manifest_sha256']!=a.manifest_sha or guardian['run_id']!=target['run_id'] or guardian['native_calls']!=0 or guardian['terminal'] is not True:raise ValueError('guardian binding differs')
 # Receipt records completed standalone process. Its handle must now be absent;
 # do not nest a live guardian/transport command that can self-match contender.
 ps=[m['powershell']['path'],'-NoProfile','-NonInteractive','-Command',f"$ErrorActionPreference='Stop'; $p=@(Get-CimInstance Win32_Process -Filter 'ProcessId={int(guardian['guard_pid'])}'); if($p.Count -gt 0){{exit 1}}; exit 0"]
 guard_check=subprocess.run(ps,capture_output=True)
 diagnostic=CASE/'review'/('guardian-pid-check-'+uuid.uuid4().hex);diagnostic.mkdir()
 (diagnostic/'stdout.bin').write_bytes(guard_check.stdout);(diagnostic/'stderr.bin').write_bytes(guard_check.stderr)
 (diagnostic/'receipt.json').write_text(json.dumps(dict(utc=utc(),run_id=target['run_id'],guardian_sha256=a.guardian_sha,command=ps,exit_code=guard_check.returncode,SSH_calls=0,native_calls=0),indent=2)+'\n',encoding='utf-8')
 if guard_check.returncode!=0 or guard_check.stderr:raise ValueError('standalone guardian PID live or query failed; see '+str(diagnostic))
 if Path(target['physical_directory']).exists() or Path(target['recovered_directory']).exists():raise ValueError('unique run path occupied')
 # The remote entry independently verifies the complete exact-bound preceding receipt graph.
 ssh=Path(m['ssh']['path'])
 if not ssh.is_file() or seal(ssh)!={k:m['ssh'][k] for k in ('bytes','sha256')}:raise ValueError('SSH tool fingerprint differs')
 runner=CASE/'run_selected_ssh_v29.ps1';key=Path('C:/Users/user/.ssh/id_rsa')
 if not key.is_file():raise ValueError('existing authorized SSH identity missing')
 debug=CASE/'review'/('ssh-client-'+a.mode+'-debug.log')
 with debug.open('xb'):pass
 cmd=[str(ssh),'-n','-o','BatchMode=yes','-o','ConnectTimeout=10','-vvv','-E',debug.as_posix(),'-i',str(key),'user@127.0.0.1','powershell.exe','-NoProfile','-NonInteractive','-File',runner.as_posix(),'-ExpectedManifestSha',a.manifest_sha,'-ExpectedReviewSha',a.review_sha,'-Mode',a.mode,'-GuardianPath',a.guardian.as_posix(),'-ExpectedGuardianSha',a.guardian_sha]
 directory=CASE/'review'/('transport-'+a.mode+'-'+uuid.uuid4().hex);directory.mkdir()
 started=utc();code=None;error=None;client_terminal=None
 try:
  kernel=ctypes.WinDLL('kernel32',use_last_error=True)
  kernel.GetProcessId.argtypes=[wintypes.HANDLE];kernel.GetProcessId.restype=wintypes.DWORD
  kernel.GetProcessTimes.argtypes=[wintypes.HANDLE,*([ctypes.POINTER(wintypes.FILETIME)]*4)];kernel.GetProcessTimes.restype=wintypes.BOOL
  kernel.QueryFullProcessImageNameW.argtypes=[wintypes.HANDLE,wintypes.DWORD,wintypes.LPWSTR,ctypes.POINTER(wintypes.DWORD)];kernel.QueryFullProcessImageNameW.restype=wintypes.BOOL
  kernel.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];kernel.WaitForSingleObject.restype=wintypes.DWORD
  kernel.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)];kernel.GetExitCodeProcess.restype=wintypes.BOOL
  def identity(p):
   ts=[wintypes.FILETIME() for _ in range(4)];h=wintypes.HANDLE(int(p._handle));assert kernel.GetProcessTimes(h,*[ctypes.byref(x) for x in ts])
   size=wintypes.DWORD(32768);image=ctypes.create_unicode_buffer(size.value);assert kernel.QueryFullProcessImageNameW(h,0,image,ctypes.byref(size))
   return {'pid':p.pid,'creation_filetime':str((ts[0].dwHighDateTime<<32)|ts[0].dwLowDateTime),'image':image.value}
  with (directory/'stdout.bin').open('xb') as out,(directory/'stderr.bin').open('xb') as err:
   p=subprocess.Popen(cmd,cwd=CASE,stdin=subprocess.DEVNULL,stdout=out,stderr=err,close_fds=True)
   first=identity(p)
   (directory/'client-started.json').write_text(json.dumps({'utc':utc(),'identity':first,'command':cmd,'stdin':'DEVNULL','stdout_stderr':'REGULAR_FILES','original_H_retained':True},indent=2)+'\n',encoding='utf-8')
   code=p.wait()
   assert first['image'].lower()==str(ssh).lower()
   h=wintypes.HANDLE(int(p._handle));terminal_times=[wintypes.FILETIME() for _ in range(4)]
   assert kernel.GetProcessTimes(h,*[ctypes.byref(x) for x in terminal_times])
   terminal_creation=str((terminal_times[0].dwHighDateTime<<32)|terminal_times[0].dwLowDateTime)
   terminal_pid=kernel.GetProcessId(h)
   assert terminal_creation==first['creation_filetime'] and terminal_pid==first['pid']
   h=wintypes.HANDLE(int(p._handle));wait=kernel.WaitForSingleObject(h,0);actual=wintypes.DWORD();assert kernel.GetExitCodeProcess(h,ctypes.byref(actual))
   assert wait==0 and actual.value==code
   p._handle.Close();assert p._handle.closed
  client_terminal={'identity':first,'terminal_creation_filetime':terminal_creation,'terminal_pid_from_original_H':terminal_pid,'terminal_identity_basis':'Same retained original H, GetProcessTimes creation equality and GetProcessId before close; live image checked at start, not queried after process exit','natural_exit':True,'retained_H_wait':wait,'retained_H_exit':actual.value,'retained_H_closed':True,'cancelled':False,'debug':{'path':str(debug),**seal(debug)},'protocol_exit_seen':('Exit status '+str(code)) in debug.read_text(encoding='utf-8',errors='replace')}
  assert client_terminal['protocol_exit_seen']
 except Exception as exc:error=repr(exc)
 stability=None
 try:check_sources(m)
 except Exception as exc:stability=repr(exc)
 result=dict(schema='simlox-a01-selected-transport/v29',mode=a.mode,run_id=target['run_id'],started_utc=started,completed_utc=utc(),exit_code=code,error=error,source_stability_error=stability,manifest_sha256=a.manifest_sha,review_sha256=a.review_sha,guardian_sha256=a.guardian_sha,command=cmd,client_terminal=client_terminal,stdin_kind='DEVNULL',streams={n:seal(directory/(n+'.bin')) for n in ('stdout','stderr')},native_approved=a.mode=='native')
 (directory/'transport-receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(dict(evidence=str(directory),exit_code=code,error=error,source_stability_error=stability)))
 return code if isinstance(code,int) and not(error or stability) else 1
if __name__=='__main__':raise SystemExit(main())
