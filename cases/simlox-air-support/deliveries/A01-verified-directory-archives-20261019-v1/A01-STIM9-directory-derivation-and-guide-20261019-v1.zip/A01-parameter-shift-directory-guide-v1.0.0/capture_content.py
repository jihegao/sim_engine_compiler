"""Capture one pinned case-local checker; preserve real exit and both raw streams."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys
CASE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--binding-sha',required=True);p.add_argument('--raw-directory',required=True,type=Path);p.add_argument('--input-path',required=True);p.add_argument('--output-path',required=True);a=p.parse_args()
assert a.raw_directory.is_dir()
name=a.raw_directory.name
assert name and not any(c in name for c in '/\\')
directory=CASE/'review'/('checker-capture-'+name);directory.mkdir(exist_ok=False)
cmd=[sys.executable,'-I','-X','utf8','-B',str(CASE/'check_a01_content.py'),'--binding-sha',a.binding_sha,'--raw-directory',str(a.raw_directory),'--input-path',a.input_path,'--output-path',a.output_path]
with (directory/'stdout.bin').open('xb') as out,(directory/'stderr.bin').open('xb') as err:
 r=subprocess.run(cmd,stdin=subprocess.DEVNULL,stdout=out,stderr=err,cwd=CASE,close_fds=True)
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
receipt={'checker_exit_code':r.returncode,'command':cmd,'stdout':pin(directory/'stdout.bin'),'stderr':pin(directory/'stderr.bin'),'native_calls':0}
with (directory/'receipt.json').open('x',encoding='utf-8') as f:json.dump(receipt,f,indent=2);f.write('\n')
if r.returncode==0:
 assert not (directory/'stderr.bin').read_bytes()
 sys.stdout.buffer.write((directory/'stdout.bin').read_bytes())
else:print(json.dumps({'status':'READONLY_CHECK_FAILED','checker_exit_code':r.returncode,'capture_directory':str(directory),'publication_GO':False}))
raise SystemExit(r.returncode)
