from pathlib import Path
import argparse,hashlib,json
CASE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
assert a.output.parent.resolve()==(CASE/'review').resolve()
r=(CASE/'source-snapshots/parent-input.json').read_bytes();assert hashlib.sha256(r).hexdigest()=='8bbd31d05630cc4a44c4b03b715d17e2f4a1ee1601352952089efd3e584f98b7'
d=json.loads(r);t=next(t for t in d['model']['tables'] if t['name']=='OperationProfile');j=next(j for j,c in enumerate(t['columns']) if c['name']=='STIM')
assert t['instances'][0]['rows'][0][:2]==['BASIC-SCHEDULE','BASIC-MISSION'] and t['instances'][0]['rows'][0][j]==8.0
t['instances'][0]['rows'][0][j]=9.0;out=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode()
assert hashlib.sha256(out).hexdigest()=='b69fc16e8e3144f4334671d73c6b03b379c583841d1d38a1c637bd1d7e77cd22' and out==(CASE/'native-input.json').read_bytes()
with a.output.open('xb') as f:f.write(out)
print(json.dumps({'derived_source_sha256':hashlib.sha256(out).hexdigest(),'native_calls':0}))
