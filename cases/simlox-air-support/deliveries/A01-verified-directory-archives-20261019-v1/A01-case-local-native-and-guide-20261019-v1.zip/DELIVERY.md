# A01 case-local native reproduction and guide delivery

The model input is byte-identical to the accepted A01 teaching case. This new
native run verifies the migrated case-local project tooling, neutral cwd and the
explicit logged SSH transport while preserving original process/GUI/queue guards.
Full339 typed export cells,4044 report cells, complete events and four complete
CRLF stage logs are checked against expectations frozen before this run.

Project source roles are local to the case directory. Installed vendor/Python/.NET
and SSH tools, live repository freshness and original coordinator/GUI state remain
explicit host prerequisites. Credentials, private dumps, vendor binaries/manuals
and databases are not included. DIRECTORY-GUIDE.md describes the reviewed entry.

The fixed runID and GO are consumed. Do not execute the archived native controller,
recreate GO or reuse its paths. A future native run needs a new version/dir/runID
and all fresh independent safety and source gates. Read-only archive replay:
  python -I -X utf8 -B replay.py <this directory>
It verifies indexed bytes, full typed source/export/report, raw-normalized relation,
events, complete stage logs, archived handles/custody and logged client receipts.
It launches no native code and does not recreate Windows readonly/NTFS identities,
original handles, queue or protected GUI. Actual OS evidence remains in the original
independent terminal receipt. Prior v1.0.0 pure-preflight failure and the finite
GetProcessTimes/image-query API experiment are retained; no native attempt occurred
in v1.0.0 and no old failed profile was rerun. No model oracle was changed.

This bounded new-method acceptance is not proof of the old SSH hang cause, a separate
agent trial, new parameter semantics, K02 Unicode/inactive/wrong-type/import-refusal
acceptance, repository publication, cross-engine conformance or whole Issue18.
Previously accepted A01 STIM8-to9 derivation remains independent evidence.
