"""Portable full-content replay; never launches native code or recreates OS custody."""
from pathlib import Path,PurePosixPath,PureWindowsPath
import hashlib,json,re,struct,sys
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
CASE=ROOT/'A01-directory-guide-native-v1.0.1'
def sha(r):return hashlib.sha256(r).hexdigest()
def pairs(items):
 d={}
 for k,v in items:assert k not in d,'lexical property duplicate';d[k]=v
 return d
def doc(r):return json.loads(r,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite JSON')))
def equal(a,b):
 if type(a) is not type(b):return False
 if isinstance(a,dict):return set(a)==set(b) and all(equal(a[k],b[k]) for k in a)
 if isinstance(a,list):return len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
 if isinstance(a,float):return struct.pack('>d',a)==struct.pack('>d',b)
 return a==b
def cells(d,root):return sum(len(row) for t in d[root]['tables'] for i in t['instances'] for row in i['rows'])
index=doc((ROOT/'delivery-index.json').read_bytes());assert index['schema']=='issue18-A01-case-local-directory-delivery/v1'
files={v['relative_path']:v for v in index['files']};assert len(files)==len(index['files'])==index['file_count']
for name,v in files.items():
 rel=PurePosixPath(name);assert not rel.is_absolute() and all(p not in ['..','.',''] for p in rel.parts) and '\\' not in name and ':' not in name
 p=ROOT.joinpath(*rel.parts);assert p.is_file() and not p.is_symlink();r=p.read_bytes();assert len(r)==v['bytes'] and sha(r)==v['sha256'],name
assert {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}==set(files)|{'delivery-index.json'}
mp=CASE/'selected-manifest-v27.json';assert sha(mp.read_bytes())=='3a2fc18e9772776c1b01f902cf155ac396905351be5a900a894f02a9db8b3719'
m=doc(mp.read_bytes());target=m['targets']['native'];remote=PureWindowsPath(m['working_directory'])
def mapped(v):
 rel=PureWindowsPath(v['path']).relative_to(remote);r=CASE.joinpath(*rel.parts).read_bytes()
 assert len(r)==v['bytes'] and sha(r)==v['sha256'];return r
tp=CASE/'review/independent-native-acceptance-v27.json';terminal=doc(tp.read_bytes());assert sha(tp.read_bytes())==index['terminal_sha256']
assert terminal['decision']=='ACCEPT_BOUNDED_A01_CASE_LOCAL_DIRECTORY_NATIVE_AND_LOGGED_TRANSPORT'
assert terminal['source_unchanged_A01'] and terminal['logged_SSH_client_natural_exit_verified'] and terminal['checker_raw_stderr_preserved']
assert terminal['directory_only_cold_process_native_verified'] and terminal['actual_readonly_NTFS_metadata_queries']==36
owner=doc(mapped(terminal['owner_receipt']));r=owner['result'];children=r['Children']
assert [c['Stage'] for c in children]==['jimport_save','jexport','calc','jsonreport'] and [c['ExitCode'] for c in children]==[0,0,0,0]
assert all(c['ResumeCount']==1 and c['Signaled'] and c['ExitCodeObserved'] for c in children)
assert r['NativeSimloxCalls']==4 and r['SimulationCalls']==1 and r['ParentReruns']==0
assert r['RecoveryVerified'] and r['OriginalSealed'] and r['RawBehaviorAccepted'] and r['QueueReleasedActual'] and not r['QueueOwned'] and not r['UnknownChild'] and not r['Failed']
assert all(v['CloseAttempted'] and v['ClosedActual'] and not v['CloseUnknown'] for v in r['Handles'])
assert len(r['Handles'])==terminal['handle_records_verified']
content=doc((CASE/'content-contract-v1.json').read_bytes());assert sha((CASE/'content-contract-v1.json').read_bytes())==m['component_binding_sha256']
refs={}
for name,v in content['references'].items():
 data=(CASE/v['relative_path']).read_bytes();assert len(data)==v['bytes'] and sha(data)==v['sha256'];refs[name]=data
rawdir=CASE/'runs'/target['run_id'];names={p.name for p in rawdir.iterdir()}
assert names==set(content['raw_payload']) and len(names)==18
originals={v['Name']:v for v in r['Originals']};copies={v['Name']:v for v in r['Recovered']}
assert names==set(originals)==set(copies)=={v['name'] for v in terminal['complete_raw_pairs']}
payload={}
for name in names:
 raw=(rawdir/name).read_bytes();a=originals[name];b=copies[name]
 assert sha(raw)==a['Sha']==b['Sha'] and len(raw)==a['Bytes']==b['Bytes']
 assert (a['Volume'],a['Id'])!=(b['Volume'],b['Id']) and a['Attributes']&1 and b['Attributes']&1
 payload[name]=raw
assert sha(payload['input.json'])==m['input_sha256']=='8bbd31d05630cc4a44c4b03b715d17e2f4a1ee1601352952089efd3e584f98b7'
assert payload['input.json']==(CASE/'source-snapshots/parent-input.json').read_bytes()
exported=doc(payload['roundtrip-raw.json']);assert equal(exported,doc(refs['roundtrip-raw.json'])) and cells(exported,'model')==terminal['export_cells']==339
assert payload['report-raw.json']==refs['report-raw.json'] and payload['model.log']==refs['model.log']
raw=payload['report-raw.json'];norm=refs['historical-report-normalized.json'];assert raw[103957]==44 and raw[:103957]+raw[103958:]==norm
try:doc(raw)
except json.JSONDecodeError as e:assert e.pos==103966
else:raise AssertionError('original strict raw failure disappeared')
report=doc(norm);assert cells(report,'report')==terminal['full_typed_report_cells']==4044
t=next(t for t in report['report']['tables'] if t['name']=='SystemResults');cols=[c['name'] for c in t['columns']];rows=t['instances'][0]['rows'];assert len(rows)==72
metrics={key:sum(row[cols.index(key)]*(row[cols.index('ETINT')]-row[cols.index('STINT')]) for row in rows) for key in ['FTMO','NSYMO','NSYMA','NSYMR','NSYRY']}
assert metrics==terminal['integrals_hours']=={'FTMO':2,'NSYMO':2,'NSYMA':3,'NSYMR':1,'NSYRY':33} and rows[-1][cols.index('NSYRY')]==1
audit=doc((CASE/'source-role-audit-v1.json').read_bytes())
cp=next(v['selected'] for v in audit['source_roles'] if v['original']['path'].endswith('A01-native-reproduction-codex-v1.0.0\\source-snapshots\\a01-bound-final-20260927-03--closure.json'))
refdir=str(PureWindowsPath(doc(mapped(cp))['artifacts']['input.json']['path']).parent)
prefixes=[b'Import completed! Time: ',b'Export completed! Time: ',b'Input data conversion time: ',b'Simulation time: ',b'Result saving time: ',b'Total execution time: ',b'Json-report generation time: ']
for name in ['import.log','export.log','run.log','report-export.log']:
 data=payload[name];assert data.endswith(b'\r\n') and not re.search(rb'[\r\n]',data.replace(b'\r\n',b''))
 expression=[]
 for line in refs[name].splitlines(keepends=True):
  line=line.replace(refdir.encode(),str(PureWindowsPath(target['physical_directory'])).encode()).replace(refdir.replace('\\','/').encode(),str(PureWindowsPath(target['physical_directory'])).replace('\\','/').encode())
  prefix=next((p for p in prefixes if line.startswith(p)),None)
  if prefix:
   match=re.fullmatch(re.escape(prefix)+rb'([0-9]+\.[0-9]+)( secs\.?\r\n)',line);assert match
   expression.append(re.escape(prefix)+rb'[0-9]+\.[0-9]+'+re.escape(match.group(2)))
  else:expression.append(re.escape(line))
 assert re.fullmatch(b''.join(expression),data),name
for stage in ['jimport_save','jexport','calc','jsonreport']:assert not payload[stage+'-stderr.bin']
controller=doc(mapped(terminal['controller']))
transport_dir=PureWindowsPath(json.loads(controller['transport_stdout'])['evidence'])
tr=doc((CASE.joinpath(*transport_dir.relative_to(remote).parts)/'transport-receipt.json').read_bytes());cl=tr['client_terminal']
assert tr['stdin_kind']=='DEVNULL' and cl['natural_exit'] and not cl['cancelled'] and cl['retained_H_wait']==cl['retained_H_exit']==0 and cl['retained_H_closed']
assert cl['terminal_creation_filetime']==cl['identity']['creation_filetime'] and cl['terminal_pid_from_original_H']==cl['identity']['pid']
assert b'Exit status 0' in mapped(cl['debug'])
capture=CASE/'review'/('checker-capture-'+target['run_id']);cp=doc((capture/'receipt.json').read_bytes())
assert cp['checker_exit_code']==0 and not mapped(cp['stderr']) and doc(mapped(cp['stdout']))['report_cells']==4044
print(json.dumps({'decision':'ACCEPT_PORTABLE_A01_CASE_LOCAL_FULL_NATIVE_CONTENT_REPLAY','files_checked':len(files),'source_reconstructed':True,'source_unchanged_A01':True,'logged_SSH_terminal_receipt_checked':True,'export_cells':339,'report_cells':4044,'raw_files':18,'full_stage_logs':4,'integrals_hours':metrics,'terminal_ready':1,'actual_native_calls_this_replay':0,'original_OS_custody_recreated':False,'new_agent_trial_inferred':False,'whole_K02_complete':False,'whole_issue_complete':False},indent=2))
