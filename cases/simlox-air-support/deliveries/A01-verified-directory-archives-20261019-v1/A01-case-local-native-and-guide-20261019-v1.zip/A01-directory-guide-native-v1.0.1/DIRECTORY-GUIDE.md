# A01 case-local native directory reproduction

This fixed, one-shot directory reproduces the accepted A01 source model without
changing its rules. All project execution sources and historical provenance are
inside this directory; installed Python/SIMLOX/.NET compiler, repository freshness
gates, existing SSH identity/trust and protected GUI are explicit host prerequisites.
No vendor installer, manual, database, credentials or private dump is included.

Use the pinned Python with `-I -X utf8 -B` and cwd `C:/Windows/Temp`.
Read contract.json, preparation-profile-v1.json and selected-manifest-v27.json.
Verify the source-role audit, independent static/ABI review and entry/reader pins.
Run directory_preflight.py only once. An independent reader must bind the actual
SSH0/PS5 result, natural client exit, exact source/refs/settings/GUI/queue checks and
the prospective full model/export/report/event/four-log contract into a fresh GO.
Only then invoke directory_native_once.py with that exact permission SHA.
It dispatches import-save, export, single-thread calc and jsonreport at most once.
Run accept_native.py --controller PATH --controller-sha SHA for independent custody,
NTFS identities, complete339 export cells,4044 report cells, events, four CRLF logs,
original process handles, queue release and final GUI checks.

The new SSH profile declares -vvv/-E with a fixed case-local debug log, stdin
DEVNULL and regular streams. The complete CurrentTransport argv/parent/connection
guard remains mandatory. The client original H is checked before/after natural
termination. This is bounded new-method integration, not proof of the old hang's
cause. The checker capture preserves its actual exit and raw stderr separately.

Fixed runID a01-guide-native-v101-20261019-01 is consumed by the first claim.
An existing claim, debug path or raw/recovery directory means STOP. Never recreate
GO, retry or alter frozen expectations. Future native reproduction requires a new
version/directory/runID and fresh independent review; archived evidence is read-only.

The source and all expected outcomes predate this native attempt. Raw report has
the historical trailing comma: exact byte equality must precede use of the existing
strict normalized reference. Do not rewrite raw JSON or relax the parser.
This proves the stated fixed A01 directory scope only. It does not certify a separate
agent trial, generic runtime changes, whole K02/Issue18 or any failed import branch.
The previously accepted STIM8-to9 parameter run remains independent evidence.
