"""Read-only independent full native-result acceptance for the fixed A01 run.

Does not import the producer/owner/content checker, execute a model, or change
source/raw files. Writes only a new terminal acceptance receipt after all checks.
"""
from pathlib import Path
import ctypes
from ctypes import wintypes
import datetime
import hashlib
import json
import re
import struct
import subprocess

CASE=Path(__file__).resolve().parent
MANIFEST='3a2fc18e9772776c1b01f902cf155ac396905351be5a900a894f02a9db8b3719'
def filepin(p):
    data=p.read_bytes();return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def bound(pin):
    p=Path(pin['path']);assert filepin(p)=={k:pin[k] for k in ('path','bytes','sha256')};return p.read_bytes()
def deep(a,b,path='$'):
    assert type(a) is type(b),'typed mismatch '+path
    if isinstance(a,dict):
        assert set(a)==set(b),'key mismatch '+path
        return 1+sum(deep(a[k],b[k],path+'/'+k) for k in a)
    if isinstance(a,list):
        assert len(a)==len(b),'array size mismatch '+path
        return 1+sum(deep(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b)))
    if isinstance(a,float):assert struct.pack('>d',a)==struct.pack('>d',b),'binary64 mismatch '+path
    else:assert a==b,'value mismatch '+path
    return 1
def cells(value):
    if isinstance(value,dict):return sum(sum(map(len,v)) if k=='rows' else cells(v) for k,v in value.items())
    if isinstance(value,list):return sum(cells(v) for v in value)
    return 0

def properties(items):
    d={}
    for k,v in items:assert k not in d,'lexical property duplicate';d[k]=v
    return d
def document(raw):return json.loads(raw,object_pairs_hook=properties,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite JSON')))
class FT(ctypes.Structure):_fields_=[('low',wintypes.DWORD),('high',wintypes.DWORD)]
class INFO(ctypes.Structure):
    _fields_=[('attributes',wintypes.DWORD),('creation',FT),('access',FT),('write',FT),('volume',wintypes.DWORD),('size_high',wintypes.DWORD),('size_low',wintypes.DWORD),('links',wintypes.DWORD),('id_high',wintypes.DWORD),('id_low',wintypes.DWORD)]
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.CreateFileW.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p,wintypes.DWORD,wintypes.DWORD,wintypes.HANDLE];k.CreateFileW.restype=wintypes.HANDLE
k.GetFileInformationByHandle.argtypes=[wintypes.HANDLE,ctypes.POINTER(INFO)];k.GetFileInformationByHandle.restype=wintypes.BOOL
k.CloseHandle.argtypes=[wintypes.HANDLE];k.CloseHandle.restype=wintypes.BOOL
k.OpenMutexW.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.LPCWSTR];k.OpenMutexW.restype=wintypes.HANDLE
def actual_file_identity(p):
    h=k.CreateFileW(str(p),0x80,1,None,3,0x00200000,None)
    assert h and h!=ctypes.c_void_p(-1).value,('read-only metadata open',str(p),ctypes.get_last_error())
    try:
        i=INFO();assert k.GetFileInformationByHandle(h,ctypes.byref(i))
        assert i.links==1 and not i.attributes&0x410 and i.attributes&1
        return {'Volume':i.volume,'Id':(i.id_high<<32)|i.id_low,'Creation':(i.creation.high<<32)|i.creation.low,'Bytes':(i.size_high<<32)|i.size_low,'Attributes':i.attributes}
    finally:assert k.CloseHandle(h),'independent metadata H close failure'

mp=CASE/'selected-manifest-v27.json';assert filepin(mp)['sha256']==MANIFEST
m=document(mp.read_bytes());t=m['targets']['native'];rawdir=Path(t['physical_directory']);recovered=Path(t['recovered_directory'])
import argparse
parser=argparse.ArgumentParser();parser.add_argument('--controller',type=Path,required=True);parser.add_argument('--controller-sha',required=True);args=parser.parse_args()
assert args.controller.parent==CASE/'review'
controller_pin=filepin(args.controller);assert controller_pin['sha256']==args.controller_sha
controller=document(bound(controller_pin))
assert controller['transport_exit_code']==0 and not controller['transport_stderr'] and controller['retries']==0
assert controller['actual_native_calls']==4 and controller['actual_simulation_calls']==1
owner_pin=controller['owner_receipt'];owner=document(bound(owner_pin));result=owner['result']
assert owner['mode']=='native' and owner['manifest_sha256']==MANIFEST and owner['run_id']==t['run_id']
for key in ['RawOwned','RecoveredOwned','OriginalSealed','RecoveryVerified','RawBehaviorAccepted','QueueReleaseAttempted','QueueReleasedActual']:
    assert result[key] is True,key
for key in ['Failed','UnknownChild','QueueOwned']:
    assert result[key] is False,key
assert result['NativeSimloxCalls']==4 and result['SimulationCalls']==1 and result['ParentReruns']==0
children=result['Children'];assert [x['Stage'] for x in children]==['jimport_save','jexport','calc','jsonreport']
identities=owner['independent_suspended_identity'];assert len(identities)==4
for child in children:
    for key in ['CreateAttempted','CreateReturned','Created','ResumeAttempted','ResumeReturned','Signaled','IdentityBeforeResume','IdentityAfterSignal','ExitCodeObserved']:
        assert child[key] is True,(child['Stage'],key)
    assert child['ExitCode']==0 and child['ResumeCount']==1 and child['Session']==0
    assert child['ImagePath'].lower()==m['exe']['path'].lower()
    rows=[x for x in identities if x['pid']==child['Pid'] and int(x['creation_filetime'])==child['Creation']]
    assert len(rows)==1 and rows[0]['observed_before_resume'] is True
    assert rows[0]['path'].lower()==m['exe']['path'].lower()
assert len({(x['Pid'],x['Creation']) for x in children})==4
handles=result['Handles'];assert handles
assert all(x['CloseAttempted'] is True and x['ClosedActual'] is True and x['CloseUnknown'] is False for x in handles)
assert len([x for x in handles if x['Role'].startswith('Process:')])==4
assert len([x for x in handles if x['Role'].startswith('Thread:')])==4

contract=document((CASE/'content-contract-v1.json').read_bytes())
assert filepin(CASE/'content-contract-v1.json')['sha256']==m['component_binding_sha256']
names=set(contract['raw_payload']);assert len(names)==18
assert {p.name for p in rawdir.iterdir()}=={p.name for p in recovered.iterdir()}==names
originals={x['Name']:x for x in result['Originals']};copies={x['Name']:x for x in result['Recovered']}
assert set(originals)==set(copies)==names
payload={};pairs=[]
for name in sorted(names):
    p=rawdir/name;q=recovered/name;op=originals[name];cp=copies[name]
    a=p.read_bytes();b=q.read_bytes();actual=hashlib.sha256(a).hexdigest()
    assert a==b and actual==op['Sha']==cp['Sha']
    assert len(a)==op['Bytes']==cp['Bytes']
    assert (op['Volume'],op['Id'])!=(cp['Volume'],cp['Id'])
    assert op['Attributes']&1 and cp['Attributes']&1
    li=actual_file_identity(p);ri=actual_file_identity(q)
    assert all(li[k]==op[k] and ri[k]==cp[k] for k in li)
    assert p.stat().st_file_attributes&1 and q.stat().st_file_attributes&1
    payload[name]=a;pairs.append({'name':name,'bytes':len(a),'sha256':actual,'original_and_recovered_byte_equal':True,'original_readonly':True,'recovered_readonly':True,'distinct_file_identity':True})
assert hashlib.sha256(payload['input.json']).hexdigest()=='8bbd31d05630cc4a44c4b03b715d17e2f4a1ee1601352952089efd3e584f98b7'
assert payload['input.json']==(CASE/'source-snapshots/parent-input.json').read_bytes()
assert len(payload['model.sxi'])>4 and len(payload['model.sxo'])>4
for stage in ['jimport_save','jexport','calc','jsonreport']:
    assert payload[stage+'-stderr.bin']==b''
reference={name:bound({'path':str(CASE/p['relative_path']),'bytes':p['bytes'],'sha256':p['sha256']}) for name,p in contract['references'].items()}
export_nodes=deep(document(payload['roundtrip-raw.json']),document(reference['roundtrip-raw.json']))
assert payload['report-raw.json']==reference['report-raw.json']
assert payload['model.log']==reference['model.log']
raw_report=payload['report-raw.json'];norm=reference['historical-report-normalized.json']
assert raw_report[103957]==44 and raw_report[:103957]+raw_report[103958:]==norm
try:document(raw_report)
except json.JSONDecodeError as error:assert error.pos==103966
else:raise AssertionError('Historical strict raw report failure unexpectedly absent')
report=document(norm);assert cells(report)==4044
tables={x['name']:x for x in report['report']['tables']};system=tables['SystemResults'];columns=[x['name'] for x in system['columns']];rows=system['instances'][0]['rows']
assert len(rows)==72 and len(columns)==40
metrics={key:sum(row[columns.index(key)]*(row[columns.index('ETINT')]-row[columns.index('STINT')]) for row in rows) for key in ['FTMO','NSYMO','NSYMA','NSYMR','NSYRY']}
assert metrics=={'FTMO':2,'NSYMO':2,'NSYMA':3,'NSYMR':1,'NSYRY':33}
assert rows[-1][columns.index('NSYRY')]==1
prep=[]
for table in report['report']['tables']:
    cols=[x['name'] for x in table['columns']]
    if 'NPSTA' in cols:
        for instance in table['instances']:
            prep += [row[cols.index('NPSTA')] for row in instance['rows'] if row[cols.index('NPSTA')] is not None]
assert prep and all(x==0 for x in prep)
for prefix in [b'Time: 7 <BASIC-MISSION,TEACH-UNIT,0,0,0> mission created:',b'Time: 8 <BASIC-MISSION,TEACH-UNIT,0,0,0> mission starting, duration: 2',b'Time: 10 <BASIC-MISSION,TEACH-UNIT,0,0,0> mission completed:']:
    assert payload['model.log'].count(prefix)==1

# Independently build a complete anchored log expression. Only declared path
# literals and numeric elapsed values on the fixed timing lines may vary.
audit=document((CASE/'source-role-audit-v1.json').read_bytes())
closure_pin=next(x['selected'] for x in audit['source_roles'] if x['original']['path'].endswith('A01-native-reproduction-codex-v1.0.0\\source-snapshots\\a01-bound-final-20260927-03--closure.json'))
ref_dir=str(Path(document(bound(closure_pin))['artifacts']['input.json']['path']).parent)
timing_prefixes=[b'Import completed! Time: ',b'Export completed! Time: ',b'Input data conversion time: ',b'Simulation time: ',b'Result saving time: ',b'Total execution time: ',b'Json-report generation time: ']
for name in ['import.log','export.log','run.log','report-export.log']:
    original=reference[name];actual=payload[name]
    assert original.endswith(b'\r\n') and actual.endswith(b'\r\n')
    assert b'\n' not in actual.replace(b'\r\n',b'') and b'\r' not in actual.replace(b'\r\n',b'')
    lines=[]
    for line in original.splitlines(keepends=True):
        line=line.replace(ref_dir.encode(),str(rawdir).encode()).replace(ref_dir.replace('\\','/').encode(),str(rawdir).replace('\\','/').encode())
        prefix=next((p for p in timing_prefixes if line.startswith(p)),None)
        if prefix:
            match=re.fullmatch(re.escape(prefix)+rb'([0-9]+\.[0-9]+)( secs\.?\r\n)',line)
            assert match
            lines.append(re.escape(prefix)+rb'[0-9]+\.[0-9]+'+re.escape(match.group(2)))
        else:lines.append(re.escape(line))
    assert re.fullmatch(b''.join(lines),actual),name
for entry in m['sources']:bound(entry)

binding=CASE/'directory-entry-binding-v1.json';permission=document(bound(controller['permission']))
assert filepin(binding)==permission['directory_entry_binding']
for v in document(binding.read_bytes())['files']:
    raw=(CASE/v['relative_path']).read_bytes();assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256']
invocation=CASE/'review/directory-native-invocation-v1.json';inv=document(invocation.read_bytes())
assert inv['exit_code']==0 and inv['retries']==0 and inv['cwd']=='C:/Windows/Temp'
assert inv['command'][:5]==[m['python']['path'],'-I','-X','utf8','-B'] and inv['command'][5]==str(CASE/'directory_native_once.py')
assert m['working_directory']==str(CASE)
for v in audit['source_roles']:
    if v['classification'].startswith('PROJECT'):assert Path(v['selected']['path']).is_relative_to(CASE)

transport_dir=Path(json.loads(controller['transport_stdout'])['evidence'])
assert transport_dir.parent==CASE/'review' and transport_dir.name.startswith('transport-native-')
transport=document((transport_dir/'transport-receipt.json').read_bytes());client=transport['client_terminal']
assert transport['mode']=='native' and transport['exit_code']==0 and transport['stdin_kind']=='DEVNULL'
assert client['natural_exit'] is True and client['cancelled'] is False
assert client['terminal_creation_filetime']==client['identity']['creation_filetime'] and client['terminal_pid_from_original_H']==client['identity']['pid']
assert client['retained_H_wait']==client['retained_H_exit']==0 and client['retained_H_closed'] is True and client['protocol_exit_seen'] is True
debug=bound(client['debug']);assert b'Exit status 0' in debug
assert Path(client['debug']['path'])==CASE/'review/ssh-client-native-debug.log'
cmd=transport['command'];assert cmd[:10]==[m['ssh']['path'],'-n','-o','BatchMode=yes','-o','ConnectTimeout=10','-vvv','-E',(CASE/'review/ssh-client-native-debug.log').as_posix(),'-i']
assert owner['transport_identity']['client_pid']==client['identity']['pid']
cim=int(owner['transport_identity']['client_creation_filetime_cim']);full=int(client['identity']['creation_filetime'])
assert 0<=full-cim<10 # CIM microsecond precision; actual retained-H FILETIME remains authoritative.
assert owner['transport_identity']['client_command']==' '.join(cmd)
assert client['identity']['image'].lower()==m['ssh']['path'].lower()
capture=CASE/'review'/('checker-capture-'+t['run_id'])
captured=document((capture/'receipt.json').read_bytes())
assert captured['checker_exit_code']==0 and bound(captured['stderr'])==b''
checked=document(bound(captured['stdout']));assert checked['status']=='RAW_IDENTITY_CHECK_ONLY' and checked['report_cells']==4044
assert captured['command'][1:6]==['-I','-X','utf8','-B',str(CASE/'check_a01_content.py')]

ps=r'''$g=@(Get-Process Simlox -ErrorAction SilentlyContinue);if($g.Count -ne 1){throw 'Unexpected native process set'};$g|ForEach-Object{[ordered]@{pid=$_.Id;session=$_.SessionId;creation_filetime=$_.StartTime.ToUniversalTime().ToFileTimeUtc().ToString();path=$_.Path;responding=$_.Responding}}|ConvertTo-Json -Compress'''
observed=subprocess.run([m['powershell']['path'],'-NoProfile','-NonInteractive','-Command',ps],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=20)
assert observed.returncode==0 and not observed.stderr
gui=document(observed.stdout)
assert gui['pid']==13340 and gui['session']==1 and gui['creation_filetime']=='134350637968261381' and gui['responding'] is True
assert gui['path']==m['exe']['path']
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.OpenMutexW.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.LPCWSTR];kernel.OpenMutexW.restype=wintypes.HANDLE
kernel.CloseHandle.argtypes=[wintypes.HANDLE];kernel.CloseHandle.restype=wintypes.BOOL
ctypes.set_last_error(0);handle=kernel.OpenMutexW(0x00100000,False,r'Global\SimloxIssue18NativeQueue');error=ctypes.get_last_error()
if handle:assert kernel.CloseHandle(handle)
assert not handle and error==2
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt={'schema':'issue18-independent-A01-case-local-guide-native-acceptance/v1','utc':now,'terminal':True,'completed':True,'decision':'ACCEPT_BOUNDED_A01_CASE_LOCAL_DIRECTORY_NATIVE_AND_LOGGED_TRANSPORT','run_id':t['run_id'],'manifest':filepin(mp),'controller':controller_pin,'owner_receipt':owner_pin,'physical_directory':str(rawdir),'recovered_directory':str(recovered),'actual_native_stages':[{'stage':x['Stage'],'pid':x['Pid'],'creation_filetime_decimal':str(x['Creation']),'exit_code':x['ExitCode'],'original_H_signaled':x['Signaled'],'single_resume_count':x['ResumeCount']} for x in children],'actual_native_calls':4,'actual_simulation_calls':1,'new_control_calls':0,'parent_validation_reruns':0,'source_roles_rechecked':len(m['sources']),'independent_export_tree_nodes_checked':export_nodes,'export_cells':cells(document(payload['roundtrip-raw.json'])),'full_typed_report_cells':4044,'report_raw_sha256':hashlib.sha256(raw_report).hexdigest(),'raw_strict_JSON_failure_retained':True,'historical_normalized_relationship':'Exact one-comma deletion at offset103957 in separately retained reference; actual raw byte equality checked; no new relaxed decoder','complete_model_log_byte_equal':True,'full_stage_logs_checked':4,'native_warnings':['108 ENLOG enabled','126 no items in fixed teaching system'],'integrals_hours':metrics,'native_NPSTA_values':sorted(set(prep)),'terminal_ready':1,'complete_raw_pairs':pairs,'all_original_handles_closed_actual':True,'handle_records_verified':len(handles),'native_queue_release_actual':True,'native_queue_OpenExisting_after':{'exists':bool(handle),'last_error':error,'ownership_not_changed':True},'protected_gui_final':gui,'native_execution_verified':True,'parameter_derived_case_completed':False,'guide_only_other_agent_delivery_verified':False,'directory_only_cold_process_native_verified':True,'project_source_paths_outside_case_required':0,'actual_readonly_NTFS_metadata_queries':36,'source_unchanged_A01':True,'logged_SSH_client_natural_exit_verified':True,'checker_raw_stderr_preserved':True,'publication_GO':False,'K02_native_holds_unchanged':True,'whole_scope_complete':False,'denominator':None,'limitations':['Fixed unchanged A01 native directory reproduction only, with installed tools and live coordinator/repository gates declared','No separate new-agent trial or new parameter-derived native claim','K02 Unicode, inactive_rows, wrong-type and import-refusal gaps unchanged','Bounded logged SSH integration only; old hang cause and old-method repair unproved','No GUI feature, cross-engine, performance or publication claim']}
target=CASE/'review/independent-native-acceptance-v27.json'
with target.open('x',encoding='utf-8') as stream:json.dump(receipt,stream,ensure_ascii=False,indent=2);stream.write('\n')
print(json.dumps({'observed_at_utc':now,'decision':receipt['decision'],'terminal_receipt':filepin(target),'native_stages':receipt['actual_native_stages'],'actual_native_calls':4,'actual_simulation_calls':1,'raw_pairs_verified':len(pairs),'full_report_cells':4044,'export_cells':receipt['export_cells'],'handle_records_verified':len(handles),'integrals_hours':metrics,'terminal_ready':1,'native_queue_release_actual':True,'native_queue_after':receipt['native_queue_OpenExisting_after'],'protected_gui_final':gui,'parameter_derived_case_completed':False,'whole_scope_complete':False},ensure_ascii=False,indent=2))
